"""Definitive reference verification: resolve each cited DOI via Crossref and match title/year."""
import json, re, time, urllib.request

t = open("manuscript.md", encoding="utf-8").read()
refs = {}
for m in re.finditer(r"^\{([A-Za-z0-9]+)\} (.+)$", t, re.M):
    refs[m.group(1)] = m.group(2).strip()

def get_doi(doi, tries=4):
    url = f"https://api.crossref.org/works/{doi}"
    for i in range(tries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "research-verify/1.0 (mailto:research@example.org)"})
            with urllib.request.urlopen(req, timeout=60) as r:
                return json.loads(r.read().decode("utf-8"))["message"]
        except Exception as e:
            if i == tries - 1:
                return None
            time.sleep(4 * (i + 1))

def norm(s):
    return re.sub(r"[^a-z0-9]+", " ", (s or "").lower()).strip()

ok, fail, nodoi = [], [], []
for key, ref in refs.items():
    dm = re.search(r"doi:([^\s]+)", ref, re.I)
    if not dm:
        nodoi.append(key)
        print(f"  NO-DOI  {key:22s} {ref[:70]}")
        continue
    doi = dm.group(1).rstrip(".")
    msg = get_doi(doi)
    if not msg:
        fail.append((key, doi, "API fail"))
        print(f"  API-FAIL {key:20s} {doi}")
        continue
    ct = (msg.get("title") or [""])[0]
    cy = (msg.get("issued", {}).get("date-parts") or [[None]])[0][0]
    venue = (msg.get("container-title") or [""])[0]
    # title similarity: check that the reference contains the core title words
    ref_norm = norm(ref)
    ct_norm = norm(ct)
    # use first 6 significant words of the crossref title
    words = [w for w in ct_norm.split() if len(w) > 3][:6]
    hit = sum(1 for w in words if w in ref_norm)
    sim = hit / max(len(words), 1)
    # year: find the citation year in the reference (the year right after the authors, i.e. first 4-digit 19xx/20xx NOT in a title range)
    years = re.findall(r"\b(19\d{2}|20\d{2})\b", ref)
    ref_year = int(years[0]) if years else None
    year_ok = ref_year is None or cy is None or abs(ref_year - int(cy)) <= 1
    status = "OK" if (sim >= 0.8 and year_ok) else "CHECK"
    if status == "OK":
        ok.append(key)
    else:
        fail.append((key, doi, f"sim={sim:.2f} year_ref={ref_year} year_cr={cy}"))
    print(f"  {status:6s} {key:22s} {cy} | {venue[:34]:34s} | {ct[:52]}")

print(f"\nDOI-RESOLVED & MATCHED: {len(ok)}/{len(refs)} | no-DOI (books/reports): {len(nodoi)} | CHECK: {len(fail)}")
for k, d, why in fail:
    print("  ", k, d, why)
