import re
t = open('manuscript.md', encoding='utf-8').read()
body = t[:t.find('## FIGURE LEGENDS')]
cited = set()
for g in re.findall(r'\{([^}]+)\}', body):
    for k in g.split(','):
        cited.add(k.strip())
refs = set(re.findall(r'^\{([A-Za-z0-9]+)\}', t, re.M))
print('total refs:', len(refs), '| cited in body:', len(cited))
print('in refs but NOT cited:', sorted(refs - cited))
print('cited but NOT in refs:', sorted(cited - refs))
for frag in ['five complementary robustness', 'Five complementary', 'Figure 6', 'Figure 7',
             'Figure 8', 'Figure 9', 'Figure 10', 'Section 3.8', 'Section 3.9', 'Section 3.10']:
    if frag in t:
        print('STALE FOUND:', frag)
print('stale scan done')
body2 = t[t.find('## 1. INTRODUCTION'):t.find('## FIGURE LEGENDS')]
print('main text approx words:', len(re.findall(r'[A-Za-z0-9]+', body2)))
