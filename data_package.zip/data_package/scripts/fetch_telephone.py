"""Fetch fixed telephone subscriptions (IV for internet) from World Bank API.
Indicator: IT.TEL.SETS.P2 = fixed telephone subscriptions per 100 people.
Window: 1995-2000 average (predates the 2000-2015 internet window -> valid instrument).
"""
import json
import os
import time
import urllib.request

IND = "IT.MLT.MAIN.P2"
URL = ("https://api.worldbank.org/v2/country/all/indicator/%s"
       "?format=json&per_page=20000" % IND)

os.makedirs("data", exist_ok=True)
out_path = "data/wdi_fixed_telephone.json"

print("fetching", URL)
for attempt in range(3):
    try:
        with urllib.request.urlopen(URL, timeout=90) as r:
            payload = json.loads(r.read().decode("utf-8"))
        break
    except Exception as e:
        print("attempt", attempt + 1, "failed:", e)
        time.sleep(3)
else:
    raise SystemExit("fetch failed")

assert payload and len(payload) == 2, "unexpected payload shape"
meta, rows = payload[0], payload[1]
print("meta:", meta)
print("rows:", len(rows))

# normalize into {iso3: {year: value}}
panel = {}
for row in rows:
    iso = row.get("countryiso3code") or (row.get("country") or {}).get("id")
    if not iso or len(iso) != 3:
        continue
    val = row.get("value")
    yr = row.get("date")
    if val is None:
        continue
    panel.setdefault(iso, {})[int(yr)] = float(val)

json.dump(panel, open(out_path, "w", encoding="utf-8"), indent=0)
print("countries with data:", len(panel))
print("saved", out_path)
# quick sanity: USA / CHN / VNM
for iso in ["USA", "CHN", "VNM", "KOR", "IND"]:
    if iso in panel:
        ys = panel[iso]
        sample = {y: round(v, 2) for y, v in sorted(ys.items()) if y in (1995, 2000)}
        print(iso, sample)
