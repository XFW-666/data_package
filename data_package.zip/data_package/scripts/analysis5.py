"""Analysis v5: panel first-differences, common-sample R2, extra descriptives for text/figures."""
import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

pd.set_option("display.width", 220); pd.set_option("display.max_columns", 60)
panel = pd.read_csv("data/master_panel.csv")
countries = json.load(open("data/countries.json", encoding="utf-8"))
meta = pd.DataFrame([
    {"iso3": k, "country": v["name"], "region": v["region"], "income": v["income"]}
    for k, v in countries.items() if not v["is_aggregate"]
])
meta["income_group"] = meta.income.map({
    "High income": "High", "Upper middle income": "Upper-middle",
    "Lower middle income": "Lower-middle", "Low income": "Low"})
out = {}

def avg_window(df, var, y0, y1):
    sub = df[(df.year >= y0) & (df.year <= y1)]
    return sub.groupby("iso3")[var].mean()

# ---------------- common-sample comparison of M1 vs M3
X = pd.read_csv("data/xsec_hlo_main.csv")
need = ["hlo", "log_gdp_pc", "edu_exp_gdp_avg", "exp_prim_pc_avg", "exp_sec_pc_avg", "ptr_avg", "trained_teachers_avg", "internet_avg"]
Xc = X.dropna(subset=need)
m1c = smf.ols("hlo ~ log_gdp_pc", Xc).fit(cov_type="HC1")
m3c = smf.ols("hlo ~ log_gdp_pc + edu_exp_gdp_avg + exp_prim_pc_avg + exp_sec_pc_avg + ptr_avg + trained_teachers_avg + internet_avg", Xc).fit(cov_type="HC1")
m5c = smf.ols("hlo ~ internet_avg", Xc).fit(cov_type="HC1")
print("common sample N=%d: M1 R2=%.3f | M3 R2=%.3f | internet-only R2=%.3f" % (
    len(Xc), m1c.rsquared, m3c.rsquared, m5c.rsquared))
out["common_n"] = int(len(Xc)); out["common_m1_r2"] = float(m1c.rsquared)
out["common_m3_r2"] = float(m3c.rsquared); out["common_m5_r2"] = float(m5c.rsquared)

# partial R2 of adding internet
ss_full = m3c.ssr; ss_red = m1c.ssr
print("partial R2 from internet: %.3f" % ((ss_red - ss_full) / ss_red))
out["partial_r2_internet"] = float((ss_red - ss_full) / ss_red)

# ---------------- EdStats panel: first differences 2000->2005 and 2005->2010
es = panel[["iso3", "year", "edstats_score"]].dropna()
es = es[es.iso3.isin(set(meta.iso3))]
def wave_df(wave):
    d = es[es.year == wave][["iso3", "edstats_score"]].copy()
    for c in ["internet", "gdp_pc", "edu_exp_gdp", "ptr", "trained_teachers"]:
        d = d.merge(avg_window(panel, c, wave - 5, wave - 1).rename(f"{c}_avg"), on="iso3", how="left")
    d["year"] = wave
    d["log_gdp_pc"] = np.log10(d["gdp_pc_avg"])
    return d
w0, w1 = wave_df(2005), wave_df(2010)
FD = w0.merge(w1, on="iso3", suffixes=("_0", "_1"))
FD["d_score"] = FD.edstats_score_1 - FD.edstats_score_0
for c in ["internet", "edu_exp_gdp", "ptr", "trained_teachers"]:
    FD[f"d_{c}"] = FD[f"{c}_avg_1"] - FD[f"{c}_avg_0"]
FD["d_log_gdp_pc"] = FD["log_gdp_pc_1"] - FD["log_gdp_pc_0"]
print("\nEdStats FD 2005->2010: N=%d, mean d_score=%.2f" % (len(FD), FD.d_score.mean()))
out["fd_n"] = int(len(FD)); out["fd_mean_dscore"] = float(FD.d_score.mean())
fdm = smf.ols("d_score ~ d_internet + d_log_gdp_pc + d_edu_exp_gdp + d_ptr + d_trained_teachers", FD).fit(cov_type="HC1")
print(fdm.summary().tables[1])
out["fd_r2"] = float(fdm.rsquared)

# also 2000->2005 (predictors too sparse; skip)
out["fd2_n"] = 0
FD.to_csv("data/edstats_fd.csv", index=False)

# ---------------- descriptives for text
# population-weighted internet growth
pop = panel[panel.year.isin([2000, 2010, 2019])][["iso3", "year", "internet", "pop"]].dropna(subset=["internet"])
pop = pop[pop.iso3.isin(set(meta.iso3))]
for y in [2000, 2010, 2019]:
    sub = pop[pop.year == y]
    w = np.average(sub.internet, weights=sub["pop"])
    print("pop-weighted internet %d: %.1f%% (n=%d countries)" % (y, w, len(sub)))
    out[f"internet_w_{y}"] = float(w)

# education expenditure % GDP by income group (2000-2015 avg, pop-weighted)
ex = panel[(panel.year >= 2000) & (panel.year <= 2015)][["iso3", "year", "edu_exp_gdp", "pop"]].dropna(subset=["edu_exp_gdp"])
ex = ex.merge(meta[["iso3", "income_group"]], on="iso3", how="left")
for g, d in ex.groupby("income_group"):
    w = np.average(d.edu_exp_gdp, weights=d["pop"])
    print("edu exp %%GDP %s: %.2f%% (n=%d)" % (g, w, len(d)))
    out[f"exp_gdp_{g}"] = float(w)

# HLO by income group
h = panel[panel.year == 2017][["iso3", "hlo"]].dropna().merge(meta[["iso3", "income_group", "region"]], on="iso3", how="left")
print("\nHLO by income group:\n", h.groupby("income_group").hlo.agg(["count", "mean", "std"]).round(1))
print("\nHLO by region:\n", h.groupby("region").hlo.agg(["count", "mean", "std"]).round(1))
out["hlo_by_income"] = h.groupby("income_group").hlo.mean().round(1).to_dict()
out["hlo_by_region"] = h.groupby("region").hlo.mean().round(1).to_dict()

# learning poverty by income group (latest)
L = pd.read_csv("data/lp_latest.csv")
L = L[L.iso3.isin(set(meta.iso3))]
if "income_group" not in L.columns:
    L = L.merge(meta[["iso3", "income_group", "region"]], on="iso3", how="left")
print("\nLP latest by income group:\n", L.groupby("income_group").lp.agg(["count", "mean"]).round(1))
out["lp_by_income"] = L.groupby("income_group").lp.mean().round(1).to_dict()

# LP population-weighted share learning poor in LMICs (latest estimate, pop at estimate year)
lpw = []
for _, r in L.iterrows():
    p = panel[(panel.iso3 == r.iso3) & (panel.year == int(r.lp_year))]["pop"]
    p = p.iloc[0] if len(p) else np.nan
    lpw.append(p)
L["pop_at_est"] = lpw
lm = L[L.income_group.isin(["Low", "Lower-middle", "Upper-middle"])].dropna(subset=["pop_at_est"])
w = np.average(lm.lp, weights=lm.pop_at_est)
print("\npop-weighted learning poverty in LMICs (latest estimates, n=%d): %.1f%%" % (len(lm), w))
out["lp_lmic_weighted"] = float(w); out["lp_lmic_n"] = int(len(lm))
hi = L[L.income_group == "High"].dropna(subset=["pop_at_est"])
w2 = np.average(hi.lp, weights=hi.pop_at_est)
print("pop-weighted learning poverty in high-income (n=%d): %.1f%%" % (len(hi), w2))
out["lp_hic_weighted"] = float(w2); out["lp_hic_n"] = int(len(hi))

# correlations with HLO (2000-2015 window) for figure/text
corr_vars = ["hlo", "log_gdp_pc", "edu_exp_gdp_avg", "exp_prim_pc_avg", "ptr_avg",
             "trained_teachers_avg", "internet_avg", "tertiary_avg", "gpi_sec_avg", "gini_avg", "rural_avg"]
C = X[corr_vars].corr()
print("\ncorrelation with HLO:\n", C["hlo"].round(3).to_string())
out["corr_hlo"] = {k: float(v) for k, v in C["hlo"].round(3).items()}
C.to_csv("data/corr_matrix.csv")

# internet convexity: fitted curve values
Xi = Xc.copy()
Xi["internet_sq"] = Xi.internet_avg ** 2
mi = smf.ols("hlo ~ log_gdp_pc + edu_exp_gdp_avg + exp_prim_pc_avg + exp_sec_pc_avg + ptr_avg + trained_teachers_avg + internet_avg + internet_sq", Xi).fit(cov_type="HC1")
print("\ninternet sq coef=%.4f p=%.4f" % (mi.params["internet_sq"], mi.pvalues["internet_sq"]))
out["internet_sq_coef"] = float(mi.params["internet_sq"]); out["internet_sq_p"] = float(mi.pvalues["internet_sq"])

# summary stats table data
summ_cols = {"hlo": "Harmonized learning outcome (HLO)", "log_gdp_pc": "log10 GDP per capita",
             "edu_exp_gdp_avg": "Education expenditure (% GDP)", "exp_prim_pc_avg": "Per-student primary spending (% GDP pc)",
             "ptr_avg": "Pupil-teacher ratio", "trained_teachers_avg": "Trained teachers (%)",
             "internet_avg": "Internet users (%)", "tertiary_avg": "Tertiary enrollment (%)",
             "gpi_sec_avg": "Gender parity index (secondary)", "gini_avg": "Gini index", "rural_avg": "Rural population (%)"}
rows = []
for c, lab in summ_cols.items():
    s = Xc[c].dropna()
    rows.append({"var": lab, "n": len(s), "mean": s.mean(), "sd": s.std(), "min": s.min(), "max": s.max()})
S = pd.DataFrame(rows)
print("\n", S.round(2).to_string(index=False))
S.to_csv("data/summary_stats.csv", index=False)

json.dump(out, open("data/analysis_out5.json", "w"), indent=1)
print("\nsaved v5.")
