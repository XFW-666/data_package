"""Final pre-submission compliance checklist."""
import re
from docx import Document
from docx.oxml.ns import qn

t = open("manuscript.md", encoding="utf-8").read()
checks = []
def chk(name, ok, detail=""):
    checks.append((name, bool(ok), detail))

# ---- Abstract
i, j = t.find("## ABSTRACT"), t.find("## KEYWORDS")
ab = t[i:j]
ab_words = len(re.findall(r"[A-Za-z0-9]+", ab)) - 1
chk("Abstract single paragraph (no subheadings)", "\n## " not in ab.replace("## ABSTRACT", ""), "")
chk("Abstract ≤ 350 words", ab_words <= 350, f"{ab_words} words")
chk("Abstract has no references/figures/tables cites", not re.search(r"\{|\[Figure|\[Table|Figure \d|Table \d", ab.replace("β", "")), "")

# ---- Keywords 5-8
i, j = t.find("## KEYWORDS"), t.find("## 1. INTRODUCTION")
kw = t[i:j].replace("## KEYWORDS", "").strip()
kws = [k.strip() for k in re.split(r"[;,]", kw) if k.strip()]
chk("Keywords 5-8", 5 <= len(kws) <= 8, f"{len(kws)} keywords")

# ---- Main text word count (Frontiers limit 12,000; excludes abstract/headings/captions/refs)
body = t[t.find("## 1. INTRODUCTION"):t.find("## FIGURE LEGENDS")]
# strip headings and table content
body_wo_heads = re.sub(r"^#{1,3} .*$", "", body, flags=re.M)
body_wo_tabs = re.sub(r"^\|.*$", "", body_wo_heads, flags=re.M)
main_words = len(re.findall(r"[A-Za-z0-9]+", body_wo_tabs))
chk("Main text ≤ 12,000 words", main_words <= 12000, f"~{main_words} words")

# ---- Sections (Original Research format)
for s in ["ABSTRACT", "1. INTRODUCTION", "2. MATERIALS AND METHODS", "3. RESULTS", "4. DISCUSSION"]:
    chk(f"Section present: {s}", s in t)
chk("Conclusion optional section present", "5. CONCLUSION" in t)

# ---- Declarations (Frontiers exact wording)
chk("Funding: no financial support wording", "no financial support was received" in t)
chk("Conflict of Interest: standard wording", "could be construed as a potential conflict of interest" in t)
chk("Data Availability Statement present", "## DATA AVAILABILITY STATEMENT" in t and "publicly available" in t)
chk("Ethics Statement present", "## ETHICS STATEMENT" in t)
chk("Author Contributions present (template)", "## AUTHOR CONTRIBUTIONS" in t and "XX contributed" in t)
chk("Author Contributions states all authors read/agreed", "All authors read and agreed" in t)
chk("Acknowledgments present", "## ACKNOWLEDGMENTS" in t)

# ---- First-page counts
chk("Word/figure/table count on first page", "Word count (main text)" in t and "Figures: 5 | Tables: 3" in t)

# ---- Figures & tables counts
n_fig = len(re.findall(r"\*\*FIGURE \d+\.\*\*", t))
n_tab = len(re.findall(r"\*\*TABLE \d+\.\*\*", t))
chk("5 figures", n_fig == 5, f"{n_fig}")
chk("3 tables", n_tab == 3, f"{n_tab}")

# ---- References
refkeys = set(re.findall(r"^\{([A-Za-z0-9]+)\}", t, re.M))
body_keys = set()
for g in re.findall(r"\{([^}]+)\}", t[:t.find("## FIGURE LEGENDS")]):
    for k in g.split(","):
        body_keys.add(k.strip())
chk("46 references", len(refkeys) == 46, f"{len(refkeys)}")
chk("All references cited in text", body_keys == refkeys, f"missing: {refkeys - body_keys}")
chk("All citations have reference entries", body_keys <= refkeys, f"orphan: {body_keys - refkeys}")

# ---- Figures/tables all cited in text
for i in range(1, 6):
    chk(f"Figure {i} cited", f"Figure {i}" in t[:t.find("## FIGURE LEGENDS")])
for i in range(1, 4):
    chk(f"Table {i} cited", f"Table {i}" in t[:t.find("## FIGURE LEGENDS")])

# ---- DOCX-specific features
d = Document("manuscript_frontiers.docx")
sec = d.sections[0]
chk("DOCX side margins per Frontiers template", abs(sec.left_margin.cm - 2.261) < 0.05 and abs(sec.right_margin.cm - 2.083) < 0.05,
    f"L={sec.left_margin.cm:.2f} R={sec.right_margin.cm:.2f}cm")
chk("DOCX single line spacing", d.styles["Normal"].paragraph_format.line_spacing == 1.0,
    str(d.styles["Normal"].paragraph_format.line_spacing))
# line numbers in sectPr XML
xml = sec._sectPr.xml
chk("DOCX line numbers enabled", "lnNumType" in xml)
imgs = sum(1 for rel in d.part.rels.values() if "image" in rel.reltype)
chk("DOCX 5 embedded images", imgs == 5, f"{imgs}")
chk("DOCX 3 tables", len(d.tables) == 3, f"{len(d.tables)}")
full = "\n".join(p.text for p in d.paragraphs)
chk("DOCX no leftover {cite} braces", not re.search(r"\{[A-Za-z0-9,]+\}", full))
chk("DOCX has word-count line (exactly once)", full.count("Word count (main text)") == 1)
chk("DOCX has Funding declaration", "no financial support was received" in full)
chk("DOCX has COI declaration", "potential conflict of interest" in full)
chk("DOCX has Data Availability", "data availability statement" in full.lower())
chk("DOCX has Ethics", "ethics statement" in full.lower())
chk("DOCX has Author Contributions template", "XX contributed" in full)
# ---- Title page elements (checked against the built DOCX)
chk("Article type on title page", "Article type: Original Research" in full)
chk("Running title placeholder", "Running title" in full)

# report
fails = [c for c in checks if not c[1]]
print(f"PRE-SUBMISSION CHECKLIST: {len(checks) - len(fails)}/{len(checks)} PASS | {len(fails)} FAIL")
for name, ok, detail in checks:
    status = "PASS" if ok else "FAIL"
    extra = f"  ({detail})" if detail else ""
    print(f"  [{status}] {name}{extra}")
