"""Download Natural Earth 50m countries GeoJSON; build ISO3->feature mapping."""
import json, urllib.request, gzip
import pandas as pd

URL = "https://raw.githubusercontent.com/nvkelso/natural-earth-vector/master/geojson/ne_50m_admin_0_countries.geojson"
req = urllib.request.Request(URL, headers={"User-Agent": "Mozilla/5.0 (research)"})
with urllib.request.urlopen(req, timeout=600) as r:
    data = r.read()
if data[:2] == b"\x1f\x8b":
    data = gzip.decompress(data)
gj = json.loads(data.decode("utf-8"))
print("50m features:", len(gj["features"]))

panel = pd.read_csv("data/master_panel.csv")
hlo = panel[panel.year == 2017][["iso3", "hlo"]].dropna()
have = set(hlo.iso3)

# build mapping with fallbacks: ISO_A3, ADM0_A3, GU_A3, SU_A3, SOV_A3, BRK_A3
iso_map = {}
for f in gj["features"]:
    p = f["properties"]
    name = p.get("NAME") or p.get("ADMIN")
    for key in ["ISO_A3", "ADM0_A3", "GU_A3", "SU_A3", "SOV_A3", "BRK_A3"]:
        v = p.get(key)
        if v and v != "-99" and len(v) == 3:
            iso_map.setdefault(v, name)
missing = [c for c in sorted(have) if c not in iso_map]
print("HLO countries:", len(have), "| still missing:", missing)
for c in missing:
    # find candidate by name search
    cands = [f["properties"].get("NAME") for f in gj["features"]
             if any(str(f["properties"].get(k, "")).find(c) >= 0 for k in [])]
    print("  ", c, "-> no geometry match")

json.dump(gj, open("data/ne50_countries.geojson", "w", encoding="utf-8"))
print("saved data/ne50_countries.geojson")
