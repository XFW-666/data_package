import json, glob, os
import pandas as pd

countries = json.load(open("data/countries.json", encoding="utf-8"))
real = {k: v for k, v in countries.items() if not v["is_aggregate"]}

FILES = {
    "hlo": "data/hlo_scores.json",
    "hlo_female": "data/hlo_scores_female.json",
    "hlo_male": "data/hlo_scores_male.json",
    "lays": "data/lays.json",
    "lp": "data/lp_total.json",
    "lp_female": "data/lp_female.json",
    "lp_male": "data/lp_male.json",
    "lp_oos": "data/lp_outofschool.json",
    "edstats_score": "data/edstats_AED.PRSC.MEAN.json",
    "edu_exp_gdp": "data/wdi_edu_exp_gdp.json",
    "exp_prim_pc": "data/wdi_exp_per_student_prim.json",
    "exp_sec_pc": "data/wdi_exp_per_student_sec.json",
    "exp_tert_pc": "data/wdi_exp_per_student_tert.json",
    "ptr": "data/wdi_ptr_primary.json",
    "trained_teachers": "data/wdi_trained_teachers_prim.json",
    "internet": "data/wdi_internet_users.json",
    "broadband": "data/wdi_broadband.json",
    "mobile": "data/wdi_mobile.json",
    "gdp_pc": "data/wdi_gdp_pc_ppp.json",
    "gdp_pc_usd": "data/wdi_gdp_pc_usd.json",
    "tertiary": "data/wdi_tertiary_enroll.json",
    "gpi_prim": "data/wdi_gpi_primary.json",
    "gpi_sec": "data/wdi_gpi_secondary.json",
    "pop": "data/wdi_population.json",
    "rural": "data/wdi_rural.json",
    "enroll_prim": "data/wdi_enroll_prim.json",
    "enroll_sec": "data/wdi_enroll_sec.json",
    "gini": "data/wdi_gini.json",
}

frames = []
for name, path in FILES.items():
    if not os.path.exists(path):
        print("MISSING", path)
        continue
    rows = json.load(open(path, encoding="utf-8"))
    recs = []
    for r in rows:
        iso = r.get("countryiso3code")
        if not iso or iso not in real:
            continue
        if r["value"] is None:
            continue
        recs.append({"iso3": iso, "year": int(r["date"]), name: r["value"]})
    frames.append(pd.DataFrame(recs))

panel = frames[0]
for f in frames[1:]:
    panel = panel.merge(f, on=["iso3", "year"], how="outer")

panel = panel.sort_values(["iso3", "year"]).reset_index(drop=True)
panel.to_csv("data/master_panel.csv", index=False)
print("panel shape:", panel.shape)
print("years:", panel.year.min(), "-", panel.year.max())

summ = []
for c in panel.columns:
    if c in ("iso3", "year"):
        continue
    sub = panel[["iso3", "year", c]].dropna()
    summ.append({
        "var": c,
        "n": len(sub),
        "countries": sub.iso3.nunique(),
        "y0": int(sub.year.min()),
        "y1": int(sub.year.max()),
    })
s = pd.DataFrame(summ).sort_values("n", ascending=False)
print(s.to_string(index=False))
