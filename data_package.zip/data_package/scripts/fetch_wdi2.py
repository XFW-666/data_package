import json, os, time, urllib.request, sys

INDICATORS = {
    "tertiary_enroll": "SE.TER.ENRR",
    "gpi_primary": "SE.ENR.PRIM.FM.ZS",
    "gpi_secondary": "SE.ENR.SECO.FM.ZS",
    "population": "SP.POP.TOTL",
}

def fetch_indicator(code):
    rows = []
    page = 1
    while True:
        url = (f"https://api.worldbank.org/v2/country/all/indicator/{code}"
               f"?format=json&per_page=5000&page={page}&date=1995:2024")
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (research script)"})
        with urllib.request.urlopen(req, timeout=60) as r:
            d = json.loads(r.read().decode("utf-8"))
        meta, recs = d[0], d[1]
        rows.extend(recs)
        print(code, "page", page, "of", meta["pages"], "records", len(recs), flush=True)
        if page >= meta["pages"]:
            break
        page += 1
    return rows

for name, code in INDICATORS.items():
    try:
        rows = fetch_indicator(code)
        with open(f"data/wdi_{name}.json", "w", encoding="utf-8") as f:
            json.dump(rows, f, ensure_ascii=False)
        print("SAVED", name, len(rows), flush=True)
    except Exception as e:
        print("FAIL", name, repr(e), flush=True)
