import json, os, time, urllib.request

JOBS = [
    ("data/hlo_scores.json", 12, "HD.HCI.HLOS", "1995:2024"),
    ("data/hlo_scores_female.json", 12, "HD.HCI.HLOS.FE", "1995:2024"),
    ("data/hlo_scores_male.json", 12, "HD.HCI.HLOS.MA", "1995:2024"),
    ("data/lays.json", 12, "HD.HCI.LAYS", "1995:2024"),
    ("data/lp_total.json", 2, "SE.LPV.PRIM", "1995:2024"),
    ("data/lp_female.json", 2, "SE.LPV.PRIM.FE", "1995:2024"),
    ("data/lp_male.json", 2, "SE.LPV.PRIM.MA", "1995:2024"),
    ("data/lp_outofschool.json", 2, "SE.LPV.PRIM.SD", "1995:2024"),
    ("data/wdi_broadband.json", 2, "IT.NET.BBND.P2", "1995:2024"),
    ("data/wdi_mobile.json", 2, "IT.CEL.SETS.P2", "1995:2024"),
]

def fetch(src, code, date):
    rows, page = [], 1
    while True:
        url = (f"https://api.worldbank.org/v2/country/all/indicator/{code}"
               f"?format=json&per_page=5000&page={page}&date={date}&source={src}")
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (research)"})
        with urllib.request.urlopen(req, timeout=90) as r:
            d = json.loads(r.read().decode("utf-8"))
        meta, recs = d[0], d[1]
        rows.extend(recs)
        print(code, "page", page, "/", meta["pages"], "records", len(recs), flush=True)
        if page >= meta["pages"]:
            break
        page += 1
    return rows

for path, src, code, date in JOBS:
    try:
        rows = fetch(src, code, date)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(rows, f, ensure_ascii=False)
        print("SAVED", path, len(rows), flush=True)
    except Exception as e:
        print("FAIL", code, repr(e)[:200], flush=True)
