"""Fit FD models with honest sample sizes; pick a defensible specification."""
import pandas as pd
import statsmodels.formula.api as smf

FD = pd.read_csv("data/edstats_fd.csv")
print("FD rows:", len(FD))
specs = [
    ("with GDP (original)", "d_score ~ d_internet + d_log_gdp_pc + d_edu_exp_gdp + d_ptr + d_trained_teachers"),
    ("no GDP", "d_score ~ d_internet + d_edu_exp_gdp + d_ptr + d_trained_teachers"),
    ("internet + edu exp", "d_score ~ d_internet + d_edu_exp_gdp"),
    ("internet + trained", "d_score ~ d_internet + d_trained_teachers"),
    ("internet + edu + ptr", "d_score ~ d_internet + d_edu_exp_gdp + d_ptr"),
    ("internet only", "d_score ~ d_internet"),
]
for lab, f in specs:
    need = [v.strip() for v in f.split("~")[1].split("+")]
    d = FD.dropna(subset=need)
    if len(d) < 10:
        print(f"{lab:24s} N={len(d):3d}  (too small)")
        continue
    m = smf.ols(f, d).fit(cov_type="HC1")
    terms = [t for t in m.params.index if t != "Intercept"]
    coefs = "  ".join(f"{t.replace('d_','')}={m.params[t]:+.3f}(p={m.pvalues[t]:.3f})" for t in terms)
    print(f"{lab:24s} N={int(m.nobs):3d} R2={m.rsquared:.3f}  {coefs}")
