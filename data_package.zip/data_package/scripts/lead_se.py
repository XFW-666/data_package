"""Recompute lead-window models and report SEs precisely."""
import json
import numpy as np
import pandas as pd
import statsmodels.formula.api as smf

panel = pd.read_csv("data/master_panel.csv")
countries = json.load(open("data/countries.json", encoding="utf-8"))
meta = pd.DataFrame([{"iso3": k, "region": v["region"].strip(), "income": v["income"]}
                     for k, v in countries.items() if not v["is_aggregate"]])

def build(y0, y1):
    d = panel[panel.year == 2017][["iso3", "hlo"]].dropna()
    for c in ["internet", "gdp_pc", "exp_prim_pc", "edu_exp_gdp", "ptr", "trained_teachers"]:
        d = d.merge(panel[(panel.year >= y0) & (panel.year <= y1)].groupby("iso3")[c].mean().rename(f"{c}_avg"), on="iso3", how="left")
    d["log_gdp_pc"] = np.log10(d["gdp_pc_avg"])
    return d

out = {}
for (y0, y1, lab) in [(2016, 2018, "2016-2018"), (2016, 2022, "2016-2022")]:
    d = build(y0, y1)
    need = ["hlo", "log_gdp_pc", "internet_avg", "exp_prim_pc_avg", "edu_exp_gdp_avg", "ptr_avg", "trained_teachers_avg"]
    dd = d.dropna(subset=need)
    m = smf.ols("hlo ~ log_gdp_pc + edu_exp_gdp_avg + exp_prim_pc_avg + ptr_avg + trained_teachers_avg + internet_avg", dd).fit(cov_type="HC1")
    out[lab] = {"n": int(m.nobs), "coef": float(m.params["internet_avg"]), "se": float(m.bse["internet_avg"]),
                "p": float(m.pvalues["internet_avg"])}
    print(lab, "coef=%.3f se=%.3f p=%.4f N=%d" % (m.params["internet_avg"], m.bse["internet_avg"], m.pvalues["internet_avg"], m.nobs))

json.dump(out, open("data/lead_placebo_se.json", "w"), indent=1)
