"""Analysis v3: panel FE, learning poverty, gender, heterogeneity, efficiency, alt interactions."""
import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

pd.set_option("display.width", 220); pd.set_option("display.max_columns", 60)

panel = pd.read_csv("data/master_panel.csv")
countries = json.load(open("data/countries.json", encoding="utf-8"))
meta = pd.DataFrame([
    {"iso3": k, "country": v["name"], "region": v["region"], "income": v["income"]}
    for k, v in countries.items() if not v["is_aggregate"]
])
meta["income_group"] = meta.income.map({
    "High income": "High", "Upper middle income": "Upper-middle",
    "Lower middle income": "Lower-middle", "Low income": "Low"})

out = {}

def avg_window(df, var, y0, y1):
    sub = df[(df.year >= y0) & (df.year <= y1)]
    return sub.groupby("iso3")[var].mean()

# ================================================================ 1. PANEL: EdStats scores 2000-2010, country FE
rows = []
for wave in [2000, 2005, 2010]:
    d = panel[panel.year == wave][["iso3", "edstats_score"]].dropna()
    for c in ["edu_exp_gdp", "exp_prim_pc", "ptr", "trained_teachers", "internet",
              "gdp_pc", "tertiary"]:
        d = d.merge(avg_window(panel, c, wave - 5, wave - 1).rename(f"{c}_avg"), on="iso3", how="left")
    d["year"] = wave
    d["log_gdp_pc"] = np.log10(d["gdp_pc_avg"])
    rows.append(d)
P = pd.concat(rows).merge(meta, on="iso3", how="left")
P = P.dropna(subset=["edstats_score", "log_gdp_pc", "internet_avg", "exp_prim_pc_avg"])
print("panel rows:", len(P), "countries:", P.iso3.nunique())
print(P.groupby("year").agg(n=("iso3", "size"), countries=("iso3", "nunique")))

P1d = P.dropna(subset=["edstats_score", "log_gdp_pc"])
p1 = smf.ols("edstats_score ~ log_gdp_pc + C(year)", data=P1d).fit(cov_type="cluster", cov_kwds={"groups": P1d.iso3})
P2d = P.dropna(subset=["edstats_score", "log_gdp_pc", "edu_exp_gdp_avg", "exp_prim_pc_avg", "ptr_avg", "trained_teachers_avg", "internet_avg"])
p2 = smf.ols("edstats_score ~ log_gdp_pc + edu_exp_gdp_avg + exp_prim_pc_avg + ptr_avg + trained_teachers_avg + internet_avg + C(year)", data=P2d).fit(cov_type="cluster", cov_kwds={"groups": P2d.iso3})
P3d = P2d.dropna(subset=["tertiary_avg"])
p3 = smf.ols("edstats_score ~ log_gdp_pc + edu_exp_gdp_avg + exp_prim_pc_avg + ptr_avg + trained_teachers_avg + internet_avg + tertiary_avg + C(year) + C(iso3)", data=P3d).fit(cov_type="cluster", cov_kwds={"groups": P3d.iso3})
print("\nP1 (pooled, year FE): R2=%.3f N=%d" % (p1.rsquared, int(p1.nobs)))
print(p1.params.round(3).to_string())
print("\nP2 (pooled, year FE): R2=%.3f N=%d" % (p2.rsquared, int(p2.nobs)))
print(p2.params.round(3).to_string())
print("\nP3 (country FE + year FE): R2=%.3f N=%d" % (p3.rsquared, int(p3.nobs)))
print(p3.params.round(3).to_string())
out["panel_n"] = int(p2.nobs); out["panel_countries"] = int(P.iso3.nunique())
out["panel_p2_r2"] = float(p2.rsquared); out["panel_p3_r2"] = float(p3.rsquared)
out["panel_p3_n"] = int(p3.nobs)

# ================================================================ 2. LEARNING POVERTY (latest estimate per country)
lp = panel[["iso3", "year", "lp", "lp_female", "lp_male"]].dropna(subset=["lp"])
lp = lp[lp.iso3.isin(set(meta.iso3))]
latest = lp.sort_values("year").groupby("iso3").tail(1).rename(columns={"year": "lp_year"})
print("\nLP latest: n=%d, mean=%.1f" % (len(latest), latest.lp.mean()))
out["lp_latest_n"] = len(latest); out["lp_latest_mean"] = float(latest.lp.mean())
out["lp_latest_share50"] = float(100 * (latest.lp > 50).mean())

L = latest.copy()
for c in ["edu_exp_gdp", "exp_prim_pc", "ptr", "trained_teachers", "internet",
          "gdp_pc", "tertiary", "gpi_sec", "rural"]:
    w = L.apply(lambda r: avg_window(panel, c, int(r.lp_year) - 10, int(r.lp_year) - 1).get(r.iso3, np.nan), axis=1)
    L[f"{c}_avg"] = w
L["log_gdp_pc"] = np.log10(L["gdp_pc_avg"])
L = L.merge(meta, on="iso3", how="left")
L.to_csv("data/lp_latest.csv", index=False)

l1 = smf.ols("lp ~ log_gdp_pc", L).fit(cov_type="HC1")
l2 = smf.ols("lp ~ log_gdp_pc + edu_exp_gdp_avg + exp_prim_pc_avg + ptr_avg + trained_teachers_avg + internet_avg", L).fit(cov_type="HC1")
l3 = smf.ols("lp ~ log_gdp_pc + edu_exp_gdp_avg + exp_prim_pc_avg + ptr_avg + trained_teachers_avg + internet_avg + tertiary_avg + gpi_sec_avg + rural_avg", L).fit(cov_type="HC1")
print("\nLP models:")
for nm, m in [("L1", l1), ("L2", l2), ("L3", l3)]:
    print("%s R2=%.3f N=%d" % (nm, m.rsquared, int(m.nobs)))
    print(m.params.round(3).to_string(), "\n")
out["lp_l1_r2"], out["lp_l2_r2"], out["lp_l3_r2"] = l1.rsquared, l2.rsquared, l3.rsquared
out["lp_l2_n"], out["lp_l3_n"] = int(l2.nobs), int(l3.nobs)

# ================================================================ 3. GENDER analysis
G = panel[panel.year == 2017][["iso3", "hlo_female", "hlo_male", "hlo"]].dropna(subset=["hlo_female"])
G["gap"] = G.hlo_female - G.hlo_male
print("\nHLO gender gap: n=%d, mean=%.2f, sd=%.2f, min=%.1f, max=%.1f" % (
    len(G), G.gap.mean(), G.gap.std(), G.gap.min(), G.gap.max()))
out["gap_n"] = len(G); out["gap_mean"] = float(G.gap.mean()); out["gap_sd"] = float(G.gap.std())
out["gap_min"] = float(G.gap.min()); out["gap_max"] = float(G.gap.max())
neg = G[G.gap < 0].merge(meta, on="iso3")
print("countries with female gap (F<M):", len(neg))
print(neg.sort_values("gap").head(10)[["country", "gap"]].to_string(index=False))
out["n_female_advantage"] = len(neg)

for c in ["gpi_sec", "gpi_prim", "internet", "edu_exp_gdp", "exp_prim_pc", "gdp_pc", "tertiary", "trained_teachers"]:
    G = G.merge(avg_window(panel, c, 2000, 2015).rename(f"{c}_avg"), on="iso3", how="left")
G["log_gdp_pc"] = np.log10(G["gdp_pc_avg"])
g1 = smf.ols("gap ~ log_gdp_pc + gpi_sec_avg + gpi_prim_avg + internet_avg + edu_exp_gdp_avg + exp_prim_pc_avg + tertiary_avg", G).fit(cov_type="HC1")
print("\ngap model R2=%.3f N=%d" % (g1.rsquared, int(g1.nobs)))
print(g1.params.round(3).to_string())
out["gap_model_r2"] = float(g1.rsquared); out["gap_model_n"] = int(g1.nobs)

# LP gender gap
Lg = L.dropna(subset=["lp_female", "lp_male"]).copy()
Lg["lp_gap"] = Lg.lp_male - Lg.lp_female
print("\nLP gender gap (M-F): n=%d, mean=%.2f, share M>F: %.1f%%" % (
    len(Lg), Lg.lp_gap.mean(), 100 * (Lg.lp_gap > 0).mean()))
out["lp_gap_n"] = len(Lg); out["lp_gap_mean"] = float(Lg.lp_gap.mean())
out["lp_gap_share_male_higher"] = float(100 * (Lg.lp_gap > 0).mean())

# ================================================================ 4. HETEROGENEITY by income group (HLO M3 spec)
X = pd.read_csv("data/xsec_hlo_main.csv")
f3 = "hlo ~ log_gdp_pc + edu_exp_gdp_avg + exp_prim_pc_avg + exp_sec_pc_avg + ptr_avg + trained_teachers_avg + internet_avg"
need = ["hlo", "log_gdp_pc", "edu_exp_gdp_avg", "exp_prim_pc_avg", "exp_sec_pc_avg", "ptr_avg", "trained_teachers_avg", "internet_avg"]
het = {}
for grp in ["High", "Upper-middle", "Lower-middle", "Low"]:
    d = X[(X.income_group == grp)].dropna(subset=need)
    if len(d) < 15:
        print("skip", grp, len(d)); continue
    m = smf.ols(f3, d).fit(cov_type="HC1")
    print("\n--- %s (N=%d) R2=%.3f ---" % (grp, len(d), m.rsquared))
    print(m.params.round(3).to_string())
    het[grp] = {"n": int(m.nobs), "r2": float(m.rsquared),
                "params": {k: float(v) for k, v in m.params.items()},
                "pvalues": {k: float(v) for k, v in m.pvalues.items()}}
out["heterogeneity_income"] = het

# by region
het_r = {}
for reg, d in X.dropna(subset=need).groupby("region"):
    if len(d) < 15:
        continue
    m = smf.ols(f3, d).fit(cov_type="HC1")
    print("\n--- %s (N=%d) R2=%.3f ---" % (reg, len(d), m.rsquared))
    print(m.params.round(3).to_string())
    het_r[reg] = {"n": int(m.nobs), "r2": float(m.rsquared),
                  "params": {k: float(v) for k, v in m.params.items()},
                  "pvalues": {k: float(v) for k, v in m.pvalues.items()}}
out["heterogeneity_region"] = het_r

# ================================================================ 5. EFFICIENCY: over/under performance vs GDP
Xd = X.dropna(subset=["hlo", "log_gdp_pc"]).copy()
mres = smf.ols("hlo ~ log_gdp_pc", Xd).fit()
Xd["resid_gdp"] = mres.resid
Xd = Xd.sort_values("resid_gdp", ascending=False)
print("\nTop 12 over-performers (vs GDP):")
print(Xd.head(12)[["country", "income_group", "hlo", "log_gdp_pc", "resid_gdp", "edu_exp_gdp_avg", "exp_prim_pc_avg", "internet_avg"]].round(2).to_string(index=False))
print("\nBottom 12 under-performers:")
print(Xd.tail(12)[["country", "income_group", "hlo", "log_gdp_pc", "resid_gdp", "edu_exp_gdp_avg", "exp_prim_pc_avg", "internet_avg"]].round(2).to_string(index=False))
out["top_over"] = Xd.head(12)[["country", "hlo", "resid_gdp", "edu_exp_gdp_avg", "exp_prim_pc_avg", "internet_avg"]].round(2).to_dict("records")
out["bottom_under"] = Xd.tail(12)[["country", "hlo", "resid_gdp", "edu_exp_gdp_avg", "exp_prim_pc_avg", "internet_avg"]].round(2).to_dict("records")

# residual vs spending correlation
sub = Xd.dropna(subset=["edu_exp_gdp_avg", "exp_prim_pc_avg", "internet_avg"])
print("\ncorr(resid_gdp, exp_gdp)=%.3f  corr(resid_gdp, exp_prim)=%.3f  corr(resid_gdp, internet)=%.3f  corr(resid_gdp, ptr)=%.3f" % (
    sub.resid_gdp.corr(sub.edu_exp_gdp_avg), sub.resid_gdp.corr(sub.exp_prim_pc_avg),
    sub.resid_gdp.corr(sub.internet_avg), sub.resid_gdp.corr(sub.ptr_avg)))
out["corr_resid_expgdp"] = float(sub.resid_gdp.corr(sub.edu_exp_gdp_avg))
out["corr_resid_expprim"] = float(sub.resid_gdp.corr(sub.exp_prim_pc_avg))
out["corr_resid_internet"] = float(sub.resid_gdp.corr(sub.internet_avg))
out["corr_resid_ptr"] = float(sub.resid_gdp.corr(sub.ptr_avg))
Xd.to_csv("data/hlo_efficiency.csv", index=False)

# ================================================================ 6. Alternative interactions
Xi = X.dropna(subset=need).copy()
Xi["int_x_gdp"] = Xi.internet_avg * Xi.log_gdp_pc
mi2 = smf.ols("hlo ~ log_gdp_pc + edu_exp_gdp_avg + exp_prim_pc_avg + exp_sec_pc_avg + ptr_avg + trained_teachers_avg + internet_avg + int_x_gdp", Xi).fit(cov_type="HC1")
print("\ninternet x log_gdp:", mi2.params.get("int_x_gdp"), "p=", mi2.pvalues.get("int_x_gdp"))
out["int_x_gdp"] = [float(mi2.params.get("int_x_gdp", np.nan)), float(mi2.pvalues.get("int_x_gdp", np.nan))]

Xi["exp_x_teach"] = Xi.exp_prim_pc_avg * Xi.trained_teachers_avg / 100.0
mi3 = smf.ols("hlo ~ log_gdp_pc + edu_exp_gdp_avg + exp_prim_pc_avg + exp_sec_pc_avg + ptr_avg + trained_teachers_avg + internet_avg + exp_x_teach", Xi).fit(cov_type="HC1")
print("exp x trained_teachers:", mi3.params.get("exp_x_teach"), "p=", mi3.pvalues.get("exp_x_teach"))
out["exp_x_teach"] = [float(mi3.params.get("exp_x_teach", np.nan)), float(mi3.pvalues.get("exp_x_teach", np.nan))]

# internet quadratic (diminishing returns)
Xi["internet_sq"] = Xi.internet_avg ** 2
mi4 = smf.ols("hlo ~ log_gdp_pc + edu_exp_gdp_avg + exp_prim_pc_avg + exp_sec_pc_avg + ptr_avg + trained_teachers_avg + internet_avg + internet_sq", Xi).fit(cov_type="HC1")
print("internet sq:", mi4.params.get("internet_sq"), "p=", mi4.pvalues.get("internet_sq"))
out["internet_sq"] = [float(mi4.params.get("internet_sq", np.nan)), float(mi4.pvalues.get("internet_sq", np.nan))]

# low-income-only digital effect (is digital a bigger deal where resources are scarce?)
low = Xi[Xi.income_group.isin(["Low", "Lower-middle"])]
hi = Xi[Xi.income_group == "High"]
for nm, d in [("Low+Lower-middle", low), ("High", hi)]:
    if len(d) > 15:
        m = smf.ols("hlo ~ log_gdp_pc + edu_exp_gdp_avg + exp_prim_pc_avg + exp_sec_pc_avg + ptr_avg + trained_teachers_avg + internet_avg", d).fit(cov_type="HC1")
        print("\n%s: N=%d internet coef=%.3f (p=%.4f) exp_prim=%.3f (p=%.4f)" % (
            nm, len(d), m.params["internet_avg"], m.pvalues["internet_avg"],
            m.params["exp_prim_pc_avg"], m.pvalues["exp_prim_pc_avg"]))
        out[f"internet_coef_{nm}"] = [float(m.params["internet_avg"]), float(m.pvalues["internet_avg"])]
        out[f"expprim_coef_{nm}"] = [float(m.params["exp_prim_pc_avg"]), float(m.pvalues["exp_prim_pc_avg"])]

json.dump(out, open("data/analysis_out3.json", "w"), indent=1)
print("\nsaved v3.")
