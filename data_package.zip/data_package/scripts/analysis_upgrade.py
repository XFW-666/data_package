"""Upgrade analyses to Q1 standards:
1. Shapley value decomposition of R^2
2. Specification curve analysis
3. Oster (2019) bounds for selection on unobservables
4. Leave-one-region-out jackknife
5. Temporal falsification (lead-window placebo)
6. Quantile regression
7. Beta/sigma convergence (EdStats panel)
8. Random forest vs OLS predictive comparison
9. Bootstrap CIs for income-group heterogeneity
"""
import json, re
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf
from itertools import permutations

pd.set_option("display.width", 220); pd.set_option("display.max_columns", 60)

panel = pd.read_csv("data/master_panel.csv")
countries = json.load(open("data/countries.json", encoding="utf-8"))
meta = pd.DataFrame([
    {"iso3": k, "country": v["name"], "region": v["region"].strip(), "income": v["income"]}
    for k, v in countries.items() if not v["is_aggregate"]
])
meta["income_group"] = meta.income.map({
    "High income": "High", "Upper middle income": "Upper-middle",
    "Lower middle income": "Lower-middle", "Low income": "Low"})

out = {}
PRED = ["edu_exp_gdp", "exp_prim_pc", "exp_sec_pc", "ptr", "trained_teachers", "internet", "gdp_pc"]

def build_xsec(y0, y1, outcome="hlo", oyear=2017):
    d = panel[panel.year == oyear][["iso3", outcome]].dropna()
    for c in PRED + ["broadband", "tertiary", "gpi_sec", "gini", "rural"]:
        d = d.merge(panel[(panel.year >= y0) & (panel.year <= y1)].groupby("iso3")[c].mean().rename(f"{c}_avg"), on="iso3", how="left")
    d["log_gdp_pc"] = np.log10(d["gdp_pc_avg"])
    return d.merge(meta, on="iso3", how="left")

X = build_xsec(2000, 2015)
NEED = ["hlo", "log_gdp_pc", "edu_exp_gdp_avg", "exp_prim_pc_avg", "exp_sec_pc_avg", "ptr_avg", "trained_teachers_avg", "internet_avg"]
Xc = X.dropna(subset=NEED).copy()
out["n_main"] = len(Xc)

# ============================================================ 1. SHAPLEY DECOMPOSITION
def ols_r2(y, Xm):
    Xd = np.column_stack([np.ones(len(y))] + [Xm[:, j] for j in range(Xm.shape[1])]) if Xm.ndim else np.ones((len(y), 1))
    beta, *_ = np.linalg.lstsq(Xd, y, rcond=None)
    resid = y - Xd @ beta
    return 1 - (resid @ resid) / ((y - y.mean()) @ (y - y.mean()))

y = Xc.hlo.values.astype(float)
preds = ["log_gdp_pc", "edu_exp_gdp_avg", "exp_prim_pc_avg", "exp_sec_pc_avg", "ptr_avg", "trained_teachers_avg", "internet_avg"]
Xm = Xc[preds].values.astype(float)
r2_full = ols_r2(y, Xm)
shap = {p: 0.0 for p in preds}
nperm = 0
for perm in permutations(range(len(preds))):
    idx = []
    prev_r2 = 0.0
    for k in perm:
        idx.append(k)
        r2 = ols_r2(y, Xm[:, idx])
        shap[preds[k]] += r2 - prev_r2
        prev_r2 = r2
    nperm += 1
for p in preds:
    shap[p] /= nperm
total_gain = r2_full  # vs intercept-only
shares = {p: shap[p] / total_gain for p in preds}
print("=== SHAPLEY DECOMPOSITION (exhaustive, %d permutations) ===" % nperm)
for p in sorted(shares, key=lambda k: -shares[k]):
    print("  %-22s avg R2 gain %.4f  share %.3f" % (p, shap[p], shares[p]))
print("  total R2 = %.4f" % r2_full)
out["shapley"] = {"shares": shares, "gains": shap, "r2_full": float(r2_full), "n_perm": nperm}

# grouped shares: wealth / financial / instructional / digital
groups = {"Wealth": ["log_gdp_pc"], "Financial": ["edu_exp_gdp_avg", "exp_prim_pc_avg", "exp_sec_pc_avg"],
          "Instructional": ["ptr_avg", "trained_teachers_avg"], "Digital": ["internet_avg"]}
gshares = {g: sum(shares[p] for p in ps) for g, ps in groups.items()}
print("  grouped:", {k: round(v, 3) for k, v in gshares.items()})
out["shapley_groups"] = gshares

# ============================================================ 2. SPECIFICATION CURVE
specs = []
for (y0, y1, wlab) in [(2000, 2015, "2000-2015"), (2007, 2015, "2007-2015"), (2011, 2015, "2011-2015")]:
    d = build_xsec(y0, y1)
    for dig, dlab in [("internet_avg", "internet"), ("broadband_avg", "broadband")]:
        for cset, clab in [("full", "full controls"), ("nowealth", "no wealth control"), ("minimal", "wealth only")]:
            if cset == "full":
                f = f"hlo ~ log_gdp_pc + edu_exp_gdp_avg + exp_prim_pc_avg + exp_sec_pc_avg + ptr_avg + trained_teachers_avg + {dig}"
            elif cset == "nowealth":
                f = f"hlo ~ edu_exp_gdp_avg + exp_prim_pc_avg + exp_sec_pc_avg + ptr_avg + trained_teachers_avg + {dig}"
            else:
                f = f"hlo ~ log_gdp_pc + {dig}"
            need = [v.strip() for v in f.split("~")[1].split("+")]
            dd = d.dropna(subset=["hlo"] + need)
            if len(dd) < 25:
                continue
            m = smf.ols(f, dd).fit(cov_type="HC1")
            specs.append({"window": wlab, "digital": dlab, "controls": clab,
                          "coef": float(m.params[dig]), "se": float(m.bse[dig]),
                          "p": float(m.pvalues[dig]), "n": int(m.nobs)})
S = pd.DataFrame(specs)
print("\n=== SPECIFICATION CURVE (%d specs) ===" % len(S))
print(S.round(3).to_string(index=False))
print("coef range: %.3f - %.3f | all positive: %s | share p<0.05: %.2f" % (
    S.coef.min(), S.coef.max(), bool((S.coef > 0).all()), (S.p < 0.05).mean()))
out["spec_curve"] = S.to_dict("records")
out["spec_curve_summary"] = {"n": len(S), "min": float(S.coef.min()), "max": float(S.coef.max()),
                             "median": float(S.coef.median()), "share_pos": float((S.coef > 0).mean()),
                             "share_sig": float((S.p < 0.05).mean())}
S.to_csv("data/spec_curve.csv", index=False)

# ============================================================ 3. OSTER BOUNDS
def oster(short_f, long_f, data, treat):
    ds = data.dropna(subset=[v.strip() for v in short_f.split("~")[1].split("+")])
    dl = data.dropna(subset=[v.strip() for v in long_f.split("~")[1].split("+")])
    ms = smf.ols(short_f, ds).fit(cov_type="HC1")
    ml = smf.ols(long_f, dl).fit(cov_type="HC1")
    b_s, b_l = ms.params[treat], ml.params[treat]
    r_s, r_l = ms.rsquared, ml.rsquared
    r_max = min(1.0, 1.3 * r_l)
    delta_bias = np.sqrt(max((b_l - b_s) ** 2 * (r_max - r_l) / max(r_l - r_s, 1e-12), 0))
    b_adj = b_l - np.sign(b_l) * delta_bias
    delta_star = abs(b_l) / delta_bias if delta_bias > 1e-12 else np.inf
    return {"beta_short": float(b_s), "beta_long": float(b_l), "r2_short": float(r_s),
            "r2_long": float(r_l), "r2_max": float(r_max), "beta_adjusted": float(b_adj),
            "delta": float(delta_star), "n_short": int(ms.nobs), "n_long": int(ml.nobs)}

print("\n=== OSTER (2019) BOUNDS ===")
oster_res = {}
short_forms = {"internet_avg": "hlo ~ log_gdp_pc + internet_avg",
               "exp_prim_pc_avg": "hlo ~ log_gdp_pc + exp_prim_pc_avg",
               "trained_teachers_avg": "hlo ~ log_gdp_pc + trained_teachers_avg",
               "log_gdp_pc": "hlo ~ internet_avg + log_gdp_pc"}
for treat in ["internet_avg", "exp_prim_pc_avg", "trained_teachers_avg", "log_gdp_pc"]:
    r = oster(short_forms[treat],
              "hlo ~ log_gdp_pc + edu_exp_gdp_avg + exp_prim_pc_avg + exp_sec_pc_avg + ptr_avg + trained_teachers_avg + internet_avg",
              Xc, treat)
    oster_res[treat] = r
    print("  %-22s beta_short=%.3f beta_long=%.3f -> adjusted=%.3f  delta=%.2f" % (
        treat, r["beta_short"], r["beta_long"], r["beta_adjusted"], r["delta"]))
out["oster"] = oster_res

# ============================================================ 4. LEAVE-ONE-REGION-OUT
f3 = "hlo ~ log_gdp_pc + edu_exp_gdp_avg + exp_prim_pc_avg + exp_sec_pc_avg + ptr_avg + trained_teachers_avg + internet_avg"
jack = []
for reg in sorted(Xc.region.unique()):
    d = Xc[Xc.region != reg]
    m = smf.ols(f3, d).fit(cov_type="HC1")
    jack.append({"dropped": reg, "coef": float(m.params["internet_avg"]), "se": float(m.bse["internet_avg"]),
                 "p": float(m.pvalues["internet_avg"]), "n": int(m.nobs)})
J = pd.DataFrame(jack)
print("\n=== LEAVE-ONE-REGION-OUT (internet coefficient) ===")
print(J.round(3).to_string(index=False))
out["jackknife"] = J.to_dict("records")
out["jackknife_summary"] = {"min": float(J.coef.min()), "max": float(J.coef.max()),
                            "all_sig": bool((J.p < 0.05).all())}
J.to_csv("data/jackknife.csv", index=False)

# ============================================================ 5. TEMPORAL FALSIFICATION (lead window)
lead = build_xsec(2018, 2022)
d = lead.dropna(subset=NEED)
if len(d) >= 25:
    ml_ = smf.ols(f3, d).fit(cov_type="HC1")
    print("\n=== TEMPORAL FALSIFICATION: lead window 2018-2022 (post-outcome) ===")
    print("  internet coef=%.3f (p=%.4f, N=%d) vs lagged 2.394 (p<0.001)" % (
        ml_.params["internet_avg"], ml_.pvalues["internet_avg"], int(ml_.nobs)))
    out["lead_placebo"] = {"coef": float(ml_.params["internet_avg"]), "p": float(ml_.pvalues["internet_avg"]),
                           "n": int(ml_.nobs), "exp_prim": float(ml_.params["exp_prim_pc_avg"]),
                           "exp_prim_p": float(ml_.pvalues["exp_prim_pc_avg"])}

# ============================================================ 6. QUANTILE REGRESSION
print("\n=== QUANTILE REGRESSION (internet & exp_prim coefficients) ===")
qr_res = {}
for q in [0.1, 0.25, 0.5, 0.75, 0.9]:
    m = smf.quantreg(f3, Xc).fit(q=q)
    qr_res[q] = {"internet": float(m.params["internet_avg"]), "internet_p": float(m.pvalues["internet_avg"]),
                 "exp_prim": float(m.params["exp_prim_pc_avg"]), "exp_prim_p": float(m.pvalues["exp_prim_pc_avg"])}
    print("  q=%.2f: internet=%.3f (p=%.4f)  exp_prim=%.3f (p=%.4f)" % (
        q, m.params["internet_avg"], m.pvalues["internet_avg"],
        m.params["exp_prim_pc_avg"], m.pvalues["exp_prim_pc_avg"]))
out["quantile"] = qr_res

# ============================================================ 7. CONVERGENCE (EdStats panel)
es = panel[["iso3", "year", "edstats_score"]].dropna()
es = es[es.iso3.isin(set(meta.iso3))]
w05 = es[es.year == 2005][["iso3", "edstats_score"]].rename(columns={"edstats_score": "s05"})
w10 = es[es.year == 2010][["iso3", "edstats_score"]].rename(columns={"edstats_score": "s10"})
C = w05.merge(w10, on="iso3")
C = C.merge(avg := panel[panel.year.isin([2000, 2005])].groupby("iso3").gdp_pc.mean().rename("gdp0509"), on="iso3", how="left")
C["dlog"] = np.log(C.s10) - np.log(C.s05)
C["log05"] = np.log(C.s05)
Cd = C.dropna(subset=["dlog", "log05"])
m1 = smf.ols("dlog ~ log05", Cd).fit(cov_type="HC1")
print("\n=== BETA-CONVERGENCE (2005->2010, N=%d) ===" % len(Cd))
print("  dlog ~ log05: coef=%.4f (p=%.4f) R2=%.3f" % (m1.params["log05"], m1.pvalues["log05"], m1.rsquared))
Cd2 = Cd.dropna(subset=["gdp0509"])
m2 = smf.ols("dlog ~ log05 + np.log10(gdp0509)", Cd2).fit(cov_type="HC1")
print("  conditional on GDP: coef=%.4f (p=%.4f) N=%d" % (m2.params["log05"], m2.pvalues["log05"], len(Cd2)))
out["convergence"] = {"n": int(len(Cd)), "beta_coef": float(m1.params["log05"]), "beta_p": float(m1.pvalues["log05"]),
                      "r2": float(m1.rsquared), "cond_n": int(len(Cd2)), "cond_coef": float(m2.params["log05"]),
                      "cond_p": float(m2.pvalues["log05"])}
# sigma convergence on balanced set
sd05, sd10 = C.s05.std(), C.s10.std()
print("  SD of scores: 2005=%.1f, 2010=%.1f (balanced N=%d)" % (sd05, sd10, len(C)))
out["sigma"] = {"sd_2005": float(sd05), "sd_2010": float(sd10), "n": int(len(C))}
C.to_csv("data/convergence.csv", index=False)

# ============================================================ 8. ML vs OLS
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import cross_val_score, KFold
from sklearn.inspection import permutation_importance

feats = ["log_gdp_pc", "edu_exp_gdp_avg", "exp_prim_pc_avg", "exp_sec_pc_avg", "ptr_avg", "trained_teachers_avg", "internet_avg"]
Xa = Xc[feats].values; ya = Xc.hlo.values
kf = KFold(n_splits=5, shuffle=True, random_state=42)
rf = RandomForestRegressor(n_estimators=500, min_samples_leaf=2, random_state=42)
rf_cv = cross_val_score(rf, Xa, ya, cv=kf, scoring="r2")
ols_cv = []
for tr, te in kf.split(Xa):
    mm = sm.OLS(ya[tr], sm.add_constant(Xa[tr])).fit()
    pred = sm.add_constant(Xa[te]) @ mm.params
    ss_res = ((ya[te] - pred) ** 2).sum(); ss_tot = ((ya[te] - ya[te].mean()) ** 2).sum()
    ols_cv.append(1 - ss_res / ss_tot)
rf.fit(Xa, ya)
pi = permutation_importance(rf, Xa, ya, n_repeats=30, random_state=42)
print("\n=== PREDICTIVE COMPARISON (5-fold CV) ===")
print("  OLS CV R2: %.3f (+/- %.3f)" % (np.mean(ols_cv), np.std(ols_cv)))
print("  RF  CV R2: %.3f (+/- %.3f)" % (rf_cv.mean(), rf_cv.std()))
print("  permutation importance (RF):")
for f, imp in sorted(zip(feats, pi.importances_mean), key=lambda t: -t[1]):
    print("    %-22s %.2f" % (f, imp))
out["ml"] = {"ols_cv_r2": float(np.mean(ols_cv)), "ols_cv_sd": float(np.std(ols_cv)),
             "rf_cv_r2": float(rf_cv.mean()), "rf_cv_sd": float(rf_cv.std()),
             "perm_importance": {f: float(i) for f, i in zip(feats, pi.importances_mean)}}

# ============================================================ 9. BOOTSTRAP for income-group heterogeneity
rng = np.random.default_rng(11)
boot = {"High": [], "Upper-middle": [], "Lower-middle": []}
for g in boot:
    d = Xc[Xc.income_group == g]
    n = len(d)
    for _ in range(4000):
        idx = rng.integers(0, n, n)
        db = d.iloc[idx]
        try:
            mb = smf.ols(f3, db).fit()
            boot[g].append(float(mb.params["internet_avg"]))
        except Exception:
            pass
print("\n=== BOOTSTRAP (internet coef by income group) ===")
boot_summ = {}
for g, vals in boot.items():
    vals = np.array(vals)
    lo, hi = np.percentile(vals, [2.5, 97.5])
    boot_summ[g] = {"n": int((Xc.income_group == g).sum()), "mean": float(vals.mean()),
                    "ci_lo": float(lo), "ci_hi": float(hi)}
    print("  %-14s N=%2d  mean=%.3f  95%% CI [%.3f, %.3f]" % (g, boot_summ[g]["n"], vals.mean(), lo, hi))
out["bootstrap_income"] = boot_summ

json.dump(out, open("data/analysis_upgrade.json", "w"), indent=1)
print("\nsaved data/analysis_upgrade.json")
