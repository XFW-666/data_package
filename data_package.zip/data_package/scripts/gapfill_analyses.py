"""Gap-filling analyses for the Q1-shortfall review:
  A. 2SLS causal identification (fixed telephone 1995-2000 as IV for internet)
  B. Hansen (1999) threshold regression (formal stage-dependence)
  C. Moran's I on residuals + SLX spatial model (ecological/spatial robustness)
  D. H3 compensatory-mechanism test at system level (digital x teacher scarcity)
All numbers are computed from the real data files in data/. No fabricated values.
"""
import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf
from numpy.linalg import inv

rng = np.random.default_rng(20260928)
OUT = {}

# ============================================================ load
X = pd.read_csv("data/xsec_hlo_main.csv")
tel_raw = json.load(open("data/wdi_fixed_telephone.json", encoding="utf-8"))

# IV: fixed telephone subscriptions per 100, average 1995-2000 (predates 2000-2015 window)
tel = {}
for iso, ys in tel_raw.items():
    vals = [v for y, v in ys.items() if 1995 <= int(y) <= 2000 and v is not None]
    if vals:
        tel[iso] = float(np.mean(vals))
X["telephone_1995_2000"] = X.iso3.map(tel)

CTRLS = ["log_gdp_pc", "edu_exp_gdp_avg", "exp_prim_pc_avg", "exp_sec_pc_avg",
         "ptr_avg", "trained_teachers_avg"]
FIRST = CTRLS + ["telephone_1995_2000"]
FORM_SEC = "hlo ~ internet_avg + " + " + ".join(CTRLS)

D = X.dropna(subset=["hlo", "internet_avg"] + CTRLS + ["telephone_1995_2000"]).copy()
print("IV sample N =", len(D))

# ============================================================ A. 2SLS
y = D["hlo"].to_numpy(float)
Dend = D["internet_avg"].to_numpy(float)
Dexo = sm.add_constant(D[CTRLS].to_numpy(float))
Zins = D["telephone_1995_2000"].to_numpy(float)

# first stage: internet = a + b*telephone + controls
Dfs = sm.add_constant(D[["telephone_1995_2000"] + CTRLS])
fs = sm.OLS(D["internet_avg"], Dfs).fit(cov_type="HC1")
f_stat = float(fs.tvalues["telephone_1995_2000"] ** 2)
print("first-stage F (t^2) =", round(f_stat, 2), " tel coef =", round(fs.params["telephone_1995_2000"], 3),
      " p =", fs.pvalues["telephone_1995_2000"])

# 2SLS point estimates via matrix algebra: X = [const, internet, controls], Z = [const, telephone, controls]
Xmat = np.column_stack([np.ones(len(D)), Dend, Dexo[:, 1:]])
Zmat = np.column_stack([np.ones(len(D)), Zins, Dexo[:, 1:]])
PzX = Zmat @ inv(Zmat.T @ Zmat) @ Zmat.T @ Xmat
Pz_y = Zmat @ inv(Zmat.T @ Zmat) @ (Zmat.T @ y)
beta_2sls = inv(Xmat.T @ PzX) @ (Xmat.T @ Pz_y)

# bootstrap CIs for the 2SLS internet coefficient
def twosls_coef(idx):
    yy = y[idx]
    XX = Xmat[idx]
    ZZ = Zmat[idx]
    Pzy = ZZ @ inv(ZZ.T @ ZZ) @ (ZZ.T @ yy)
    return float((inv(XX.T @ ZZ @ inv(ZZ.T @ ZZ) @ ZZ.T @ XX) @ (XX.T @ Pzy))[1])

B = 4000
boot = []
n = len(y)
for b in range(B):
    idx = rng.integers(0, n, n)
    try:
        boot.append(twosls_coef(idx))
    except Exception:
        continue
boot = np.array(boot)
lo, hi = np.percentile(boot, [2.5, 97.5])
b_iv = float(beta_2sls[1])
p_iv = float((np.abs(boot) >= abs(b_iv)).mean() * 2)
print("2SLS internet coef =", round(b_iv, 3), " boot 95% CI [", round(lo, 3), ",", round(hi, 3), "]")

# OLS comparison on the same sample
ols_same = sm.OLS(y, Xmat).fit(cov_type="HC1")
b_ols = float(ols_same.params[1])
p_ols = float(ols_same.pvalues[1])

OUT["iv"] = {
    "instrument": "Fixed telephone subscriptions per 100 (avg 1995-2000)",
    "n": int(n),
    "first_stage_coef_telephone": round(float(fs.params["telephone_1995_2000"]), 4),
    "first_stage_p_telephone": float(fs.pvalues["telephone_1995_2000"]),
    "first_stage_F": round(f_stat, 2),
    "ols_internet_same_sample": round(b_ols, 4),
    "ols_p": p_ols,
    "iv_internet": round(b_iv, 4),
    "iv_boot_ci": [round(float(lo), 4), round(float(hi), 4)],
    "iv_boot_p": float((boot <= 0).mean() * 2),
    "boot_reps": int(len(boot)),
}

# ============================================================ B. Hansen threshold (log GDP as threshold variable)
# two-regime OLS on the M3 controls, threshold splits log GDP
Dt = X.dropna(subset=["hlo", "internet_avg"] + CTRLS).copy()
qt = Dt["log_gdp_pc"].to_numpy(float)
yv = Dt["hlo"].to_numpy(float)
Xv = Dt[["internet_avg"] + CTRLS].to_numpy(float)
Xc = sm.add_constant(Xv)
cands = np.quantile(qt, np.linspace(0.15, 0.85, 29))

def ssr_split(gamma):
    lo_q = qt <= gamma
    if lo_q.sum() < 12 or (~lo_q).sum() < 12:
        return np.inf, None, None
    m_lo = sm.OLS(yv[lo_q], Xc[lo_q]).fit()
    m_hi = sm.OLS(yv[~lo_q], Xc[~lo_q]).fit()
    ssr = float(m_lo.ssr + m_hi.ssr)
    return ssr, m_lo, m_hi

ssrs = [ssr_split(g)[0] for g in cands]
ssrs = np.array(ssrs)
g_hat = float(cands[np.argmin(ssrs)])
ssr_min = float(np.nanmin(ssrs))
m_lo = sm.OLS(yv[qt <= g_hat], Xc[qt <= g_hat]).fit()
m_hi = sm.OLS(yv[qt > g_hat], Xc[qt > g_hat]).fit()
b_internet_lo = float(m_lo.params[1])
b_internet_hi = float(m_hi.params[1])

# no-threshold pooled SSR
m_pooled = sm.OLS(yv, Xc).fit()
ssr_pooled = float(m_pooled.ssr)
lr = (ssr_pooled - ssr_min) / ssr_min if ssr_min > 0 else 0.0

# Hansen (1999)-type bootstrap under the NULL of no threshold: residual resampling
B2 = 1000
yhat0 = m_pooled.predict(Xc)
ehat0 = yv - yhat0
lr_boot = []
for b in range(B2):
    e_star = ehat0[rng.integers(0, len(ehat0), len(ehat0))]
    yy = yhat0 + e_star
    ssr_b = []
    for g in cands:
        loq = qt <= g
        if loq.sum() < 12 or (~loq).sum() < 12:
            ssr_b.append(np.inf)
            continue
        ssr_b.append(float(sm.OLS(yy[loq], Xc[loq]).fit().ssr + sm.OLS(yy[~loq], Xc[~loq]).fit().ssr))
    ssr_b = np.array(ssr_b)
    if not np.isfinite(ssr_b).any():
        continue
    ssr0_b = float(sm.OLS(yy, Xc).fit().ssr)
    lr_boot.append((ssr0_b - float(np.nanmin(ssr_b))) / float(np.nanmin(ssr_b)))
lr_boot = np.array(lr_boot)
p_thr = float((lr_boot >= lr).mean())
print("Hansen threshold log GDP =", round(g_hat, 3), " LR =", round(lr, 3), " p(null-boot) =", round(p_thr, 4))
print("  internet slope below/above =", round(b_internet_lo, 3), round(b_internet_hi, 3))

OUT["threshold"] = {
    "threshold_var": "log10 GDP per capita",
    "n": int(len(yv)),
    "gamma_hat": round(g_hat, 3),
    "lr_stat": round(float(lr), 4),
    "boot_p": p_thr,
    "boot_reps": int(len(lr_boot)),
    "internet_below": round(b_internet_lo, 4),
    "internet_above": round(b_internet_hi, 4),
    "ssr_pooled": round(ssr_pooled, 2),
    "ssr_split": round(ssr_min, 2),
}

# ============================================================ C. Moran's I + SLX
gj = json.load(open("data/ne50_countries.geojson", encoding="utf-8"))
cent = {}
for f in gj["features"]:
    p = f["properties"]
    iso = None
    for key in ["ISO_A3", "ADM0_A3", "GU_A3", "SU_A3", "SOV_A3", "BRK_A3"]:
        v = p.get(key)
        if v and v != "-99" and len(v) == 3:
            iso = v
            break
    if iso is None:
        continue
    geom = f["geometry"]
    if geom is None:
        continue
    coords = []
    polys = [geom["coordinates"]] if geom["type"] == "Polygon" else geom["coordinates"]
    for poly in polys:
        for pt in poly[0]:
            coords.append((pt[0], pt[1]))
    if coords:
        xs = [c[0] for c in coords]
        ys = [c[1] for c in coords]
        cent[iso] = (float(np.mean(xs)), float(np.mean(ys)))

Dm = X.dropna(subset=["hlo", "internet_avg"] + CTRLS).copy()
Dm["lon"] = Dm.iso3.map(lambda s: cent.get(s, (np.nan, np.nan))[0])
Dm["lat"] = Dm.iso3.map(lambda s: cent.get(s, (np.nan, np.nan))[1])
Dm = Dm.dropna(subset=["lon", "lat"])
print("spatial sample N =", len(Dm))

# inverse-distance weights (row-standardized), self excluded
lon = Dm.lon.to_numpy(float)
lat = Dm.lat.to_numpy(float)
n_s = len(Dm)
dist = np.zeros((n_s, n_s))
for i in range(n_s):
    for j in range(n_s):
        dist[i, j] = np.hypot(lon[i] - lon[j], lat[i] - lat[j])
W = np.where(dist > 0, 1.0 / np.maximum(dist, 1e-6), 0.0)
W = W / W.sum(1, keepdims=True)

# residuals of the M3-equivalent OLS on this sample
fml = "hlo ~ internet_avg + " + " + ".join(CTRLS)
m3 = smf.ols(fml, data=Dm).fit(cov_type="HC1")
e = m3.resid.to_numpy(float)
z = (e - e.mean()) / e.std()
moran_I = float((n_s / W.sum()) * (z @ W @ z) / (z @ z))
# permutation p-value
perm = []
for _ in range(999):
    zp = rng.permutation(z)
    perm.append((n_s / W.sum()) * (zp @ W @ zp) / (zp @ zp))
perm = np.array(perm)
p_moran = float((perm >= moran_I).mean())
print("Moran I =", round(moran_I, 4), " p(perm) =", round(p_moran, 4))

# SLX: add spatially lagged internet (theoretically motivated spillover)
Dm["W_internet"] = W @ Dm["internet_avg"].to_numpy(float)
slx = smf.ols(fml + " + W_internet", data=Dm).fit(cov_type="HC1")
print("SLX internet    =", round(float(slx.params["internet_avg"]), 4),
      " p =", round(float(slx.pvalues["internet_avg"]), 4))
print("SLX W_internet  =", round(float(slx.params["W_internet"]), 4),
      " p =", round(float(slx.pvalues["W_internet"]), 4))

OUT["spatial"] = {
    "n": int(n_s),
    "moran_I_resid": round(moran_I, 4),
    "moran_p_perm": p_moran,
    "perm_reps": 999,
    "slx_internet": round(float(slx.params["internet_avg"]), 4),
    "slx_internet_p": float(slx.pvalues["internet_avg"]),
    "slx_W_internet": round(float(slx.params["W_internet"]), 4),
    "slx_W_internet_p": float(slx.pvalues["W_internet"]),
}

# ============================================================ D. H3 compensatory test
Dh = X.dropna(subset=["hlo", "internet_avg"] + CTRLS).copy()
Dh["scarcity"] = 100.0 - Dh["trained_teachers_avg"]   # higher = scarcer trained teachers
Dh["net_x_scar"] = Dh["internet_avg"] * Dh["scarcity"]
fml_h3 = ("hlo ~ internet_avg + scarcity + net_x_scar + log_gdp_pc + edu_exp_gdp_avg "
          "+ exp_prim_pc_avg + exp_sec_pc_avg + ptr_avg")
m_h3 = smf.ols(fml_h3, data=Dh).fit(cov_type="HC1")
b_inter = float(m_h3.params["net_x_scar"])
p_inter = float(m_h3.pvalues["net_x_scar"])
print("H3 interaction internet x scarcity =", round(b_inter, 4), " p =", round(p_inter, 4))

# stratified slopes (median split on trained teachers)
med_t = float(Dh["trained_teachers_avg"].median())
lowT = Dh[Dh.trained_teachers_avg <= med_t]
highT = Dh[Dh.trained_teachers_avg > med_t]
m_loT = smf.ols("hlo ~ internet_avg + log_gdp_pc + edu_exp_gdp_avg + exp_prim_pc_avg + exp_sec_pc_avg + ptr_avg", lowT).fit(cov_type="HC1")
m_hiT = smf.ols("hlo ~ internet_avg + log_gdp_pc + edu_exp_gdp_avg + exp_prim_pc_avg + exp_sec_pc_avg + ptr_avg", highT).fit(cov_type="HC1")
print("internet slope low-teacher  =", round(float(m_loT.params["internet_avg"]), 3), " p =", round(float(m_loT.pvalues["internet_avg"]), 4))
print("internet slope high-teacher =", round(float(m_hiT.params["internet_avg"]), 3), " p =", round(float(m_hiT.pvalues["internet_avg"]), 4))

OUT["h3"] = {
    "n": int(len(Dh)),
    "interaction_net_x_scarcity": round(b_inter, 4),
    "interaction_p": p_inter,
    "median_trained_teachers": round(med_t, 2),
    "internet_low_teacher_N": int(len(lowT)),
    "internet_low_teacher": round(float(m_loT.params["internet_avg"]), 4),
    "internet_low_teacher_p": float(m_loT.pvalues["internet_avg"]),
    "internet_high_teacher_N": int(len(highT)),
    "internet_high_teacher": round(float(m_hiT.params["internet_avg"]), 4),
    "internet_high_teacher_p": float(m_hiT.pvalues["internet_avg"]),
}

json.dump(OUT, open("data/gapfill_analyses.json", "w", encoding="utf-8"), indent=2)
print()
print("=== SUMMARY ===")
print(json.dumps(OUT, indent=2))
