"""Verify all gap-fill numeric claims in the manuscript against computed data."""
import json
import re

gf = json.load(open("data/gapfill_analyses.json", encoding="utf-8"))
text = open("manuscript.md", encoding="utf-8").read()

checks = []
def chk(name, cond, detail=""):
    checks.append((cond, name, detail))

iv = gf["iv"]; th = gf["threshold"]; sp = gf["spatial"]; h3 = gf["h3"]

# --- IV claims in text
chk("IV first-stage F 113.8", abs(iv["first_stage_F"] - 113.8) < 0.2, f"{iv['first_stage_F']}")
chk("IV 2SLS coef 4.08", abs(iv["iv_internet"] - 4.08) < 0.01, f"{iv['iv_internet']}")
chk("IV boot CI 2.78-5.87", abs(iv["iv_boot_ci"][0] - 2.78) < 0.02 and abs(iv["iv_boot_ci"][1] - 5.87) < 0.02, f"{iv['iv_boot_ci']}")
chk("IV N=82", iv["n"] == 82, f"{iv['n']}")
chk("IV tel coef 0.75", abs(iv["first_stage_coef_telephone"] - 0.75) < 0.02, f"{iv['first_stage_coef_telephone']}")
chk("IV 2SLS significant (CI excludes 0)", iv["iv_boot_ci"][0] > 0)

# --- text contains the IV sentence
chk("text has 2SLS 4.08", "4.08" in text)
chk("text has first-stage F 113.8", "113.8" in text)
chk("text has boot CI 2.78-5.87", "2.78" in text and "5.87" in text)

# --- threshold claims
chk("threshold gamma 4.15", abs(th["gamma_hat"] - 4.15) < 0.01, f"{th['gamma_hat']}")
chk("threshold LR 0.32", abs(th["lr_stat"] - 0.32) < 0.02, f"{th['lr_stat']}")
chk("threshold p 0.093", abs(th["boot_p"] - 0.093) < 0.01, f"{th['boot_p']}")
chk("threshold slope above 2.32", abs(th["internet_above"] - 2.32) < 0.02, f"{th['internet_above']}")
chk("threshold slope below -0.28", abs(th["internet_below"] - (-0.28)) < 0.02, f"{th['internet_below']}")
chk("text has threshold 4.15", "4.15" in text)
chk("text has threshold p 0.093", "0.093" in text)

# --- spatial claims
chk("Moran I 0.066", abs(sp["moran_I_resid"] - 0.066) < 0.005, f"{sp['moran_I_resid']}")
chk("Moran p 0.009", abs(sp["moran_p_perm"] - 0.009) < 0.005, f"{sp['moran_p_perm']}")
chk("SLX internet 2.29", abs(sp["slx_internet"] - 2.29) < 0.02, f"{sp['slx_internet']}")
chk("SLX W_internet 1.80", abs(sp["slx_W_internet"] - 1.80) < 0.02, f"{sp['slx_W_internet']}")
chk("SLX W_internet p 0.095", abs(sp["slx_W_internet_p"] - 0.095) < 0.01, f"{sp['slx_W_internet_p']}")
chk("text has Moran 0.066", "0.066" in text)
chk("text has Moran p 0.009", "0.009" in text)

# --- H3 claims
chk("H3 interaction -0.026", abs(h3["interaction_net_x_scarcity"] - (-0.026)) < 0.005, f"{h3['interaction_net_x_scarcity']}")
chk("H3 interaction p 0.145", abs(h3["interaction_p"] - 0.145) < 0.01, f"{h3['interaction_p']}")
chk("H3 low-teacher 2.00", abs(h3["internet_low_teacher"] - 2.00) < 0.02, f"{h3['internet_low_teacher']}")
chk("H3 low-teacher N 42", h3["internet_low_teacher_N"] == 42, f"{h3['internet_low_teacher_N']}")
chk("H3 high-teacher 2.44", abs(h3["internet_high_teacher"] - 2.44) < 0.02, f"{h3['internet_high_teacher']}")
chk("H3 high-teacher N 41", h3["internet_high_teacher_N"] == 41, f"{h3['internet_high_teacher_N']}")
chk("text has H3 interaction p 0.145", "0.145" in text)
chk("text has 2.44 vs 2.00", "2.44" in text and "2.00" in text)

# --- Table 3 rows present
for frag in ["2SLS internet coefficient", "Hansen threshold", "Moran's I", "SLX: own internet",
             "H3 compensatory test", "Internet × teacher-scarcity"]:
    chk("Table 3 has row: " + frag, frag in text)

fails = [c for c in checks if not c[0]]
print("GAPFILL VERIFICATION: %d/%d PASS" % (len(checks) - len(fails), len(checks)))
for cond, name, detail in checks:
    if not cond:
        print("  FAIL", name, detail)
if not fails:
    print("ALL GAP-FILL CLAIMS VERIFIED")
