import json, urllib.request

def get(url, timeout=120):
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (research)"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))

rows, page = [], 1
while True:
    d = get(f"https://api.worldbank.org/v2/country?format=json&per_page=500&page={page}")
    rows.extend(d[1])
    if page >= d[0]["pages"]:
        break
    page += 1

countries = {}
for c in rows:
    countries[c["id"]] = {
        "name": c["name"],
        "region": c["region"]["value"],
        "income": c["incomeLevel"]["value"],
        "is_aggregate": c["region"]["id"] == "NA",
    }
json.dump(countries, open("data/countries.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
real = [k for k, v in countries.items() if not v["is_aggregate"]]
print("total entries:", len(countries), "| real countries:", len(real))

# income groups
from collections import Counter
print(Counter(v["income"] for v in countries.values() if not v["is_aggregate"]))

# inspect EdStats AED.PRSC.MEAN year distribution
d = json.load(open("data/edstats_AED.PRSC.MEAN.json", encoding="utf-8"))
from collections import Counter as C2
yrs = C2()
cs = set()
for r in d:
    if r["value"] is None:
        continue
    if r["countryiso3code"] in real:
        yrs[int(r["date"])] += 1
        cs.add(r["countryiso3code"])
print("AED.PRSC.MEAN by year:", dict(sorted(yrs.items())))
print("countries with AED.PRSC.MEAN:", len(cs))
