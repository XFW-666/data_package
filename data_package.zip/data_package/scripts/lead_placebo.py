"""Lead-window (post-outcome) falsification test with available data."""
import json
import numpy as np
import pandas as pd
import statsmodels.formula.api as smf

panel = pd.read_csv("data/master_panel.csv")
countries = json.load(open("data/countries.json", encoding="utf-8"))
meta = pd.DataFrame([{"iso3": k, "region": v["region"].strip(), "income": v["income"]}
                     for k, v in countries.items() if not v["is_aggregate"]])
meta["income_group"] = meta.income.map({"High income": "High", "Upper middle income": "Upper-middle",
                                        "Lower middle income": "Lower-middle", "Low income": "Low"})

def build(y0, y1):
    d = panel[panel.year == 2017][["iso3", "hlo"]].dropna()
    for c in ["internet", "gdp_pc", "exp_prim_pc", "edu_exp_gdp", "ptr", "trained_teachers"]:
        d = d.merge(panel[(panel.year >= y0) & (panel.year <= y1)].groupby("iso3")[c].mean().rename(f"{c}_avg"), on="iso3", how="left")
    d["log_gdp_pc"] = np.log10(d["gdp_pc_avg"])
    return d.merge(meta, on="iso3", how="left")

out = {}
for (y0, y1, lab) in [(2016, 2018, "2016-2018"), (2016, 2022, "2016-2022"), (2018, 2022, "2018-2022")]:
    d = build(y0, y1)
    need = ["hlo", "log_gdp_pc", "internet_avg", "exp_prim_pc_avg", "edu_exp_gdp_avg", "ptr_avg", "trained_teachers_avg"]
    dd = d.dropna(subset=need)
    print(f"window {lab}: N={len(dd)} (internet only: {d.internet_avg.notna().sum()})")
    if len(dd) >= 25:
        m = smf.ols("hlo ~ log_gdp_pc + edu_exp_gdp_avg + exp_prim_pc_avg + ptr_avg + trained_teachers_avg + internet_avg", dd).fit(cov_type="HC1")
        print("  internet=%.3f (p=%.4f) exp_prim=%.3f (p=%.4f) trained=%.3f (p=%.4f)" % (
            m.params["internet_avg"], m.pvalues["internet_avg"],
            m.params["exp_prim_pc_avg"], m.pvalues["exp_prim_pc_avg"],
            m.params["trained_teachers_avg"], m.pvalues["trained_teachers_avg"]))
        out[lab] = {"n": int(m.nobs), "internet": float(m.params["internet_avg"]), "internet_p": float(m.pvalues["internet_avg"]),
                    "exp_prim": float(m.params["exp_prim_pc_avg"]), "exp_prim_p": float(m.pvalues["exp_prim_pc_avg"])}
    else:
        # reduced model: wealth + internet + trained + ptr
        need2 = ["hlo", "log_gdp_pc", "internet_avg", "ptr_avg", "trained_teachers_avg"]
        dd2 = d.dropna(subset=need2)
        print(f"  reduced model N={len(dd2)}")
        if len(dd2) >= 25:
            m = smf.ols("hlo ~ log_gdp_pc + ptr_avg + trained_teachers_avg + internet_avg", dd2).fit(cov_type="HC1")
            print("  internet=%.3f (p=%.4f)" % (m.params["internet_avg"], m.pvalues["internet_avg"]))
            out[lab] = {"n": int(m.nobs), "internet": float(m.params["internet_avg"]), "internet_p": float(m.pvalues["internet_avg"])}

json.dump(out, open("data/lead_placebo.json", "w"), indent=1)
print("saved")
