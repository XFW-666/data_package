"""Merged multi-panel figures (180mm width, min font 8pt).
Fig2 landscape (6 panels), Fig3 associations (9 panels),
Fig4 robustness (6 panels), Fig5 extensions (6 panels).
Fig1 stays as the author-supplied original and is NOT regenerated here.
"""
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
from matplotlib.collections import PatchCollection
from matplotlib.patches import Polygon as MplPolygon
import statsmodels.api as sm
import statsmodels.formula.api as smf

plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 8.5, "axes.titlesize": 9.5, "axes.labelsize": 8.5,
    "xtick.labelsize": 8, "ytick.labelsize": 8, "legend.fontsize": 8,
    "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True, "grid.alpha": 0.25,
    "grid.linewidth": 0.5, "figure.dpi": 300, "savefig.dpi": 330, "savefig.bbox": "tight",
    "legend.frameon": False,
})
W = 7.09  # 180 mm final width
BLUE_D, BLUE_M, BLUE_L, BLUE_XL = "#08306b", "#2171b5", "#6baed6", "#c6dbef"
ACCENT = "#d95f02"
GREY = "#595959"

panel = pd.read_csv("data/master_panel.csv")
countries = json.load(open("data/countries.json", encoding="utf-8"))
meta = pd.DataFrame([{"iso3": k, "income": v["income"]} for k, v in countries.items() if not v["is_aggregate"]])
meta["income_group"] = meta.income.map({"High income": "High", "Upper middle income": "Upper-middle",
                                        "Lower middle income": "Lower-middle", "Low income": "Low"})
if "income_group" not in panel.columns:
    panel = panel.merge(meta[["iso3", "income_group"]], on="iso3", how="left")
X = pd.read_csv("data/xsec_hlo_main.csv")
up = json.load(open("data/analysis_upgrade.json", encoding="utf-8"))
L = pd.read_csv("data/lp_latest.csv")
L = L[L.iso3.isin(set(meta.iso3))]
if "income_group" not in L.columns:
    L = L.merge(meta[["iso3", "income_group"]], on="iso3", how="left")
order = ["High", "Upper-middle", "Lower-middle", "Low"]
cols = {"High": BLUE_D, "Upper-middle": BLUE_M, "Lower-middle": BLUE_L, "Low": BLUE_XL}


def ptitle(ax, t):
    ax.set_title(t, loc="left", fontweight="bold", fontsize=9.5)


def qa_texts(fig, name):
    """Report text artists that overflow the figure or cross into a neighbor axes."""
    fig.canvas.draw()
    r = fig.canvas.get_renderer()
    W = fig.get_figwidth() * fig.dpi
    H = fig.get_figheight() * fig.dpi
    issues = []
    titles = []
    for i, ax in enumerate(fig.axes):
        ax_bb = ax.get_window_extent(r)
        def in_view(t, lim, is_x):
            pos = t.get_position()[0 if is_x else 1]
            lo, hi = min(lim), max(lim)
            return lo - 0.6 <= pos <= hi + 0.6
        items = [(ax.title, "title")] + \
                [(ax.xaxis.label, "xlabel"), (ax.yaxis.label, "ylabel")] + \
                [(t, "xtick") for t in ax.get_xticklabels() if t.get_text() and in_view(t, ax.get_xlim(), True)] + \
                [(t, "ytick") for t in ax.get_yticklabels() if t.get_text() and in_view(t, ax.get_ylim(), False)] + \
                [(t, "text") for t in ax.texts]
        for t, kind in items:
            if not t.get_text():
                continue
            bb = t.get_window_extent(r)
            if bb.x0 < -2 or bb.x1 > W + 2 or bb.y0 < -2 or bb.y1 > H + 2:
                issues.append(f"{name} ax{i} {kind} OUTSIDE-FIG: '{t.get_text()[:28]}' bb=({bb.x0:.0f},{bb.x1:.0f},{bb.y0:.0f},{bb.y1:.0f}) fig=({W:.0f},{H:.0f})")
            if kind == "title":
                titles.append((i, bb, t.get_text()))
        # ytick labels must not overlap each other vertically
        yticks = [t for t in ax.get_yticklabels() if t.get_text()]
        for a in range(len(yticks)):
            for b in range(a + 1, len(yticks)):
                ba, bb_ = yticks[a].get_window_extent(r), yticks[b].get_window_extent(r)
                if ba.x0 < bb_.x1 and bb_.x0 < ba.x1 and ba.y0 < bb_.y1 and bb_.y0 < ba.y1:
                    issues.append(f"{name} ax{i} ytick OVERLAP: '{yticks[a].get_text()[:14]}' vs '{yticks[b].get_text()[:14]}'")
        xticks = [t for t in ax.get_xticklabels() if t.get_text() and abs(t.get_rotation()) < 30]
        for a in range(len(xticks)):
            for b in range(a + 1, len(xticks)):
                ba, bb_ = xticks[a].get_window_extent(r), xticks[b].get_window_extent(r)
                if ba.x0 < bb_.x1 and bb_.x0 < ba.x1 and ba.y0 < bb_.y1 and bb_.y0 < ba.y1:
                    issues.append(f"{name} ax{i} xtick OVERLAP: '{xticks[a].get_text()[:14]}' vs '{xticks[b].get_text()[:14]}'")
        # title should not extend past own axes right edge by a wide margin
        if ax.title.get_text():
            bb = ax.title.get_window_extent(r)
            if bb.x1 > ax_bb.x1 + 60:
                issues.append(f"{name} ax{i} title OVERFLOW-R: '{ax.title.get_text()[:30]}' x1={bb.x1:.0f} ax_x1={ax_bb.x1:.0f}")
    for i in range(len(titles)):
        for j in range(i + 1, len(titles)):
            a, b = titles[i][1], titles[j][1]
            if a.x0 < b.x1 and b.x0 < a.x1 and a.y0 < b.y1 and b.y0 < a.y1:
                issues.append(f"{name} title OVERLAP: '{titles[i][2][:20]}' vs '{titles[j][2][:20]}'")
    if issues:
        for s in issues:
            print("  QA", s)
    else:
        print(f"  QA {name}: texts ok")
    return issues


# ============================================================ FIGURE 2: landscape (6 panels)
hlo = panel[panel.year == 2017][["iso3", "hlo"]].dropna()
hlo_map = dict(zip(hlo.iso3, hlo.hlo))
gj = json.load(open("data/ne50_countries.geojson", encoding="utf-8"))
geom_by_iso = {}
for f in gj["features"]:
    p = f["properties"]
    for key in ["ISO_A3", "ADM0_A3", "GU_A3", "SU_A3", "SOV_A3", "BRK_A3"]:
        v = p.get(key)
        if v and v != "-99" and len(v) == 3 and v not in geom_by_iso:
            geom_by_iso[v] = f["geometry"]
geom_by_iso["XKX"] = next((f["geometry"] for f in gj["features"] if f["properties"].get("NAME") == "Kosovo"), None)

fig = plt.figure(figsize=(W, 7.4))
gs = fig.add_gridspec(3, 6, height_ratios=[1.55, 1.05, 1.05], hspace=0.55, wspace=1.75)
axM = fig.add_subplot(gs[0, :])
cmap = plt.get_cmap("YlGnBu")
norm = mcolors.Normalize(vmin=300, vmax=590)
patches, vals = [], []
for iso, geom in geom_by_iso.items():
    if geom is None:
        continue
    polys = [geom["coordinates"]] if geom["type"] == "Polygon" else geom["coordinates"]
    for poly in polys:
        ring = poly[0]
        xs = [pt[0] for pt in ring]; ys = [pt[1] for pt in ring]
        if max(xs) - min(xs) > 180:
            continue
        patches.append(MplPolygon(np.column_stack([xs, ys]), closed=True))
        vals.append(hlo_map.get(iso, np.nan))
grey_p = [p for p, v in zip(patches, vals) if not np.isfinite(v)]
colored = [(p, v) for p, v in zip(patches, vals) if np.isfinite(v)]
pc = PatchCollection([p for p, _ in colored], array=np.array([v for _, v in colored]),
                     cmap=cmap, norm=norm, edgecolor="#666666", linewidth=0.25)
axM.add_collection(pc)
axM.add_collection(PatchCollection(grey_p, facecolor="#e8e8e8", edgecolor="#bbbbbb", linewidth=0.25))
axM.set_xlim(-196, 158); axM.set_ylim(-58, 90)
axM.set_aspect("equal"); axM.axis("off")
ptitle(axM, "A  Harmonized learning outcomes, 2017")
cb = fig.colorbar(pc, ax=axM, orientation="horizontal", fraction=0.05, pad=0.015, shrink=0.5, aspect=34)
cb.set_label("HLO score", fontsize=8); cb.ax.tick_params(labelsize=8)
axM.text(1.012, 0.42, "Grey: no harmonized\nestimate; small states\nnot visible",
         transform=axM.transAxes, fontsize=8, color=GREY, va="center", ha="left", linespacing=1.35, clip_on=False)

ax = fig.add_subplot(gs[1, 0:3])
h = hlo.merge(meta[["iso3", "income_group"]], on="iso3", how="left")
data = [h[h.income_group == g].hlo.values for g in order]
bp = ax.boxplot(data, positions=range(4), widths=0.55, patch_artist=True, showfliers=False,
                medianprops=dict(color="#333333", lw=1.3))
for patch, g in zip(bp["boxes"], order):
    patch.set_facecolor(cols[g]); patch.set_alpha(0.8); patch.set_edgecolor("#555555")
rng = np.random.default_rng(7)
for i, g in enumerate(order):
    v = h[h.income_group == g].hlo.values
    ax.scatter(i + rng.uniform(-0.18, 0.18, len(v)), v, s=6, color="#333333", alpha=0.45, zorder=3, linewidths=0)
ax.set_xticks(range(4))
ax.set_xticklabels([f"{g.replace('-middle','-mid.')}\n(n={len(h[h.income_group==g])})" for g in order], fontsize=8)
ax.set_ylabel("HLO score", fontsize=8.5)
ptitle(ax, "B  HLO by income group")
ax.axhline(430.6, color=ACCENT, lw=1.0, ls="--")
ax.text(0.98, 0.94, "mean 431", transform=ax.transAxes, ha="right", fontsize=8, color=ACCENT)

ax = fig.add_subplot(gs[1, 3:6])
grp = L.groupby("income_group").lp.agg(["mean", "count"]).reindex(order)
ax.bar(range(4), grp["mean"], color=[cols[g] for g in order], alpha=0.88, width=0.6)
for i, (m, c) in enumerate(zip(grp["mean"], grp["count"])):
    ax.text(i, m + 1.5, f"{m:.0f}%", ha="center", fontsize=8)
ax.set_xticks(range(4))
ax.set_xticklabels([f"{g.replace('-middle','-mid.')}\n(n={c})" for g, c in zip(order, grp["count"])], fontsize=8)
ax.set_ylabel("Learning poverty (%)", fontsize=8.5)
ax.set_ylim(0, 105)
ptitle(ax, "C  Learning poverty by income")

years = list(range(2000, 2020))
def trend(ax, var, label, title, legend=False):
    for g in order:
        d = panel[(panel.year >= 2000) & (panel.year <= 2019) & (panel.income_group == g)]
        vals = []
        for y in years:
            dy = d[d.year == y].dropna(subset=[var, "pop"])
            vals.append(np.average(dy[var], weights=dy["pop"]) if len(dy) else np.nan)
        ax.plot(years, vals, color=cols[g], lw=1.5, label=g.replace("-middle", "-mid."))
    ptitle(ax, title)
    ax.set_ylabel(label, fontsize=8.5)
    ax.set_xlim(2000, 2019)
    if legend:
        ax.legend(loc="upper left", ncol=1, handlelength=0.6, handletextpad=0.35,
                  labelspacing=0.28, borderaxespad=0.15, fontsize=8, frameon=False)

ax = fig.add_subplot(gs[2, 0:2])
trend(ax, "internet", "Internet users (%)", "D  Internet, 2000–2019", legend=True)
ax = fig.add_subplot(gs[2, 2:4])
trend(ax, "exp_prim_pc", "Spend/student\n(% GDP p.c.)", "E  Per-student spending")
ax = fig.add_subplot(gs[2, 4:6])
trend(ax, "ptr", "Pupil–teacher ratio", "F  Class size proxy")
ax.set_xlabel("Year", fontsize=8.5)
qa_texts(fig, "fig2")
fig.savefig("figures/fig2_landscape.png")
plt.close(fig)
print("fig2 done")

# ============================================================ FIGURE 3: associations (9 panels)
fig, axes = plt.subplots(3, 3, figsize=(W, 8.6), gridspec_kw={"width_ratios": [0.88, 1.24, 0.88]})
sc = [("log_gdp_pc", "log$_{10}$ GDP p.c.", "A  Wealth"),
      ("internet_avg", "Internet users (%)", "B  Digital access"),
      ("exp_prim_pc_avg", "Per-student spending\n(% GDP p.c.)", "C  Spending"),
      ("trained_teachers_avg", "Trained teachers (%)", "D  Teachers")]
for ax, (v, lab, t) in zip([axes[0, 0], axes[0, 1], axes[0, 2], axes[1, 0]], sc):
    d = X.dropna(subset=["hlo", v])
    ax.scatter(d[v], d.hlo, s=9, color="#2171b5", alpha=0.5, linewidths=0)
    b, a = np.polyfit(d[v], d.hlo, 1)
    xs = np.linspace(d[v].min(), d[v].max(), 50)
    ax.plot(xs, a + b * xs, color=ACCENT, lw=1.4)
    r = np.corrcoef(d[v], d.hlo)[0, 1]
    if t.startswith("B"):
        ax.text(0.97, 0.05, f"r = {r:.2f}\nn = {len(d)}", transform=ax.transAxes, va="bottom",
                ha="right", fontsize=8, linespacing=1.2,
                bbox=dict(facecolor="white", edgecolor="none", alpha=0.85, pad=1.2))
    else:
        ax.text(0.03, 0.97, f"r = {r:.2f}\nn = {len(d)}", transform=ax.transAxes, va="top",
                ha="left", fontsize=8, linespacing=1.2,
                bbox=dict(facecolor="white", edgecolor="none", alpha=0.85, pad=1.2))
    ax.set_xlabel(lab, fontsize=8)
    ax.set_ylabel("HLO score", fontsize=8)
    if v == "trained_teachers_avg":
        ax.set_xlim(12, 108)
    ptitle(ax, t)

ax = axes[1, 1]
zcols = ["hlo", "log_gdp_pc", "edu_exp_gdp_avg", "exp_prim_pc_avg", "exp_sec_pc_avg",
         "ptr_avg", "trained_teachers_avg", "internet_avg"]
Z = X.dropna(subset=zcols).copy()
for c in zcols:
    Z[c] = (Z[c] - Z[c].mean()) / Z[c].std()
m3z = smf.ols("hlo ~ log_gdp_pc + edu_exp_gdp_avg + exp_prim_pc_avg + exp_sec_pc_avg + ptr_avg + trained_teachers_avg + internet_avg", Z).fit(cov_type="HC1")
labels = {"internet_avg": "Internet", "exp_prim_pc_avg": "Spend/pc",
          "trained_teachers_avg": "Teachers", "ptr_avg": "Pupil–tch",
          "exp_sec_pc_avg": "Spend/sec", "edu_exp_gdp_avg": "Edu. exp.",
          "log_gdp_pc": "log GDP"}
items = [(k, m3z.params[k], m3z.bse[k], m3z.pvalues[k]) for k in labels]
items.sort(key=lambda t: -t[1])
ypos = np.arange(len(items))[::-1]
for y, (k, b, se, p) in zip(ypos, items):
    col = ACCENT if p < 0.05 else "#2171b5"
    ax.errorbar(b, y, xerr=1.96 * se, fmt="o", color=col, ms=3.2, capsize=2, lw=0.9)
ax.axvline(0, color="#666666", lw=0.9)
ax.set_yticks(ypos); ax.set_yticklabels([labels[k] for k, _, _, _ in items], fontsize=8)
ax.set_xlabel("Standardized β (95% CI)", fontsize=8)
ax.set_ylim(-0.6, len(items) - 0.15)
ax.set_title("E  Std. effects (M3)", loc="left", fontweight="bold", fontsize=9.5, pad=7)

ax = axes[1, 2]
r2s = [("GDP only", 0.483), ("Internet only", 0.611), ("GDP + resources", 0.576), ("GDP + res + net", 0.667)]
vals = [r[1] for r in r2s]
c5 = ["#9ecae1", ACCENT, "#6baed6", "#08306b"]
ax.barh(range(len(vals))[::-1], vals, color=c5, alpha=0.9, height=0.6)
for i, v in zip(range(len(vals))[::-1], vals):
    ax.text(v + 0.015, i, f"{v:.2f}", va="center", fontsize=8)
ax.set_yticks(range(len(vals))[::-1]); ax.set_yticklabels([r[0] for r in r2s], fontsize=8)
ax.set_xlim(0, 0.85); ax.set_xlabel("R$^2$ (N = 83)", fontsize=8, labelpad=2)
ax.set_ylim(-0.55, len(vals) - 0.45)
ptitle(ax, "F  R² comparison")
ax.grid(axis="y", visible=False)

ax = axes[2, 0]
sh = up["shapley_groups"]
gkeys = ["Digital", "Wealth", "Instructional", "Financial"]
gorder = ["Digital", "Wealth", "Instruct.", "Financial"]
gvals = [sh[g] * 100 for g in gkeys]
gcols = [ACCENT, BLUE_D, BLUE_M, "#9ecae1"]
yp = np.arange(4)[::-1]
ax.barh(yp, gvals, color=gcols, alpha=0.92, height=0.6)
for y, v in zip(yp, gvals):
    ax.text(v + 1.2, y, f"{v:.1f}%", va="center", fontsize=8, fontweight="bold")
ax.set_yticks(yp); ax.set_yticklabels(gorder, fontsize=8)
ax.set_xlim(0, 52); ax.set_xlabel("Share of explained variance (%)", fontsize=8)
ptitle(ax, "G  Shapley")
ax.grid(axis="y", visible=False)

ax = axes[2, 1]
Cm = pd.read_csv("data/corr_matrix.csv", index_col=0)
lab_map = {"hlo": "HLO", "log_gdp_pc": "GDP", "edu_exp_gdp_avg": "Exp", "exp_prim_pc_avg": "Sp/pc",
           "ptr_avg": "PTR", "trained_teachers_avg": "Tch", "internet_avg": "Net",
           "tertiary_avg": "Ter", "gpi_sec_avg": "GPI", "gini_avg": "Gini", "rural_avg": "Rur"}
Cm = Cm.rename(index=lab_map, columns=lab_map)
im = ax.imshow(Cm.values, cmap="RdBu_r", vmin=-1, vmax=1, aspect="equal")
ax.set_xticks(range(len(Cm)))
ax.set_xticklabels([""] * len(Cm))
for i, lab in enumerate(Cm.columns):
    ax.text(i, -0.06 - (0.16 if i % 2 else 0.0), lab, transform=ax.get_xaxis_transform(),
            ha="right", va="top", fontsize=8, rotation=45, clip_on=False)
ax.set_yticks(range(len(Cm))); ax.set_yticklabels(Cm.index, fontsize=8)
ptitle(ax, "H  Correlations")
ax.grid(False)
cb = fig.colorbar(im, ax=ax, fraction=0.032, pad=0.012, ticks=[-1, 0, 1])
cb.ax.tick_params(labelsize=8, pad=1)

ax = axes[2, 2]
ost = up["oster"]
olabs = ["Internet", "Spend/pc", "Teachers", "log GDP"]
okeys = ["internet_avg", "exp_prim_pc_avg", "trained_teachers_avg", "log_gdp_pc"]
deltas = [ost[k]["delta"] for k in okeys]
ocolors = [ACCENT, BLUE_M, BLUE_M, BLUE_L]
yp = np.arange(4)[::-1]
ax.barh(yp, deltas, color=ocolors, alpha=0.9, height=0.6)
for y, v in zip(yp, deltas):
    ax.text(v + 0.3, y, f"δ = {v:.1f}", va="center", fontsize=8, fontweight="bold", clip_on=False)
ax.axvline(1, color="#666666", lw=0.9, ls="--")
ax.text(1.4, 4.05, "dashed: δ = 1", fontsize=8,
        color="#222222", va="center", ha="left",
        bbox=dict(facecolor="white", edgecolor="none", alpha=0.9, pad=1.4))
ax.set_ylim(-0.55, 4.7)
ax.set_yticks(yp); ax.set_yticklabels(olabs, fontsize=8)
ax.set_xlim(0, 12.5); ax.set_xlabel("Oster δ breakeven", fontsize=8)
ptitle(ax, "I  Oster δ bounds")
ax.grid(axis="y", visible=False)

fig.subplots_adjust(hspace=0.72, wspace=0.95, bottom=0.16)
qa_texts(fig, "fig3")
fig.savefig("figures/fig3_associations.png")
plt.close(fig)
print("fig3 done")

# ============================================================ FIGURE 4: robustness + identification (9 panels)
S = pd.read_csv("data/spec_curve.csv").sort_values("coef").reset_index(drop=True)
J = pd.read_csv("data/jackknife.csv").sort_values("coef")
lp = json.load(open("data/lead_placebo.json", encoding="utf-8"))
gf = json.load(open("data/gapfill_analyses.json", encoding="utf-8"))
tel_raw2 = json.load(open("data/wdi_fixed_telephone.json", encoding="utf-8"))

fig, axes = plt.subplots(3, 3, figsize=(W, 8.2))
ax = axes[0, 0]
for i, r in S.iterrows():
    col = ACCENT if r.p < 0.05 else "#9ecae1"
    ax.plot([i, i], [r.coef - 1.96 * r.se, r.coef + 1.96 * r.se], color=col, lw=1.0, alpha=0.85)
    ax.plot(i, r.coef, "o", color=col, ms=3.2)
ax.axhline(0, color="#666666", lw=0.9)
ax.set_xlim(-0.8, 17.8)
ax.set_xticks([0, 5, 10, 15])
ax.set_xlabel("Specification (sorted)", fontsize=8)
ax.set_ylabel("Coefficient, digital access", fontsize=8)
ptitle(ax, "A  Specification curve (18)")
ax.text(0.02, 0.95, "orange: p < 0.05", transform=ax.transAxes, fontsize=8, va="top")

ax = axes[0, 1]
ypos = np.arange(len(J))[::-1]
for y, (_, r) in zip(ypos, J.iterrows()):
    ax.errorbar(r.coef, y, xerr=1.96 * r.se, fmt="s", color="#2171b5", ms=4, capsize=2.5, lw=1.1)
ax.axvline(0, color="#666666", lw=0.9)
ax.axvline(2.394, color=ACCENT, lw=1.1, ls="--")
ax.set_yticks(ypos)
ax.set_yticklabels([s.replace("Middle East, North Africa, Afghanistan & Pakistan", "MENA+A/Pak.")
                    .replace("Latin America & Caribbean", "Latin America")
                    .replace("East Asia & Pacific", "E. Asia & Pac.")
                    .replace("Europe & Central Asia", "Eur. & C. Asia") for s in J.dropped], fontsize=8)
ax.set_xlabel("Internet coefficient", fontsize=8)
ptitle(ax, "B  Leave-one-region-out")

ax = axes[0, 2]
items = [("Pre-outcome\n2000–15", 2.394, 0.496, 83, BLUE_D),
         ("Lead\n2016–18", lp["2016-2018"]["internet"], 0.682, lp["2016-2018"]["n"], BLUE_L),
         ("Lead\n2016–22", lp["2016-2022"]["internet"], 0.659, lp["2016-2022"]["n"], BLUE_L)]
for i, (lab, b, se, n, col) in enumerate(items):
    ax.bar(i, b, color=col, alpha=0.9, width=0.55)
    ax.errorbar(i, b, yerr=1.96 * se, fmt="none", ecolor="#333333", capsize=3.5, lw=1.1)
    ax.text(i, b + 0.18, f"{b:.2f}", ha="center", fontsize=8, fontweight="bold",
            bbox=dict(facecolor="white", edgecolor="none", alpha=0.9, pad=1.5))
ax.axhline(0, color="#666666", lw=0.9)
ax.set_xticks(range(3)); ax.set_xticklabels([i[0] for i in items], fontsize=8, rotation=32, ha="right")
ax.set_ylabel("Internet coefficient (95% CI)", fontsize=8)
ax.set_ylim(-0.55, 3.6)
ptitle(ax, "C  Temporal falsification")

ax = axes[1, 0]
d = X.dropna(subset=["hlo", "internet_avg"])
ax.scatter(d.internet_avg, d.hlo, s=9, color="#2171b5", alpha=0.5, linewidths=0)
mm = smf.ols("hlo ~ internet_avg + np.power(internet_avg, 2)", d).fit()
xs = np.linspace(d.internet_avg.min(), d.internet_avg.max(), 200)
ax.plot(xs, mm.params["Intercept"] + mm.params["internet_avg"] * xs + mm.params["np.power(internet_avg, 2)"] * xs**2,
        color=ACCENT, lw=1.5)
ax.set_xlim(0, 85)
ax.set_xlabel("Internet users (%)", fontsize=8)
ax.set_ylabel("HLO score", fontsize=8)
ptitle(ax, "D  Convex returns to digital")
ax.text(0.97, 0.05, "quadratic p = 0.017", transform=ax.transAxes, va="bottom",
        ha="right", fontsize=8, color=ACCENT,
        bbox=dict(facecolor="white", edgecolor="none", alpha=0.85, pad=1.2))

ax = axes[1, 1]
het = up.get("heterogeneity_income", None) or json.load(open("data/analysis_out3.json", encoding="utf-8"))["heterogeneity_income"]
groups = ["High", "Upper-middle", "Lower-middle"]
vars_ = ["internet_avg", "exp_prim_pc_avg", "trained_teachers_avg"]
vlab = ["Internet", "Spend/pc", "Teachers"]
xpos = np.arange(3); w = 0.26
gcol = {"High": BLUE_D, "Upper-middle": BLUE_M, "Lower-middle": BLUE_L}
for i, g in enumerate(groups):
    for j, v in enumerate(vars_):
        if g in het and v in het[g]["params"]:
            ax.bar(xpos[j] + (i - 1) * w, het[g]["params"][v], width=w * 0.9, color=gcol[g], alpha=0.9,
                   label=g.replace("-middle", "-mid.") if j == 0 else None)
ax.axhline(0, color="#666666", lw=0.9)
ax.set_xticks(xpos); ax.set_xticklabels(vlab, fontsize=8, rotation=32, ha="right")
ax.set_ylabel("Coefficient (unstandardized)", fontsize=8)
ax.set_ylim(-1.3, 5.2)
ptitle(ax, "E  Effects by income")
ax.legend(loc="upper right", bbox_to_anchor=(1.02, 1.0), fontsize=8, frameon=False,
          handlelength=0.8, handletextpad=0.45, labelspacing=0.35, borderaxespad=0)

ax = axes[1, 2]
q = up["quantile"]
qs = ["0.1", "0.25", "0.5", "0.75", "0.9"]
xs_q = [10, 25, 50, 75, 90]
y_net = [q[k]["internet"] for k in qs]
y_sp = [q[k]["exp_prim"] for k in qs]
p_net = [q[k]["internet_p"] for k in qs]
ax.plot(xs_q, y_net, "o-", color=ACCENT, lw=1.5, ms=5, label="Internet users")
ax.plot(xs_q, y_sp, "s--", color=BLUE_M, lw=1.5, ms=5, label="Spend/student")
for x, y_, p_ in zip(xs_q, y_net, p_net):
    if p_ < 0.05:
        ax.plot(x, y_, "o", color=ACCENT, ms=8, mfc="none", mew=1.2)
ax.axhline(0, color="#666666", lw=0.8)
ax.set_xticks(xs_q); ax.set_xticklabels(["10", "25", "50", "75", "90"], fontsize=8)
ax.set_xlabel("Outcome percentile", fontsize=8)
ax.set_ylabel("Quantile coefficient", fontsize=8)
ptitle(ax, "F  Quantile associations")
ax.legend(loc="lower right", fontsize=8, frameon=False,
          handlelength=0.8, handletextpad=0.45, labelspacing=0.35)
ax.text(0.03, 0.22, "ring = p < 0.05", transform=ax.transAxes, fontsize=8,
        color="#222222", va="bottom", ha="left",
        bbox=dict(facecolor="white", edgecolor="none", alpha=0.85, pad=1.2))

# ---- G: IV first stage (telephone 1995-2000 -> internet)
ax = axes[2, 0]
tel = {}
for iso, ys in tel_raw2.items():
    vals = [v for yy, v in ys.items() if 1995 <= int(yy) <= 2000 and v is not None]
    if vals:
        tel[iso] = float(np.mean(vals))
Dg = X.dropna(subset=["hlo", "internet_avg", "log_gdp_pc"]).copy()
Dg["tel"] = Dg.iso3.map(tel)
Dg = Dg.dropna(subset=["tel"])
ax.scatter(Dg.tel, Dg.internet_avg, s=9, color="#2171b5", alpha=0.55, linewidths=0)
bb, aa = np.polyfit(Dg.tel, Dg.internet_avg, 1)
xs = np.linspace(Dg.tel.min(), Dg.tel.max(), 50)
ax.plot(xs, aa + bb * xs, color=ACCENT, lw=1.5)
ax.set_xlabel("Fixed telephone (per 100, 1995–2000)", fontsize=8)
ax.set_ylabel("Internet users (%)", fontsize=8)
ptitle(ax, "G  IV first stage")
ax.text(0.97, 0.05, f"F = {gf['iv']['first_stage_F']:.0f}", transform=ax.transAxes,
        va="bottom", ha="right", fontsize=8, color=ACCENT,
        bbox=dict(facecolor="white", edgecolor="none", alpha=0.85, pad=1.2))

# ---- H: Hansen threshold profile (SSR vs split point on log GDP)
ax = axes[2, 1]
Dt2 = X.dropna(subset=["hlo", "internet_avg", "log_gdp_pc", "edu_exp_gdp_avg",
                       "exp_prim_pc_avg", "exp_sec_pc_avg", "ptr_avg", "trained_teachers_avg"]).copy()
qt2 = Dt2["log_gdp_pc"].to_numpy(float)
yv2 = Dt2["hlo"].to_numpy(float)
Xc2 = sm.add_constant(Dt2[["internet_avg", "log_gdp_pc", "edu_exp_gdp_avg", "exp_prim_pc_avg",
                           "exp_sec_pc_avg", "ptr_avg", "trained_teachers_avg"]].to_numpy(float))
cands2 = np.quantile(qt2, np.linspace(0.15, 0.85, 29))
ssr_prof = []
for g in cands2:
    loq = qt2 <= g
    if loq.sum() < 12 or (~loq).sum() < 12:
        ssr_prof.append(np.nan)
        continue
    ssr_prof.append(float(sm.OLS(yv2[loq], Xc2[loq]).fit().ssr + sm.OLS(yv2[~loq], Xc2[~loq]).fit().ssr))
ax.plot(cands2, ssr_prof, "-", color=BLUE_M, lw=1.5)
g_hat = gf["threshold"]["gamma_hat"]
ax.axvline(g_hat, color=ACCENT, lw=1.2, ls="--")
ax.text(0.97, 0.95, f"γ = {g_hat:.2f}\np = {gf['threshold']['boot_p']:.3f}", transform=ax.transAxes,
        va="top", ha="right", fontsize=8, color="#222222",
        bbox=dict(facecolor="white", edgecolor="none", alpha=0.85, pad=1.2))
ax.set_xlabel("Threshold: log$_{10}$ GDP p.c.", fontsize=8)
ax.set_ylabel("Pooled SSR of two regimes", fontsize=8)
ptitle(ax, "H  Hansen threshold")

# ---- I: H3 stratified slopes (digital x teacher scarcity)
ax = axes[2, 2]
bars = [("Low trained\nteachers", gf["h3"]["internet_low_teacher"], BLUE_L, gf["h3"]["internet_low_teacher_N"]),
        ("High trained\nteachers", gf["h3"]["internet_high_teacher"], BLUE_D, gf["h3"]["internet_high_teacher_N"])]
for i, (lab, v, col, n) in enumerate(bars):
    ax.bar(i, v, color=col, alpha=0.9, width=0.55)
    ax.text(i, v + 0.12, f"{v:.2f}", ha="center", fontsize=8, fontweight="bold",
            bbox=dict(facecolor="white", edgecolor="none", alpha=0.9, pad=1.2))
    ax.text(i, -0.42, f"N = {n}", ha="center", fontsize=8, color="#555555")
ax.axhline(0, color="#666666", lw=0.9)
ax.set_xticks([0, 1]); ax.set_xticklabels([b[0] for b in bars], fontsize=8)
ax.set_ylabel("Internet coefficient", fontsize=8)
ax.set_ylim(-0.6, 3.2)
ptitle(ax, "I  H3: digital × scarcity")
ax.text(0.5, 0.97, f"interaction p = {gf['h3']['interaction_p']:.3f}", transform=ax.transAxes,
        va="top", ha="center", fontsize=8, color="#222222",
        bbox=dict(facecolor="white", edgecolor="none", alpha=0.85, pad=1.2))

fig.tight_layout(h_pad=1.8, w_pad=2.0)
qa_texts(fig, "fig4")
fig.savefig("figures/fig4_robustness.png")
plt.close(fig)
print("fig4 done")

# ============================================================ FIGURE 5: extensions (6 panels)
C = pd.read_csv("data/convergence.csv").dropna(subset=["dlog", "log05"])
E = pd.read_csv("data/hlo_efficiency.csv")

fig = plt.figure(figsize=(W, 7.6))
gs = fig.add_gridspec(2, 3, height_ratios=[1, 1.45], hspace=0.55, wspace=1.05,
                      width_ratios=[0.9, 1.28, 0.88])

ax = fig.add_subplot(gs[0, 0])
ax.scatter(C.log05, C.dlog * 100, s=11, color="#2171b5", alpha=0.6, linewidths=0)
b, a = np.polyfit(C.log05, C.dlog * 100, 1)
xs = np.linspace(C.log05.min(), C.log05.max(), 50)
ax.plot(xs, a + b * xs, color=ACCENT, lw=1.5)
ax.axhline(0, color="#666666", lw=0.9)
ax.set_xlabel("log test score, 2005", fontsize=8)
ax.set_ylabel("Δ log score, 2005→2010 (×100)", fontsize=8)
ptitle(ax, "A  β-convergence (N = 59)")
ax.text(0.03, 0.05, f"slope = {up['convergence']['beta_coef']:.3f}, p < 0.001", transform=ax.transAxes, fontsize=8)

ax = fig.add_subplot(gs[0, 1])
Lm = L.merge(panel[panel.year == 2017][["iso3", "hlo"]].dropna(), on="iso3", how="inner").dropna(subset=["hlo", "lp"])
Lm = Lm[np.isfinite(Lm.hlo) & np.isfinite(Lm.lp)]
ax.scatter(Lm.hlo, Lm.lp, s=11, color="#2171b5", alpha=0.6, linewidths=0)
b, a = np.polyfit(Lm.hlo, Lm.lp, 1)
xs = np.linspace(Lm.hlo.min(), Lm.hlo.max(), 50)
ax.plot(xs, a + b * xs, color=ACCENT, lw=1.5)
r = np.corrcoef(Lm.hlo, Lm.lp)[0, 1]
ax.text(0.03, 0.05, f"r = {r:.2f}, n = {len(Lm)}", transform=ax.transAxes, fontsize=8)
ax.set_xlabel("HLO score (2017)", fontsize=8)
ax.set_ylabel("Learning poverty (%)", fontsize=8)
ptitle(ax, "B  Two outcomes agree")

ax = fig.add_subplot(gs[0, 2])
G = panel[panel.year == 2017][["iso3", "hlo_female", "hlo_male"]].dropna(subset=["hlo_female"])
G["gap"] = G.hlo_female - G.hlo_male
bins = np.arange(-25, 60, 5)
ax.hist(G.gap, bins=bins, color="#2171b5", alpha=0.85, edgecolor="white", lw=0.5)
ax.axvline(G.gap.mean(), color=ACCENT, lw=1.3, ls="--")
ax.axvline(0, color="#666666", lw=0.9)
ax.text(G.gap.mean() + 1.5, ax.get_ylim()[1] * 0.92, f"mean = +{G.gap.mean():.1f}", color=ACCENT, fontsize=8)
ax.text(0.97, 0.05, f"{(G.gap < 0).sum()} countries:\nboys ahead", transform=ax.transAxes, fontsize=8,
        color="#333333", linespacing=1.3, ha="right", va="bottom",
        bbox=dict(facecolor="white", edgecolor="none", alpha=0.85, pad=1.5))
ax.set_xlabel("Female minus male HLO", fontsize=8)
ax.set_ylabel("Countries", fontsize=8)
ptitle(ax, f"C  Gender gaps (N = {len(G)})")

ax = fig.add_subplot(gs[1, 0])
Lg = L.dropna(subset=["lp_female", "lp_male"])
Lg = Lg[Lg.iso3.isin(set(meta.iso3))].merge(meta[["iso3", "income_group"]], on="iso3", how="left", suffixes=("", "_y"))
Lg["lpgap"] = Lg.lp_male - Lg.lp_female
means = [Lg[Lg.income_group == g].lpgap.mean() for g in order]
ns = [len(Lg[Lg.income_group == g]) for g in order]
ax.bar(range(4), means, color=[cols[g] for g in order], alpha=0.88, width=0.6)
lo, hi = min(means + [0]), max(means + [0])
ax.set_ylim(lo - 3.4, hi * 1.55)
for i, (m, n) in enumerate(zip(means, ns)):
    if m >= 0:
        ax.text(i, m + 0.3, f"+{m:.1f}", ha="center", va="bottom", fontsize=8, fontweight="bold")
    else:
        ax.text(i, m - 0.3, f"{m:.1f}", ha="center", va="top", fontsize=8, fontweight="bold")
ax.axhline(0, color="#666666", lw=1.0)
ax.set_xticks(range(4))
ax.set_xticklabels(["High", "Up-mid.", "Lo-mid.", "Low"], fontsize=8, rotation=32, ha="right")
ax.set_ylabel("Male − female learning poverty (pp)", fontsize=8)
ptitle(ax, "D  LP gender gap")
ax.text(0.5, 0.97, f"boys higher in {100*(Lg.lpgap>0).mean():.0f}% of {len(Lg)} countries",
        transform=ax.transAxes, fontsize=8, color="#333333", va="top", ha="center",
        bbox=dict(facecolor="white", edgecolor="none", alpha=0.85, pad=1.2))

ax = fig.add_subplot(gs[1, 1])
top = E.head(8); bot = E.tail(8).iloc[::-1]
sel = pd.concat([top, bot])
cols10 = ["#1a9850"] * 8 + ["#d73027"] * 8
y = np.arange(16)
rename = {"Dominican Republic": "Dominican Rep.", "Egypt, Arab Rep.": "Egypt",
          "Korea, Rep.": "Korea, Rep.", "South Africa": "South Africa"}
names = [rename.get(c, c) for c in sel.country.values]
ax.barh(y, sel.resid_gdp.values, color=cols10, alpha=0.88, height=0.68)
ax.set_yticks(y)
ax.set_yticklabels(names, fontsize=8)
ax.axvline(0, color="#666666", lw=1.0)
ax.set_xlabel("Residual vs income prediction", fontsize=8)
ptitle(ax, "E  Over-/under-performers")
ax.set_ylim(16.6, -1.2); ax.set_xlim(-140, 130)
ax.grid(axis="y", visible=False)
bb = dict(facecolor="white", edgecolor="none", alpha=0.85, pad=1.2)
ax.text(0.02, 0.72, "Over-performers\n(top 8)", color="#1a9850", fontsize=8,
        ha="left", va="center", fontweight="bold", linespacing=1.3, transform=ax.transAxes, bbox=bb)
ax.text(0.98, 0.27, "Under-performers\n(bottom 8)", color="#d73027", fontsize=8,
        ha="right", va="center", fontweight="bold", linespacing=1.3, transform=ax.transAxes, bbox=bb)

ax = fig.add_subplot(gs[1, 2])
d = E.dropna(subset=["exp_prim_pc_avg", "resid_gdp"])
ax.scatter(d.exp_prim_pc_avg, d.resid_gdp, s=11, color="#2171b5", alpha=0.55, linewidths=0)
b, a = np.polyfit(d.exp_prim_pc_avg, d.resid_gdp, 1)
xs = np.linspace(d.exp_prim_pc_avg.min(), d.exp_prim_pc_avg.max(), 50)
ax.plot(xs, a + b * xs, color=ACCENT, lw=1.5)
r = np.corrcoef(d.exp_prim_pc_avg, d.resid_gdp)[0, 1]
ax.text(0.03, 0.05, f"r = {r:.2f}, n = {len(d)}", transform=ax.transAxes, fontsize=8)
ax.axhline(0, color="#666666", lw=0.9)
ax.set_xlabel("Per-student spending\n(% GDP p.c.)", fontsize=8)
ax.set_ylabel("Residual from income model", fontsize=8)
ptitle(ax, "F  Resources vs over-performance")

qa_texts(fig, "fig5")
fig.savefig("figures/fig5_extensions.png")
plt.close(fig)
print("fig5 done")
