"""Relevance audit: extract the citation context of every reference."""
import re

t = open("manuscript.md", encoding="utf-8").read()
body = t[:t.find("## FIGURE LEGENDS")]
# also include methods/backmatter for citations there
full = t

# map key -> reference text
refs = {}
for m in re.finditer(r"^\{([A-Za-z0-9]+)\} (.+)$", t, re.M):
    refs[m.group(1)] = m.group(2).strip()

# split body into sentences (rough)
text = re.sub(r"\s+", " ", body)
sentences = re.split(r"(?<=[.;])\s+", text)

# for each key, find sentences citing it
usage = {k: [] for k in refs}
for s in sentences:
    for m in re.finditer(r"\{([^}]+)\}", s):
        for k in m.group(1).split(","):
            k = k.strip()
            if k in usage:
                usage[k].append(s)

print("REFERENCE RELEVANCE AUDIT (context in which each reference is cited)\n")
for i, (k, ref) in enumerate(refs.items(), 1):
    ctxs = usage[k]
    short_ref = ref[:95]
    print(f"[{i:2d}] {k}")
    print(f"     REF: {short_ref}")
    if not ctxs:
        print(f"     CTX: (cited only in back-matter or not found)")
    for c in ctxs[:2]:
        # show the sentence with the citation group
        c2 = c.strip()
        if len(c2) > 300:
            c2 = c2[:300] + "..."
        print(f"     CTX: {c2}")
    print()
