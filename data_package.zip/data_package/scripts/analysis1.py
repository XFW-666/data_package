"""Core analysis: cross-national determinants of learning outcomes.
All data from World Bank public API (WDI, EdStats, HCI/learning poverty).
"""
import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

pd.set_option("display.width", 200)
pd.set_option("display.max_columns", 50)

panel = pd.read_csv("data/master_panel.csv")
countries = json.load(open("data/countries.json", encoding="utf-8"))
meta = pd.DataFrame([
    {"iso3": k, "country": v["name"], "region": v["region"], "income": v["income"]}
    for k, v in countries.items() if not v["is_aggregate"]
])

out = {}

# ---------------------------------------------------------------- helpers
def avg_window(df, var, y0, y1):
    sub = df[(df.year >= y0) & (df.year <= y1)]
    g = sub.groupby("iso3")[var].mean()
    return g

def build_xsec(outcome_year, lag_start, lag_end, outcome="hlo"):
    df = panel.copy()
    d = df[df.year == outcome_year][["iso3", outcome]].dropna()
    cols = ["edu_exp_gdp", "exp_prim_pc", "exp_sec_pc", "ptr", "trained_teachers",
            "internet", "broadband", "mobile", "gdp_pc", "tertiary", "gpi_prim",
            "gpi_sec", "rural", "gini", "enroll_prim", "enroll_sec", "pop"]
    for c in cols:
        d = d.merge(avg_window(df, c, lag_start, lag_end).rename(f"{c}_avg"),
                    on="iso3", how="left")
    d["log_gdp_pc"] = np.log10(d["gdp_pc_avg"])
    d = d.merge(meta, on="iso3", how="left")
    return d

def ols(formula, data, cov="HC1"):
    m = smf.ols(formula, data=data).fit(cov_type=cov)
    return m

# ---------------------------------------------------------------- headline descriptives
h = panel[panel.year == 2017][["iso3", "hlo"]].dropna()
print("HLO 2017: n=%d, mean=%.1f, sd=%.1f, min=%.0f (%s), max=%.0f (%s)" % (
    len(h), h.hlo.mean(), h.hlo.std(), h.hlo.min(),
    meta.set_index("iso3").loc[h.loc[h.hlo.idxmin(), "iso3"], "country"],
    h.hlo.max(),
    meta.set_index("iso3").loc[h.loc[h.hlo.idxmax(), "iso3"], "country"]))
out["hlo_n"] = len(h); out["hlo_mean"] = h.hlo.mean(); out["hlo_sd"] = h.hlo.std()
out["hlo_min"] = h.hlo.min(); out["hlo_max"] = h.hlo.max()
out["hlo_min_country"] = meta.set_index("iso3").loc[h.loc[h.hlo.idxmin(), "iso3"], "country"]
out["hlo_max_country"] = meta.set_index("iso3").loc[h.loc[h.hlo.idxmax(), "iso3"], "country"]

# correlation GDP-HLO (5y avg)
x = build_xsec(2017, 2012, 2016)
r = x[["hlo", "log_gdp_pc", "edu_exp_gdp_avg", "exp_prim_pc_avg", "internet_avg",
       "trained_teachers_avg", "ptr_avg", "tertiary_avg", "gpi_sec_avg"]].corr()
print("\ncorrelations with HLO:\n", r["hlo"].round(3))
out["corr_hlo_gdp"] = float(r.loc["log_gdp_pc", "hlo"])
out["corr_hlo_exp"] = float(r.loc["edu_exp_gdp_avg", "hlo"])
out["corr_hlo_expprim"] = float(r.loc["exp_prim_pc_avg", "hlo"])
out["corr_hlo_internet"] = float(r.loc["internet_avg", "hlo"])
out["corr_hlo_teachers"] = float(r.loc["trained_teachers_avg", "hlo"])
out["corr_hlo_ptr"] = float(r.loc["ptr_avg", "hlo"])

# learning poverty descriptives
lp = panel[panel.year.isin([2019, 2021])][["iso3", "year", "lp"]].dropna()
lp = lp.merge(meta, on="iso3", how="left")
print("\nLP waves: n=%d countries, mean=%.1f" % (lp.iso3.nunique(), lp.lp.mean()))
out["lp_n"] = int(lp.iso3.nunique()); out["lp_mean"] = float(lp.lp.mean())
for w in [2019, 2021]:
    sub = lp[lp.year == w]
    print("  %d wave: n=%d, mean=%.1f, share>50%%=%.1f%%" % (
        w, len(sub), sub.lp.mean(), 100 * (sub.lp > 50).mean()))
    out[f"lp_{w}_n"] = len(sub); out[f"lp_{w}_mean"] = float(sub.lp.mean())
    out[f"lp_{w}_share50"] = float(100 * (sub.lp > 50).mean())

# ---------------------------------------------------------------- main models (HLO 2017)
X5 = build_xsec(2017, 2012, 2016).dropna(subset=["hlo"])
X10 = build_xsec(2017, 2007, 2016).dropna(subset=["hlo"])
print("\nHLO 5y-lag sample:", len(X5), " 10y-lag sample:", len(X10))

m1 = ols("hlo ~ log_gdp_pc", X5)
m2 = ols("hlo ~ log_gdp_pc + edu_exp_gdp_avg + exp_prim_pc_avg + exp_sec_pc_avg + ptr_avg + trained_teachers_avg", X5)
m3 = ols("hlo ~ log_gdp_pc + edu_exp_gdp_avg + exp_prim_pc_avg + exp_sec_pc_avg + ptr_avg + trained_teachers_avg + internet_avg + broadband_avg", X5)
m4 = ols("hlo ~ log_gdp_pc + edu_exp_gdp_avg + exp_prim_pc_avg + exp_sec_pc_avg + ptr_avg + trained_teachers_avg + internet_avg + broadband_avg + tertiary_avg + gpi_sec_avg + gini_avg + rural_avg", X5)
print("\nM1 R2=%.3f N=%d" % (m1.rsquared, int(m1.nobs)))
print("M2 R2=%.3f N=%d" % (m2.rsquared, int(m2.nobs)))
print("M3 R2=%.3f N=%d" % (m3.rsquared, int(m3.nobs)))
print("M4 R2=%.3f N=%d" % (m4.rsquared, int(m4.nobs)))
out["m1_r2"], out["m2_r2"], out["m3_r2"], out["m4_r2"] = m1.rsquared, m2.rsquared, m3.rsquared, m4.rsquared
out["m1_n"], out["m2_n"], out["m3_n"], out["m4_n"] = int(m1.nobs), int(m2.nobs), int(m3.nobs), int(m4.nobs)

print("\nM4 params:\n", m4.params.round(4))
print("\nM4 pvalues:\n", m4.pvalues.round(4))
print("\nM4 tvalues:\n", m4.tvalues.round(2))

# standardized version of M3
def standardize(df, cols):
    z = df.copy()
    for c in cols:
        z[c] = (z[c] - z[c].mean()) / z[c].std()
    return z

zcols = ["hlo", "log_gdp_pc", "edu_exp_gdp_avg", "exp_prim_pc_avg", "exp_sec_pc_avg",
         "ptr_avg", "trained_teachers_avg", "internet_avg", "broadband_avg"]
Z = standardize(X5.dropna(subset=["hlo", "log_gdp_pc", "edu_exp_gdp_avg", "exp_prim_pc_avg",
                                  "exp_sec_pc_avg", "ptr_avg", "trained_teachers_avg",
                                  "internet_avg", "broadband_avg"]), zcols)
m3z = smf.ols("hlo ~ log_gdp_pc + edu_exp_gdp_avg + exp_prim_pc_avg + exp_sec_pc_avg + ptr_avg + trained_teachers_avg + internet_avg + broadband_avg", Z).fit(cov_type="HC1")
print("\nM3 standardized betas:\n", m3z.params.round(3))

# 10-year lag version of M3
X10s = X10.dropna(subset=["hlo", "log_gdp_pc", "edu_exp_gdp_avg", "exp_prim_pc_avg",
                          "exp_sec_pc_avg", "ptr_avg", "trained_teachers_avg",
                          "internet_avg", "broadband_avg"])
m3_10 = ols("hlo ~ log_gdp_pc + edu_exp_gdp_avg + exp_prim_pc_avg + exp_sec_pc_avg + ptr_avg + trained_teachers_avg + internet_avg + broadband_avg", X10s)
print("\nM3 10y-lag R2=%.3f N=%d" % (m3_10.rsquared, int(m3_10.nobs)))
out["m3_10_r2"] = m3_10.rsquared; out["m3_10_n"] = int(m3_10.nobs)

# VIF for M3
from statsmodels.stats.outliers_influence import variance_inflation_factor
Xv = X5[["log_gdp_pc", "edu_exp_gdp_avg", "exp_prim_pc_avg", "exp_sec_pc_avg", "ptr_avg",
         "trained_teachers_avg", "internet_avg", "broadband_avg"]].dropna()
Xv = sm.add_constant(Xv)
vif = pd.Series([variance_inflation_factor(Xv.values, i) for i in range(Xv.shape[1])], index=Xv.columns)
print("\nVIF:\n", vif.round(2))
out["vif_max"] = float(vif.drop("const").max())

json.dump(out, open("data/analysis_out1.json", "w"), indent=1)
m1.summary().as_csv(); 
for name, m in [("m1", m1), ("m2", m2), ("m3", m3), ("m4", m4), ("m3z", m3z), ("m3_10", m3_10)]:
    open(f"data/model_{name}.txt", "w").write(str(m.summary()))
X5.to_csv("data/xsec_hlo_5y.csv", index=False)
X10.to_csv("data/xsec_hlo_10y.csv", index=False)
print("\nsaved.")
