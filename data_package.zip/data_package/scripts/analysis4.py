"""Analysis v4: refinements - LP log models, delta-LP, income interaction, EdStats overlap."""
import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

pd.set_option("display.width", 220); pd.set_option("display.max_columns", 60)
panel = pd.read_csv("data/master_panel.csv")
countries = json.load(open("data/countries.json", encoding="utf-8"))
meta = pd.DataFrame([
    {"iso3": k, "country": v["name"], "region": v["region"], "income": v["income"]}
    for k, v in countries.items() if not v["is_aggregate"]
])
meta["income_group"] = meta.income.map({
    "High income": "High", "Upper middle income": "Upper-middle",
    "Lower middle income": "Lower-middle", "Low income": "Low"})
out = {}

def avg_window(df, var, y0, y1):
    sub = df[(df.year >= y0) & (df.year <= y1)]
    return sub.groupby("iso3")[var].mean()

# ---------- EdStats wave overlaps
es = panel[["iso3", "year", "edstats_score"]].dropna()
es = es[es.iso3.isin(set(meta.iso3))]
for pair in [(2000, 2005), (2005, 2010), (2000, 2010), (1995, 2005)]:
    a = set(es[es.year == pair[0]].iso3); b = set(es[es.year == pair[1]].iso3)
    print("EdStats overlap", pair, ":", len(a & b))

# ---------- LP waves overlap
lp = panel[["iso3", "year", "lp"]].dropna()
lp = lp[lp.iso3.isin(set(meta.iso3))]
for pair in [(2006, 2011), (2011, 2016), (2016, 2019), (2019, 2021), (2006, 2016)]:
    a = set(lp[lp.year == pair[0]].iso3); b = set(lp[lp.year == pair[1]].iso3)
    print("LP overlap", pair, ":", len(a & b))

# ---------- LP latest with log transform
L = pd.read_csv("data/lp_latest.csv")
L = L[L.iso3.isin(set(meta.iso3))]
L["log_lp"] = np.log(L.lp.clip(lower=0.5))
l1 = smf.ols("log_lp ~ log_gdp_pc", L).fit(cov_type="HC1")
l2 = smf.ols("log_lp ~ log_gdp_pc + edu_exp_gdp_avg + exp_prim_pc_avg + ptr_avg + trained_teachers_avg + internet_avg", L).fit(cov_type="HC1")
l3 = smf.ols("log_lp ~ log_gdp_pc + edu_exp_gdp_avg + exp_prim_pc_avg + ptr_avg + trained_teachers_avg + internet_avg + tertiary_avg + gpi_sec_avg + rural_avg", L).fit(cov_type="HC1")
print("\n=== log(LP) models ===")
for nm, m in [("L1", l1), ("L2", l2), ("L3", l3)]:
    print("%s R2=%.3f N=%d" % (nm, m.rsquared, int(m.nobs)))
    print(m.params.round(3).to_string(), "\n")
out["loglp_l2_n"] = int(l2.nobs); out["loglp_l2_r2"] = float(l2.rsquared)
out["loglp_l3_n"] = int(l3.nobs); out["loglp_l3_r2"] = float(l3.rsquared)

# ---------- Delta-LP: countries with two LP waves >= 3 years apart
rows = []
for iso, g in lp.groupby("iso3"):
    g = g.sort_values("year")
    if len(g) >= 2:
        y0, y1 = int(g.year.iloc[0]), int(g.year.iloc[-1])
        if y1 - y0 < 3:
            continue
        rec = {"iso3": iso, "y0": y0, "y1": y1, "lp0": g.lp.iloc[0], "lp1": g.lp.iloc[-1]}
        for c in ["internet", "gdp_pc", "edu_exp_gdp", "exp_prim_pc"]:
            v0 = avg_window(panel, c, y0 - 5, y0 - 1).get(iso, np.nan)
            v1 = avg_window(panel, c, y1 - 5, y1 - 1).get(iso, np.nan)
            rec[f"d_{c}"] = v1 - v0 if (v0 is not None and v1 is not None) else np.nan
            rec[f"{c}_0"] = v0
        rows.append(rec)
D = pd.DataFrame(rows)
D["d_lp"] = D.lp1 - D.lp0
D = D.merge(meta, on="iso3", how="left")
print("\nDelta-LP countries:", len(D))
d1 = smf.ols("d_lp ~ d_internet + d_gdp_pc + d_edu_exp_gdp + d_exp_prim_pc", D).fit(cov_type="HC1")
print(d1.summary().tables[1])
out["delta_lp_n"] = int(d1.nobs)
out["delta_lp_r2"] = float(d1.rsquared)

# ---------- HLO: fully interacted income model
X = pd.read_csv("data/xsec_hlo_main.csv")
X = X[X.iso3.isin(set(meta.iso3))]
need = ["hlo", "log_gdp_pc", "edu_exp_gdp_avg", "exp_prim_pc_avg", "exp_sec_pc_avg", "ptr_avg", "trained_teachers_avg", "internet_avg"]
Xi = X.dropna(subset=need).copy()
Xi["high"] = (Xi.income_group == "High").astype(float)
base = "hlo ~ log_gdp_pc + edu_exp_gdp_avg + exp_prim_pc_avg + exp_sec_pc_avg + ptr_avg + trained_teachers_avg + internet_avg"
inter = base + " + high:log_gdp_pc + high:edu_exp_gdp_avg + high:exp_prim_pc_avg + high:exp_sec_pc_avg + high:ptr_avg + high:trained_teachers_avg + high:internet_avg"
mi = smf.ols(inter, Xi).fit(cov_type="HC1")
print("\n=== interacted model (high vs rest) ===")
print(mi.summary().tables[1])
# joint test of interaction terms
terms = [k for k in mi.params.index if k.startswith("high:")]
print("\ninteraction terms:", terms)
ftest = mi.f_test(" = ".join(terms) + " = 0")
print("joint F-test p-value:", ftest.pvalue)
out["inter_joint_p"] = float(ftest.pvalue)

# simple slopes for high vs rest
mh = smf.ols(base, Xi[Xi.high == 1]).fit(cov_type="HC1")
mr = smf.ols(base, Xi[Xi.high == 0]).fit(cov_type="HC1")
print("\nHigh income (N=%d): internet=%.3f (p=%.4f), exp_prim=%.3f (p=%.4f), trained=%.3f (p=%.4f)" % (
    int(mh.nobs), mh.params["internet_avg"], mh.pvalues["internet_avg"],
    mh.params["exp_prim_pc_avg"], mh.pvalues["exp_prim_pc_avg"],
    mh.params["trained_teachers_avg"], mh.pvalues["trained_teachers_avg"]))
print("Rest (N=%d): internet=%.3f (p=%.4f), exp_prim=%.3f (p=%.4f), trained=%.3f (p=%.4f)" % (
    int(mr.nobs), mr.params["internet_avg"], mr.pvalues["internet_avg"],
    mr.params["exp_prim_pc_avg"], mr.pvalues["exp_prim_pc_avg"],
    mr.params["trained_teachers_avg"], mr.pvalues["trained_teachers_avg"]))
out["high_slopes"] = {"n": int(mh.nobs), "internet": [float(mh.params["internet_avg"]), float(mh.pvalues["internet_avg"])],
                      "exp_prim": [float(mh.params["exp_prim_pc_avg"]), float(mh.pvalues["exp_prim_pc_avg"])],
                      "trained": [float(mh.params["trained_teachers_avg"]), float(mh.pvalues["trained_teachers_avg"])]}
out["rest_slopes"] = {"n": int(mr.nobs), "internet": [float(mr.params["internet_avg"]), float(mr.pvalues["internet_avg"])],
                      "exp_prim": [float(mr.params["exp_prim_pc_avg"]), float(mr.pvalues["exp_prim_pc_avg"])],
                      "trained": [float(mr.params["trained_teachers_avg"]), float(mr.pvalues["trained_teachers_avg"])]}

# ---------- LAYS as secondary outcome
Y = panel[panel.year == 2017][["iso3", "lays", "hlo"]].dropna()
for c in ["log_gdp_pc", "edu_exp_gdp", "exp_prim_pc", "internet", "tertiary", "trained_teachers", "ptr"]:
    pass
# build predictor windows
preds = {}
for c in ["edu_exp_gdp", "exp_prim_pc", "ptr", "trained_teachers", "internet", "gdp_pc", "tertiary"]:
    preds[c] = avg_window(panel, c, 2000, 2015)
Y = Y.set_index("iso3")
for c, s in preds.items():
    Y[f"{c}_avg"] = s
Y["log_gdp_pc"] = np.log10(Y.gdp_pc_avg)
Y = Y.reset_index()
lay1 = smf.ols("lays ~ log_gdp_pc", Y).fit(cov_type="HC1")
lay2 = smf.ols("lays ~ log_gdp_pc + edu_exp_gdp_avg + exp_prim_pc_avg + ptr_avg + trained_teachers_avg + internet_avg + tertiary_avg", Y).fit(cov_type="HC1")
print("\n=== LAYS models ===")
for nm, m in [("LAY1", lay1), ("LAY2", lay2)]:
    print("%s R2=%.3f N=%d" % (nm, m.rsquared, int(m.nobs)))
    print(m.params.round(3).to_string(), "\n")
out["lays_l2_n"] = int(lay2.nobs); out["lays_l2_r2"] = float(lay2.rsquared)

json.dump(out, open("data/analysis_out4.json", "w"), indent=1)
D.to_csv("data/delta_lp.csv", index=False)
print("saved v4.")
