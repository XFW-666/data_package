import json, time, urllib.request

JOBS = [
    ("data/wdi_rural.json", 2, "SP.RUR.TOTL.ZS"),
    ("data/wdi_enroll_prim.json", 2, "SE.PRM.ENRL"),
    ("data/wdi_enroll_sec.json", 2, "SE.SEC.ENRL"),
    ("data/wdi_gini.json", 2, "SI.POV.GINI"),
    ("data/wgi_goveff.json", 3, "GE.EST"),
]

def fetch(src, code, date="1995:2024"):
    rows, page = [], 1
    while True:
        url = (f"https://api.worldbank.org/v2/country/all/indicator/{code}"
               f"?format=json&per_page=5000&page={page}&date={date}&source={src}")
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (research)"})
        with urllib.request.urlopen(req, timeout=90) as r:
            d = json.loads(r.read().decode("utf-8"))
        rows.extend(d[1])
        print(code, "page", page, "/", d[0]["pages"], flush=True)
        if page >= d[0]["pages"]:
            break
        page += 1
    return rows

for path, src, code in JOBS:
    ok = False
    for attempt in range(3):
        try:
            rows = fetch(src, code)
            with open(path, "w", encoding="utf-8") as f:
                json.dump(rows, f, ensure_ascii=False)
            print("SAVED", path, len(rows), flush=True)
            ok = True
            break
        except Exception as e:
            print("retry", attempt, repr(e)[:120], flush=True)
            time.sleep(3)
    if not ok:
        print("FAILED", code, flush=True)
