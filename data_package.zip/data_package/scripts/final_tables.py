"""Produce final coefficient tables (CSV) used in the manuscript tables."""
import json
import numpy as np
import pandas as pd
import statsmodels.formula.api as smf

pd.set_option("display.width", 250)
X = pd.read_csv("data/xsec_hlo_main.csv")

NEED = ["hlo", "log_gdp_pc", "edu_exp_gdp_avg", "exp_prim_pc_avg", "exp_sec_pc_avg",
        "ptr_avg", "trained_teachers_avg", "internet_avg"]
Xc = X.dropna(subset=NEED)

models = {
    "M1": smf.ols("hlo ~ log_gdp_pc", Xc).fit(cov_type="HC1"),
    "M2": smf.ols("hlo ~ log_gdp_pc + edu_exp_gdp_avg + exp_prim_pc_avg + exp_sec_pc_avg + ptr_avg + trained_teachers_avg", Xc).fit(cov_type="HC1"),
    "M3": smf.ols("hlo ~ log_gdp_pc + edu_exp_gdp_avg + exp_prim_pc_avg + exp_sec_pc_avg + ptr_avg + trained_teachers_avg + internet_avg", Xc).fit(cov_type="HC1"),
    "M4": smf.ols("hlo ~ log_gdp_pc + edu_exp_gdp_avg + exp_prim_pc_avg + exp_sec_pc_avg + ptr_avg + trained_teachers_avg + internet_avg + tertiary_avg + gpi_sec_avg + gini_avg + rural_avg", Xc).fit(cov_type="HC1"),
    "M5": smf.ols("hlo ~ internet_avg", X.dropna(subset=["hlo", "internet_avg"])).fit(cov_type="HC1"),
    "M3b": smf.ols("hlo ~ log_gdp_pc + edu_exp_gdp_avg + exp_prim_pc_avg + exp_sec_pc_avg + ptr_avg + trained_teachers_avg + broadband_avg", Xc).fit(cov_type="HC1"),
    "M6": smf.ols("hlo ~ edu_exp_gdp_avg + exp_prim_pc_avg + exp_sec_pc_avg + ptr_avg + trained_teachers_avg + internet_avg", Xc).fit(cov_type="HC1"),
    "R1": smf.ols("hlo ~ log_gdp_pc + edu_exp_gdp_avg + exp_prim_pc_avg + exp_sec_pc_avg + ptr_avg + trained_teachers_avg + internet_avg", X.dropna(subset=NEED)).fit(cov_type="HC1"),
}
rows = []
var_order = ["log_gdp_pc", "edu_exp_gdp_avg", "exp_prim_pc_avg", "exp_sec_pc_avg",
             "ptr_avg", "trained_teachers_avg", "internet_avg", "broadband_avg",
             "tertiary_avg", "gpi_sec_avg", "gini_avg", "rural_avg"]
vlab = {"log_gdp_pc": "log10 GDP per capita", "edu_exp_gdp_avg": "Education expenditure (% GDP)",
        "exp_prim_pc_avg": "Per-student primary spending", "exp_sec_pc_avg": "Per-student secondary spending",
        "ptr_avg": "Pupil-teacher ratio", "trained_teachers_avg": "Trained teachers (%)",
        "internet_avg": "Internet users (%)", "broadband_avg": "Fixed broadband (per 100)",
        "tertiary_avg": "Tertiary enrollment (%)", "gpi_sec_avg": "Gender parity (secondary)",
        "gini_avg": "Gini index", "rural_avg": "Rural population (%)"}
for v in var_order:
    row = {"variable": vlab[v]}
    for mn, m in models.items():
        if v in m.params.index:
            b, se, p = m.params[v], m.bse[v], m.pvalues[v]
            stars = "***" if p < 0.001 else "**" if p < 0.01 else "*" if p < 0.05 else "†" if p < 0.10 else ""
            row[mn] = f"{b:.3f}{stars}"
            row[f"{mn}_se"] = f"({se:.3f})"
            row[f"{mn}_p"] = f"{p:.3f}"
        else:
            row[mn] = ""
    rows.append(row)
for mn, m in models.items():
    rows.append({"variable": f"__{mn}_r2", **{k: f"{m.rsquared:.3f}" for k in models}})
    rows.append({"variable": f"__{mn}_n", **{k: str(int(m.nobs)) for k in models}})
T = pd.DataFrame(rows)
print(T[["variable", "M1", "M2", "M3", "M4", "M5", "M3b", "M6", "R1"]].to_string(index=False))
T.to_csv("data/final_models_table.csv", index=False)

# extra numbers needed for text
print("\nM1 full-sample coef log_gdp:", models["M1"].params["log_gdp_pc"].round(3),
      "p:", models["M1"].pvalues["log_gdp_pc"].round(4))
print("M3b broadband coef:", models["M3b"].params["broadband_avg"].round(3),
      "p:", models["M3b"].pvalues["broadband_avg"].round(4))
print("M6 internet coef (no GDP):", models["M6"].params["internet_avg"].round(3),
      "p:", models["M6"].pvalues["internet_avg"].round(4))

# income-group specific coefficients with p-values for table 3
het = json.load(open("data/analysis_out3.json"))["heterogeneity_income"]
for g in ["High", "Upper-middle", "Lower-middle"]:
    h = het[g]
    print(f"\n{g}: N={h['n']} R2={h['r2']:.3f}")
    for v in ["log_gdp_pc", "exp_prim_pc_avg", "trained_teachers_avg", "internet_avg"]:
        print(f"   {v}: {h['params'][v]:.3f} (p={h['pvalues'][v]:.4f})")
ssa = het.get("Sub-Saharan Africa", {})
print("\nSSA internet:", ssa.get("params", {}).get("internet_avg"), "p:", ssa.get("pvalues", {}).get("internet_avg"))

# education spending: gap between high and low income per-student spending (2000-2015)
panel = pd.read_csv("data/master_panel.csv")
countries = json.load(open("data/countries.json", encoding="utf-8"))
meta = pd.DataFrame([{"iso3": k, "income": v["income"]} for k, v in countries.items() if not v["is_aggregate"]])
meta["ig"] = meta.income.map({"High income": "High", "Upper middle income": "UM", "Lower middle income": "LM", "Low income": "Low"})
d = panel[(panel.year >= 2000) & (panel.year <= 2015)][["iso3", "year", "exp_prim_pc", "ptr", "trained_teachers", "internet", "gdp_pc"]].merge(meta, on="iso3")
for v in ["exp_prim_pc", "ptr", "trained_teachers", "internet"]:
    print(f"\n{v} by income group (2000-2015, pop-unweighted mean):")
    print(d.groupby("ig")[v].mean().round(2).to_string())
