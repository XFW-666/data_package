"""Core analysis v2: long-window predictors, main + robustness + heterogeneity + gender + LP."""
import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

pd.set_option("display.width", 220)
pd.set_option("display.max_columns", 60)

panel = pd.read_csv("data/master_panel.csv")
countries = json.load(open("data/countries.json", encoding="utf-8"))
meta = pd.DataFrame([
    {"iso3": k, "country": v["name"], "region": v["region"], "income": v["income"]}
    for k, v in countries.items() if not v["is_aggregate"]
])
meta["income_group"] = meta.income.map({
    "High income": "High", "Upper middle income": "Upper-middle",
    "Lower middle income": "Lower-middle", "Low income": "Low"})

out = {}
PRED = ["edu_exp_gdp", "exp_prim_pc", "exp_sec_pc", "ptr", "trained_teachers",
        "internet", "broadband", "mobile", "gdp_pc", "tertiary", "gpi_prim",
        "gpi_sec", "rural", "gini", "enroll_prim", "enroll_sec", "pop"]

def build_xsec(outcome, outcome_year, y0, y1):
    df = panel.copy()
    d = df[df.year == outcome_year][["iso3", outcome]].dropna()
    for c in PRED:
        d = d.merge(avg_window(df, c, y0, y1).rename(f"{c}_avg"), on="iso3", how="left")
    d["log_gdp_pc"] = np.log10(d["gdp_pc_avg"])
    d = d.merge(meta, on="iso3", how="left")
    return d

def avg_window(df, var, y0, y1):
    sub = df[(df.year >= y0) & (df.year <= y1)]
    return sub.groupby("iso3")[var].mean()

def ols(formula, data, cov="HC1"):
    return smf.ols(formula, data=data).fit(cov_type=cov)

# ================================================================ headline numbers
h = panel[(panel.year == 2017)][["iso3", "hlo"]].dropna()
print("HLO: n=%d mean=%.1f sd=%.1f" % (len(h), h.hlo.mean(), h.hlo.std()))
out.update(hlo_n=len(h), hlo_mean=float(h.hlo.mean()), hlo_sd=float(h.hlo.std()),
           hlo_min=float(h.hlo.min()), hlo_max=float(h.hlo.max()))

# ================================================================ main models (2000-2015 window)
X = build_xsec("hlo", 2017, 2000, 2015).dropna(subset=["hlo"])
print("\nHLO xsec (2000-2015 window):", len(X))
out["xsec_n"] = len(X)

specs = {
    "M1": "hlo ~ log_gdp_pc",
    "M2": "hlo ~ log_gdp_pc + edu_exp_gdp_avg + exp_prim_pc_avg + exp_sec_pc_avg + ptr_avg + trained_teachers_avg",
    "M3": "hlo ~ log_gdp_pc + edu_exp_gdp_avg + exp_prim_pc_avg + exp_sec_pc_avg + ptr_avg + trained_teachers_avg + internet_avg",
    "M4": "hlo ~ log_gdp_pc + edu_exp_gdp_avg + exp_prim_pc_avg + exp_sec_pc_avg + ptr_avg + trained_teachers_avg + internet_avg + tertiary_avg + gpi_sec_avg + gini_avg + rural_avg",
    "M3b": "hlo ~ log_gdp_pc + edu_exp_gdp_avg + exp_prim_pc_avg + exp_sec_pc_avg + ptr_avg + trained_teachers_avg + broadband_avg",
    "M5": "hlo ~ internet_avg",  # digital only, no GDP
    "M6": "hlo ~ edu_exp_gdp_avg + exp_prim_pc_avg + exp_sec_pc_avg + ptr_avg + trained_teachers_avg + internet_avg",  # no GDP
}
models = {}
for k, f in specs.items():
    need = [v for v in f.split("~")[1].split("+")]
    need = [v.strip() for v in need]
    dd = X.dropna(subset=["hlo"] + need)
    m = ols(f, dd)
    models[k] = m
    print("%-4s R2=%.3f adjR2=%.3f N=%d" % (k, m.rsquared, m.rsquared_adj, int(m.nobs)))
    out[f"{k}_r2"] = float(m.rsquared); out[f"{k}_n"] = int(m.nobs)

print("\n--- M2 ---\n", models["M2"].summary().tables[1])
print("\n--- M3 ---\n", models["M3"].summary().tables[1])
print("\n--- M4 ---\n", models["M4"].summary().tables[1])

# standardized betas for M3
zcols = ["hlo", "log_gdp_pc", "edu_exp_gdp_avg", "exp_prim_pc_avg", "exp_sec_pc_avg",
         "ptr_avg", "trained_teachers_avg", "internet_avg"]
Z = X.dropna(subset=zcols).copy()
for c in zcols:
    Z[c] = (Z[c] - Z[c].mean()) / Z[c].std()
m3z = ols("hlo ~ log_gdp_pc + edu_exp_gdp_avg + exp_prim_pc_avg + exp_sec_pc_avg + ptr_avg + trained_teachers_avg + internet_avg", Z)
print("\nM3 standardized betas:\n", m3z.params.round(3).to_string())
out["m3_std_betas"] = {k: float(v) for k, v in m3z.params.items()}

# VIF M3
from statsmodels.stats.outliers_influence import variance_inflation_factor
Xv = X[["log_gdp_pc", "edu_exp_gdp_avg", "exp_prim_pc_avg", "exp_sec_pc_avg", "ptr_avg",
        "trained_teachers_avg", "internet_avg"]].dropna()
Xv = sm.add_constant(Xv)
vif = pd.Series([variance_inflation_factor(Xv.values, i) for i in range(Xv.shape[1])],
                index=Xv.columns).drop("const")
print("\nVIF:\n", vif.round(2).to_string())
out["vif"] = {k: float(v) for k, v in vif.items()}

# ================================================================ robustness: recent windows
for (y0, y1, tag) in [(2007, 2015, "recent"), (2011, 2015, "contemp")]:
    Xr = build_xsec("hlo", 2017, y0, y1).dropna(subset=["hlo"])
    need = ["log_gdp_pc", "edu_exp_gdp_avg", "exp_prim_pc_avg", "exp_sec_pc_avg",
            "ptr_avg", "trained_teachers_avg", "internet_avg"]
    dd = Xr.dropna(subset=need)
    m = ols("hlo ~ log_gdp_pc + edu_exp_gdp_avg + exp_prim_pc_avg + exp_sec_pc_avg + ptr_avg + trained_teachers_avg + internet_avg", dd)
    print("\nM3 %s (%d-%d): R2=%.3f N=%d" % (tag, y0, y1, m.rsquared, int(m.nobs)))
    print(m.params.round(3).to_string())
    out[f"m3_{tag}_r2"] = float(m.rsquared); out[f"m3_{tag}_n"] = int(m.nobs)

# ================================================================ interaction: internet x spending
Xi = X.dropna(subset=["hlo", "log_gdp_pc", "edu_exp_gdp_avg", "exp_prim_pc_avg",
                      "exp_sec_pc_avg", "ptr_avg", "trained_teachers_avg", "internet_avg"]).copy()
Xi["int_x_exp"] = Xi.internet_avg * Xi.exp_prim_pc_avg / 100.0
mi = ols("hlo ~ log_gdp_pc + edu_exp_gdp_avg + exp_prim_pc_avg + exp_sec_pc_avg + ptr_avg + trained_teachers_avg + internet_avg + int_x_exp", Xi)
print("\n--- interaction model ---\n", mi.summary().tables[1])
out["inter_model"] = {k: [float(mi.params[k]), float(mi.pvalues[k])] for k in mi.params.index}

# marginal effect of per-student spending at internet levels
b_exp = mi.params["exp_prim_pc_avg"]
b_int = mi.params["int_x_exp"]
se_exp = mi.bse["exp_prim_pc_avg"]; se_int = mi.bse["int_x_exp"]
cov = mi.cov_params()
for q in [10, 25, 50, 75, 90]:
    iv = np.percentile(Xi.internet_avg, q)
    me = b_exp + b_int * iv / 100.0
    var = se_exp**2 + (iv/100)**2 * se_int**2 + 2*(iv/100)*cov.loc["exp_prim_pc_avg", "int_x_exp"]
    print("internet p%d=%.1f -> marginal effect of exp_prim_pc: %.3f (se %.3f)" % (q, iv, me, np.sqrt(var)))
    out[f"me_exp_at_internet_p{q}"] = [float(me), float(np.sqrt(var))]

json.dump(out, open("data/analysis_out2.json", "w"), indent=1)
X.to_csv("data/xsec_hlo_main.csv", index=False)
for k, m in models.items():
    open(f"data/model_{k}.txt", "w").write(str(m.summary()))
open("data/model_interaction.txt", "w").write(str(mi.summary()))
print("\nsaved v2.")
