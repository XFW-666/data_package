import json, os, time, urllib.request

os.makedirs("data", exist_ok=True)

INDICATORS = {
    "edu_exp_gdp": "SE.XPD.TOTL.GD.ZS",
    "exp_per_student_prim": "SE.XPD.PRIM.PC.ZS",
    "exp_per_student_sec": "SE.XPD.SECO.PC.ZS",
    "exp_per_student_tert": "SE.XPD.TERT.PC.ZS",
    "ptr_primary": "SE.PRM.ENRL.TC.ZS",
    "trained_teachers_prim": "SE.PRM.TCAQ.ZS",
    "internet_users": "IT.NET.USER.ZS",
    "gdp_pc_ppp": "NY.GDP.PCAP.PP.KD",
    "gdp_pc_usd": "NY.GDP.PCAP.CD",
    "tertiary_enroll": "SE.TER.ENRR",
    "gpi_primary": "SE.ENR.PRIM.FM.ZS",
    "gpi_secondary": "SE.ENR.SECO.FM.ZS",
    "population": "SP.POP.TOTL",
}

def fetch_indicator(code):
    rows = []
    page = 1
    while True:
        url = (f"https://api.worldbank.org/v2/country/all/indicator/{code}"
               f"?format=json&per_page=5000&page={page}&date=1995:2024")
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (research script)"})
        with urllib.request.urlopen(req, timeout=90) as r:
            d = json.loads(r.read().decode("utf-8"))
        meta, recs = d[0], d[1]
        rows.extend(recs)
        if page >= meta["pages"]:
            break
        page += 1
        time.sleep(0.3)
    return rows, meta["total"]

summary = {}
for name, code in INDICATORS.items():
    try:
        rows, total = fetch_indicator(code)
        summary[name] = {"code": code, "total": total, "fetched": len(rows)}
        with open(f"data/wdi_{name}.json", "w", encoding="utf-8") as f:
            json.dump(rows, f, ensure_ascii=False)
    except Exception as e:
        summary[name] = {"code": code, "error": repr(e)}
    time.sleep(0.3)

for k, v in summary.items():
    print(k, "->", v)
