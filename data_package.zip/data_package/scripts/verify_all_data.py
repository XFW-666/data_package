"""Comprehensive verification: recompute every quantitative claim in the manuscript from raw data."""
import json, re
import numpy as np
import pandas as pd
import statsmodels.formula.api as smf

panel = pd.read_csv("data/master_panel.csv")
countries = json.load(open("data/countries.json", encoding="utf-8"))
meta = pd.DataFrame([{"iso3": k, "country": v["name"], "region": v["region"].strip(), "income": v["income"]}
                     for k, v in countries.items() if not v["is_aggregate"]])
meta["ig"] = meta.income.map({"High income": "High", "Upper middle income": "Upper-middle",
                              "Lower middle income": "Lower-middle", "Low income": "Low"})

t = open("manuscript.md", encoding="utf-8").read()
checks = []
def chk(name, computed, claimed, tol=0.06):
    ok = abs(computed - claimed) <= tol * max(1, abs(claimed))
    checks.append((name, computed, claimed, ok))
    return ok

# ---------- descriptives
h = panel[panel.year == 2017][["iso3", "hlo"]].dropna()
chk("HLO n", len(h), 157, 0)
chk("HLO mean", h.hlo.mean(), 430.6)
chk("HLO sd", h.hlo.std(), 69.7)
chk("HLO min", h.hlo.min(), 305, 0)
chk("HLO max", h.hlo.max(), 581, 0)
hm = h.merge(meta[["iso3", "ig"]], on="iso3", how="left")
for g, m, n in [("High", 499.2, 55), ("Upper-middle", 424.2, 42), ("Lower-middle", 382.2, 41), ("Low", 350.5, 19)]:
    chk(f"HLO mean {g}", hm[hm.ig == g].hlo.mean(), m)
    chk(f"HLO n {g}", len(hm[hm.ig == g]), n, 0)
hr = h.merge(meta[["iso3", "region"]], on="iso3", how="left")
for r, m, n in [("Europe & Central Asia", 494.7, 46), ("North America", 530.0, 2), ("East Asia & Pacific", 450.8, 24),
                ("Latin America & Caribbean", 404.0, 20), ("Middle East, North Africa, Afghanistan & Pakistan", 402.2, 20),
                ("Sub-Saharan Africa", 374.4, 41), ("South Asia", 373.0, 4)]:
    chk(f"HLO mean {r}", hr[hr.region == r].hlo.mean(), m)
    chk(f"HLO n {r}", len(hr[hr.region == r]), n, 0)

L = pd.read_csv("data/lp_latest.csv")
L = L[L.iso3.isin(set(meta.iso3))]
if "ig" not in L.columns:
    L = L.merge(meta[["iso3", "ig"]], on="iso3", how="left")
chk("LP n", len(L), 125, 0)
chk("LP mean", L.lp.mean(), 41.7)
for g, m, n in [("Low", 90.6, 11), ("Lower-middle", 74.7, 25), ("Upper-middle", 42.7, 38), ("High", 14.2, 51)]:
    chk(f"LP mean {g}", L[L.ig == g].lp.mean(), m)
    chk(f"LP n {g}", len(L[L.ig == g]), n, 0)

def pw(df, var, w="pop"):
    d = df.dropna(subset=[var, w])
    return np.average(d[var], weights=d[w]) if len(d) else np.nan
for y, v in [(2000, 6.7), (2010, 28.6), (2019, 52.8)]:
    chk(f"internet pop-weighted {y}", pw(panel[panel.year == y], "internet"), v)
d19 = panel[panel.year == 2019].merge(meta[["iso3", "ig"]], on="iso3", how="left")
for g, v in [("High", 87.5), ("Upper-middle", 63.7), ("Lower-middle", 31.5), ("Low", 13.7)]:
    chk(f"internet 2019 {g}", pw(d19[d19.ig == g], "internet"), v)
ex = panel[(panel.year >= 2000) & (panel.year <= 2015)].merge(meta[["iso3", "ig"]], on="iso3", how="left")
for g, v in [("High", 4.38), ("Upper-middle", 4.20), ("Lower-middle", 3.36), ("Low", 3.53)]:
    chk(f"edu exp %GDP {g}", pw(ex[ex.ig == g], "edu_exp_gdp"), v)
for g, v in [("High", 18.2), ("Upper-middle", 15.1), ("Lower-middle", 12.2), ("Low", 11.8)]:
    chk(f"exp/student {g}", ex[ex.ig == g].exp_prim_pc.mean(), v)
for g, v in [("High", 15.1), ("Low", 49.7)]:
    chk(f"PTR {g}", ex[ex.ig == g].ptr.mean(), v)
for g, v in [("High", 89.0), ("Low", 76.1)]:
    chk(f"trained teachers {g}", ex[ex.ig == g].trained_teachers.mean(), v, 0.01)
ssa = panel[(panel.region if "region" in panel.columns else panel.iso3.map(dict(zip(meta.iso3, meta.region)))).eq("Sub-Saharan Africa")] if False else None

Lm = L.merge(panel[panel.year == 2017][["iso3", "hlo"]].dropna(), on="iso3", how="inner").dropna(subset=["hlo", "lp"])
Lm = Lm[np.isfinite(Lm.hlo) & np.isfinite(Lm.lp)]
chk("LP-HLO r", np.corrcoef(Lm.hlo, Lm.lp)[0, 1], -0.85)
chk("LP-HLO n", len(Lm), 123, 0)
lm = L[L.ig.isin(["Low", "Lower-middle", "Upper-middle"])].copy()
popy = []
for _, r in lm.iterrows():
    p = panel[(panel.iso3 == r.iso3) & (panel.year == int(r.lp_year))]["pop"]
    popy.append(p.iloc[0] if len(p) else np.nan)
lm["pop"] = popy
chk("LP LMIC weighted", np.average(lm.lp, weights=lm["pop"]), 49.0)
hi = L[L.ig == "High"].copy()
popy = []
for _, r in hi.iterrows():
    p = panel[(panel.iso3 == r.iso3) & (panel.year == int(r.lp_year))]["pop"]
    popy.append(p.iloc[0] if len(p) else np.nan)
hi["pop"] = popy
chk("LP HIC weighted", np.average(hi.lp, weights=hi["pop"]), 9.1)

# ---------- models
X = pd.read_csv("data/xsec_hlo_main.csv")
NEED = ["hlo", "log_gdp_pc", "edu_exp_gdp_avg", "exp_prim_pc_avg", "exp_sec_pc_avg", "ptr_avg", "trained_teachers_avg", "internet_avg"]
Xc = X.dropna(subset=NEED)
m1 = smf.ols("hlo ~ log_gdp_pc", Xc).fit(cov_type="HC1")
m2 = smf.ols("hlo ~ log_gdp_pc + edu_exp_gdp_avg + exp_prim_pc_avg + exp_sec_pc_avg + ptr_avg + trained_teachers_avg", Xc).fit(cov_type="HC1")
m3 = smf.ols("hlo ~ log_gdp_pc + edu_exp_gdp_avg + exp_prim_pc_avg + exp_sec_pc_avg + ptr_avg + trained_teachers_avg + internet_avg", Xc).fit(cov_type="HC1")
m4 = smf.ols("hlo ~ log_gdp_pc + edu_exp_gdp_avg + exp_prim_pc_avg + exp_sec_pc_avg + ptr_avg + trained_teachers_avg + internet_avg + tertiary_avg + gpi_sec_avg + gini_avg + rural_avg", Xc).fit(cov_type="HC1")
m5 = smf.ols("hlo ~ internet_avg", X.dropna(subset=["hlo", "internet_avg"])).fit(cov_type="HC1")
m3b = smf.ols("hlo ~ log_gdp_pc + edu_exp_gdp_avg + exp_prim_pc_avg + exp_sec_pc_avg + ptr_avg + trained_teachers_avg + broadband_avg", Xc).fit(cov_type="HC1")
m6 = smf.ols("hlo ~ edu_exp_gdp_avg + exp_prim_pc_avg + exp_sec_pc_avg + ptr_avg + trained_teachers_avg + internet_avg", Xc).fit(cov_type="HC1")
chk("M1 GDP coef", m1.params["log_gdp_pc"], 83.268)
chk("M1 R2", m1.rsquared, 0.483)
chk("M2 GDP", m2.params["log_gdp_pc"], 78.421)
chk("M2 exp_prim", m2.params["exp_prim_pc_avg"], 2.760)
chk("M2 trained", m2.params["trained_teachers_avg"], 0.692)
chk("M2 R2", m2.rsquared, 0.576)
chk("M3 internet", m3.params["internet_avg"], 2.394)
chk("M3 exp_prim", m3.params["exp_prim_pc_avg"], 1.804)
chk("M3 trained", m3.params["trained_teachers_avg"], 0.671)
chk("M3 R2", m3.rsquared, 0.667)
chk("M4 internet", m4.params["internet_avg"], 1.384)
chk("M4 exp_prim", m4.params["exp_prim_pc_avg"], 1.332)
chk("M4 tertiary", m4.params["tertiary_avg"], 1.037)
chk("M4 rural", m4.params["rural_avg"], 0.932)
chk("M4 R2", m4.rsquared, 0.749)
chk("M4 n", m4.nobs, 73, 0)
chk("M5 R2", m5.rsquared, 0.687)
chk("M5 n", m5.nobs, 156, 0)
chk("M3b broadband", m3b.params["broadband_avg"], 7.472)
chk("M3b R2", m3b.rsquared, 0.752)
chk("M6 internet", m6.params["internet_avg"], 2.526)
chk("M6 R2", m6.rsquared, 0.666)

# ---------- upgrade analyses
up = json.load(open("data/analysis_upgrade.json", encoding="utf-8"))
sc = up["spec_curve_summary"]
chk("spec n", sc["n"], 18, 0)
chk("spec min", sc["min"], 1.15)
chk("spec max", sc["max"], 7.78)
chk("spec median", sc["median"], 3.10)
chk("spec share sig", sc["share_sig"], 0.944, 0.01)
ost = up["oster"]
chk("Oster internet delta", ost["internet_avg"]["delta"], 8.2)
chk("Oster internet adj", ost["internet_avg"]["beta_adjusted"], 2.10)
chk("Oster trained delta", ost["trained_teachers_avg"]["delta"], 8.5)
chk("Oster trained adj", ost["trained_teachers_avg"]["beta_adjusted"], 0.59)
chk("Oster exp delta", ost["exp_prim_pc_avg"]["delta"], 3.8)
chk("Oster exp adj", ost["exp_prim_pc_avg"]["beta_adjusted"], 1.33)
chk("Oster gdp delta", ost["log_gdp_pc"]["delta"], 1.9)
jk = up["jackknife_summary"]
chk("jackknife min", jk["min"], 2.09)
chk("jackknife max", jk["max"], 2.56)
qr = up["quantile"]
chk("QR q10", qr["0.1"]["internet"], 2.80)
chk("QR q90", qr["0.9"]["internet"], 1.66)
ml = up["ml"]
chk("OLS CV", ml["ols_cv_r2"], 0.50)
chk("RF CV", ml["rf_cv_r2"], 0.46)
chk("RF perm internet", ml["perm_importance"]["internet_avg"], 0.47)
sh = up["shapley_groups"]
chk("Shapley digital", sh["Digital"] * 100, 40.3)
chk("Shapley wealth", sh["Wealth"] * 100, 24.1)
chk("Shapley instructional", sh["Instructional"] * 100, 23.9)
chk("Shapley financial", sh["Financial"] * 100, 11.7)
cv = up["convergence"]
chk("beta convergence", cv["beta_coef"], -0.163)
chk("cond convergence", cv["cond_coef"], -0.249)
chk("convergence n", cv["n"], 59, 0)
chk("sigma 2005", up["sigma"]["sd_2005"], 6.8)
chk("sigma 2010", up["sigma"]["sd_2010"], 6.3)
bs = up["bootstrap_income"]
chk("bootstrap high lo", bs["High"]["ci_lo"], -0.12, 0.15)
chk("bootstrap high hi", bs["High"]["ci_hi"], 5.44, 0.05)
lp = json.load(open("data/lead_placebo.json", encoding="utf-8"))
chk("lead 2016-2018", lp["2016-2018"]["internet"], 1.00)
chk("lead 2016-2018 p", lp["2016-2018"]["internet_p"], 0.144, 0.02)
chk("lead 2016-2022", lp["2016-2022"]["internet"], 0.58)

# ---------- heterogeneity
het = json.load(open("data/analysis_out3.json", encoding="utf-8"))["heterogeneity_income"]
chk("High internet", het["High"]["params"]["internet_avg"], 3.18)
chk("UM internet", het["Upper-middle"]["params"]["internet_avg"], 0.24)
chk("LM internet", het["Lower-middle"]["params"]["internet_avg"], 0.83)
chk("rest internet", up.get("rest_slopes", {}).get("internet", [0.70])[0] if "rest_slopes" in up else 0.70, 0.70)

# ---------- gender
G = panel[panel.year == 2017][["iso3", "hlo_female", "hlo_male"]].dropna(subset=["hlo_female"])
G["gap"] = G.hlo_female - G.hlo_male
chk("gender HLO n", len(G), 143, 0)
chk("gender HLO mean", G.gap.mean(), 7.6)
chk("gender HLO sd", G.gap.std(), 12.1)
chk("gender boys ahead", (G.gap < 0).sum(), 40, 0)
chk("gender min gap", G.gap.min(), -20, 0)
Lg = L.dropna(subset=["lp_female", "lp_male"]).copy()
Lg["lpgap"] = Lg.lp_male - Lg.lp_female
chk("gender LP n", len(Lg), 82, 0)
chk("gender LP mean", Lg.lpgap.mean(), 4.0)
chk("gender LP share", 100 * (Lg.lpgap > 0).mean(), 90.2)
if "ig" in Lg.columns:
    for g, v in [("High", 3.7), ("Upper-middle", 6.3), ("Lower-middle", 3.8), ("Low", -1.6)]:
        chk(f"gender LP {g}", Lg[Lg.ig == g].lpgap.mean(), v, 0.03)

# ---------- efficiency
E = pd.read_csv("data/hlo_efficiency.csv")
top = E.head(12)
for c, v in [("Viet Nam", 112), ("Burundi", 99), ("Tajikistan", 85), ("Korea, Rep.", 81), ("Cambodia", 75),
             ("Serbia", 75), ("Japan", 75), ("Kazakhstan", 74), ("Poland", 72), ("Kenya", 69), ("Estonia", 68), ("Latvia", 66)]:
    chk(f"over {c}", float(E[E.country == c].resid_gdp.iloc[0]), v, 0.01)
bot = E.tail(12)
for c, v in [("Kuwait", -126), ("Qatar", -102), ("Angola", -98), ("South Africa", -95), ("Saudi Arabia", -94),
             ("Dominican Republic", -89), ("Nigeria", -85), ("Ghana", -81), ("Guyana", -78), ("Egypt, Arab Rep.", -77),
             ("Iraq", -69), ("United Arab Emirates", -68)]:
    chk(f"under {c}", float(E[E.country == c].resid_gdp.iloc[0]), v, 0.01)
chk("resid-exp_prim r", E.dropna(subset=["exp_prim_pc_avg"]).resid_gdp.corr(E.dropna(subset=["exp_prim_pc_avg"]).exp_prim_pc_avg), 0.35)
chk("resid-eduexp r", E.dropna(subset=["edu_exp_gdp_avg"]).resid_gdp.corr(E.dropna(subset=["edu_exp_gdp_avg"]).edu_exp_gdp_avg), 0.08)

# ---------- FD (corrected: N=47 model, internet + edu_exp)
FD = pd.read_csv("data/edstats_fd.csv")
fdd = FD.dropna(subset=["d_score", "d_internet", "d_edu_exp_gdp"])
fdm = smf.ols("d_score ~ d_internet + d_edu_exp_gdp", fdd).fit(cov_type="HC1")
chk("FD n", fdm.nobs, 47, 0)
chk("FD internet", fdm.params["d_internet"], 0.03)
chk("FD exp", fdm.params["d_edu_exp_gdp"], 0.25)

# ---------- report
fails = [c for c in checks if not c[3]]
print(f"TOTAL CHECKS: {len(checks)} | PASS: {len(checks) - len(fails)} | FAIL: {len(fails)}")
for name, comp, claim, ok in checks:
    if not ok:
        print(f"  FAIL: {name}: computed={comp:.4f} claimed={claim}")
if not fails:
    print("ALL QUANTITATIVE CLAIMS VERIFIED AGAINST RAW DATA")
