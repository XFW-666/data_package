"""Append tables, figure legends, references and closing statements to manuscript.md."""
import pandas as pd

S = pd.read_csv("data/summary_stats.csv")
T = pd.read_csv("data/final_models_table.csv")

lines = []
lines.append("\n## FIGURE LEGENDS\n")
legends = [
    ("FIGURE 1", "Global landscape of learning outcomes and learning poverty by national income group. Panel A shows the distribution of harmonized learning outcome (HLO) scores for 2017 across 157 countries, with box plots indicating the median and interquartile range, individual points showing countries, and the dashed line marking the global mean of 430.6. Panel B shows mean learning poverty by income group for the 125 countries with recent estimates, with the number of countries shown within each bar. Data: World Bank Human Capital Index and World Development Indicators."),
    ("FIGURE 2", "Evolution of educational inputs by income group, 2000–2019. Population-weighted means are shown for high-income (dark blue), upper-middle-income (medium blue), lower-middle-income (light blue), and low-income (pale blue) countries. Panel A: internet users (% of population). Panel B: government education expenditure (% of GDP). Panel C: government expenditure per primary student (% of GDP per capita). Panel D: pupil–teacher ratio in primary education. Data: World Development Indicators."),
    ("FIGURE 3", "Bivariate associations between harmonized learning outcomes and representative educational inputs. Each panel shows 83–157 countries with inputs averaged over 2000–2015, the ordinary least squares fit line, the Pearson correlation coefficient, and the sample size. Panel A: log10 GDP per capita. Panel B: internet users (%). Panel C: per-student primary spending (% of GDP per capita). Panel D: trained teachers in primary education (%). Data: World Bank Human Capital Index and World Development Indicators."),
    ("FIGURE 4", "Standardized effects and explained variance in harmonized learning outcomes. Panel A shows standardized regression coefficients (β) with 95% confidence intervals from Model 3 (N = 83); orange markers indicate statistical significance at p < 0.05. Panel B compares the proportion of variance explained (R²) on the common 83-country sample for four nested specifications. Data: World Bank Human Capital Index and World Development Indicators."),
    ("FIGURE 5", "Digital access and stage-dependent production functions. Panel A shows the convex association between internet penetration and harmonized learning outcomes with the quadratic fit; the quadratic term is significant (p = 0.017). Panel B shows income-group-specific unstandardized coefficients for three inputs from separate models estimated within each income group (high income N = 20, upper-middle N = 23, lower-middle N = 26). Data: World Bank Human Capital Index and World Development Indicators."),
    ("FIGURE 6", "Robustness of the digital-access association and within-country change analysis. Panel A shows the coefficient on digital access with 95% confidence intervals across five specifications: the main model (2000–2015 predictor window), two shorter windows (2007–2015 and 2011–2015), a broadband-based measure, and a specification without the wealth control. Panel B shows first-difference coefficients for changes in inputs between the 2005 and 2010 EdStats waves (N = 59); orange indicates marginal significance (p < 0.10). Data: World Bank Human Capital Index, EdStats, and World Development Indicators."),
    ("FIGURE 7", "Gender gaps in learning. Panel A shows the distribution of female-minus-male harmonized learning outcome scores across 143 countries, with the dashed line marking the mean advantage for girls (+7.6 points) and the solid line marking parity; 40 countries lie to the left of zero, indicating a male advantage. Panel B shows the male-minus-female learning-poverty gap in percentage points by income group (82 countries with sex-disaggregated estimates). Data: World Bank Human Capital Index and World Development Indicators."),
    ("FIGURE 8", "Efficiency analysis of harmonized learning outcomes. Panel A shows the twelve largest positive and twelve largest negative residuals from a regression of learning outcomes on log GDP per capita alone (N = 155). Panel B plots residuals against per-student primary spending, with the fitted line (r = 0.35, n = 130). Data: World Bank Human Capital Index and World Development Indicators."),
    ("FIGURE 9", "Convergence of outcome measures and correlation structure. Panel A shows the association between harmonized learning outcomes and learning poverty across 123 countries with both measures (r = −0.85). Panel B shows the Pearson correlation matrix of the harmonized outcome and the eleven core predictors, with sample sizes ranging from 73 to 157 depending on variable availability. Data: World Bank Human Capital Index and World Development Indicators."),
]
for tag, txt in legends:
    lines.append(f"**{tag}.** {txt}\n")

# ---------------- Table 1
lines.append("## TABLES\n")
lines.append("**TABLE 1.** Summary statistics for the core analytical sample (N = 83 countries unless noted). Predictor variables are averaged over 2000–2015; the harmonized learning outcome is measured in 2017.\n")
lines.append("| Variable | N | Mean | SD | Min | Max |")
lines.append("|---|---|---|---|---|---|")
name_map = {
    "Harmonized learning outcome (HLO)": "Harmonized learning outcome (HLO, 2017)",
    "log10 GDP per capita": "log10 GDP per capita (PPP)",
    "Education expenditure (% GDP)": "Education expenditure (% of GDP)",
    "Per-student primary spending (% GDP pc)": "Per-student primary spending (% GDP p.c.)",
    "Pupil-teacher ratio": "Pupil–teacher ratio, primary",
    "Trained teachers (%)": "Trained teachers, primary (%)",
    "Internet users (%)": "Internet users (%)",
    "Tertiary enrollment (%)": "Tertiary enrollment, gross (%)",
    "Gender parity index (secondary)": "Gender parity index, secondary",
    "Gini index": "Gini index",
    "Rural population (%)": "Rural population (%)",
}
for _, r in S.iterrows():
    nm = name_map.get(r["var"], r["var"])
    lines.append(f"| {nm} | {int(r['n'])} | {r['mean']:.1f} | {r['sd']:.1f} | {r['min']:.1f} | {r['max']:.1f} |")
lines.append("")

# ---------------- Table 2
lines.append("**TABLE 2.** Ordinary least squares models of harmonized learning outcomes (N = 83 unless noted). Heteroskedasticity-robust (HC1) standard errors in parentheses.\n")
cols = [("M1", "M1"), ("M2", "M2"), ("M3", "M3"), ("M4", "M4"), ("M5", "M5"), ("M3b", "M3b"), ("M6", "M6")]
lines.append("| Variable | " + " | ".join(c[0] for c in cols) + " |")
lines.append("|" + "---|" * (len(cols) + 1))
var_rows = T[~T.variable.str.startswith("__")]
for _, r in var_rows.iterrows():
    cells = []
    for c, _ in cols:
        v = r.get(c, "")
        if isinstance(v, str) and v:
            cells.append(v)
        else:
            cells.append("")
    if any(cells):
        lines.append(f"| {r['variable']} | " + " | ".join(cells) + " |")
for tag in ["__M1_r2", "__M2_r2", "__M3_r2", "__M4_r2", "__M5_r2", "__M3b_r2", "__M6_r2"]:
    pass
lines.append("| R² | 0.483 | 0.576 | 0.667 | 0.749 | 0.687 | 0.752 | 0.666 |")
lines.append("| N | 83 | 83 | 83 | 73 | 156 | 82 | 83 |")
lines.append("")
lines.append("Note: \u2020 p < 0.10, \* p < 0.05, \*\* p < 0.01, \*\*\* p < 0.001. M1: wealth only. M2: M1 + financial and instructional inputs. M3: M2 + internet users. M4: M3 + tertiary enrollment, gender parity, Gini, rural share. M5: internet users only (full sample). M3b: M3 with fixed broadband subscriptions instead of internet users. M6: M3 without the wealth control.\n")

# ---------------- Table 3
lines.append("**TABLE 3.** Robustness, heterogeneity, and within-country change analyses of the digital-access and input associations.\n")
lines.append("| Analysis | Coefficient | SE | p | N |")
lines.append("|---|---|---|---|---|")
rows3 = [
    ("Robustness: main model (2000–2015 window), internet", "2.394", "0.496", "<0.001", "83"),
    ("Robustness: recent window (2007–2015), internet", "1.627", "0.469", "<0.001", "71"),
    ("Robustness: contemporaneous window (2011–2015), internet", "1.149", "0.590", "0.055", "57"),
    ("Robustness: broadband measure (per 100 inhabitants)", "7.472", "0.873", "<0.001", "82"),
    ("Robustness: no wealth control, internet", "2.526", "0.495", "<0.001", "83"),
    ("Functional form: internet squared (convexity)", "0.045", "0.019", "0.017", "83"),
    ("Interaction: internet × per-student spending", "−0.467", "3.880", "0.904", "83"),
    ("Interaction: internet × log GDP per capita", "1.358", "0.925", "0.140", "83"),
    ("Heterogeneity: high income, internet", "3.182", "1.038", "0.004", "20"),
    ("Heterogeneity: low/middle income, internet", "0.697", "0.738", "0.338", "63"),
    ("Heterogeneity: high income, per-student spending", "3.602", "4.686", "0.450", "20"),
    ("Heterogeneity: low/middle income, per-student spending", "2.317", "0.678", "0.001", "63"),
    ("Heterogeneity: Sub-Saharan Africa, internet", "2.946", "1.333", "0.031", "34"),
    ("Within-country change (2005→2010): Δ internet", "0.168", "0.160", "0.294", "59"),
    ("Within-country change (2005→2010): Δ trained teachers", "0.154", "0.080", "0.056", "59"),
    ("Within-country change (2005→2010): Δ education spending", "−0.141", "0.612", "0.818", "59"),
]
for a, b, c, d, e in rows3:
    lines.append(f"| {a} | {b} | {c} | {d} | {e} |")
lines.append("")
lines.append("Note: The joint F-test of all seven interactions between the high-income indicator and the core predictors was significant (p = 0.004). Within-country change models use the EdStats adjusted test score as outcome and five-year lagged changes in inputs as predictors, with heteroskedasticity-robust standard errors.\n")

with open("manuscript.md", "a", encoding="utf-8") as f:
    f.write("\n".join(lines))
print("appended tables and legends")
