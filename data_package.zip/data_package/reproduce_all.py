"""Run the full analysis, table, figure, and validation pipeline in order.

Usage: python reproduce_all.py
Run from the package root. Requires the dependencies in requirements.txt.
"""
import subprocess
import sys

ANALYSIS = [
    "scripts/analysis1.py", "scripts/analysis2.py", "scripts/analysis3.py",
    "scripts/analysis4.py", "scripts/analysis5.py", "scripts/analysis_upgrade.py",
    "scripts/lead_placebo.py", "scripts/fd_specs.py", "scripts/gapfill_analyses.py",
]
OUTPUT = ["scripts/final_tables.py", "scripts/build_merged_figs.py"]
VALIDATION = ["scripts/verify_all_data.py", "scripts/verify_gapfill.py",
              "scripts/check_consistency.py"]

for group, scripts in [("analysis", ANALYSIS), ("output", OUTPUT), ("validation", VALIDATION)]:
    print("\n==== %s ====" % group.upper())
    for s in scripts:
        print("--> python", s)
        r = subprocess.run([sys.executable, s])
        if r.returncode != 0:
            print("FAILED:", s)
            sys.exit(r.returncode)
print("\nPipeline complete.")
