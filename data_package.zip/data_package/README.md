# Money, Teachers, or Machines? Educational Resources, Instructional Quality, and Digital Connectivity as Correlates of National Learning Outcomes Across 157 Countries

Data and code package accompanying the manuscript. This repository contains all
input data, analysis code, figure-generation code, and validation scripts needed
to reproduce every number and figure reported in the paper. All data are derived
from public sources; no individual-level or restricted data are included.

---

## 1. Data provenance

All data are obtained from the **World Bank open data infrastructure** through its
public REST API (`https://api.worldbank.org`). No proprietary or non-public data
are used, and no values are hand-entered or simulated.

| Source | Indicators | Coverage |
|---|---|---|
| Human Capital Index / harmonized learning outcomes (EdStats source 12, `HD.HCI.HLOS`) | harmonized learning outcome (HLO), female/male breakdowns, learning-adjusted years of schooling | 157 countries, 2017 |
| Learning poverty (`SE.LPV.PRIM`, total/female/male, out-of-school) | learning poverty | 125 countries, 2001–2023 |
| EdStats adjusted test scores (`AED.PRSC.MEAN`) | harmonized primary/secondary scores | 120 countries, waves 1990–2010 |
| World Development Indicators | expenditure (% GDP), spending per primary/secondary student, pupil–teacher ratio, trained teachers, internet users, fixed broadband, mobile, tertiary enrollment, gender parity, Gini, rural share, GDP per capita (PPP), population | 217 countries, 1990–2024 |
| Natural Earth (public-domain vector map) | country boundaries (50m) for the world map | global |

The raw API responses are stored under `data/` as JSON (`wdi_*.json`,
`edstats_*.json`, `hlo_scores*.json`, `lays.json`, `lp_*.json`). The retrieval
scripts in `scripts/` (`fetch_*.py`, `build_countries.py`, `build_panel.py`)
regenerate the analytical panel from these raw files.

## 2. Package structure

```
data_package/
├── README.md
├── requirements.txt
├── CITATION.cff
├── .zenodo.json
├── manuscript.md              # manuscript source (read by the validation scripts)
├── data/                      # raw API pulls + derived analytical files
│   ├── wdi_*.json             # raw World Bank API responses (indicators)
│   ├── edstats_*.json         # raw adjusted-score series
│   ├── hlo_scores*.json       # raw harmonized outcome series (total/female/male)
│   ├── lp_*.json              # raw learning-poverty series
│   ├── lays.json              # learning-adjusted years of schooling
│   ├── countries.json         # country metadata (region, income group)
│   ├── ne50_countries.geojson # Natural Earth 50m boundaries
│   ├── master_panel.csv       # country-year panel (inputs + outcomes)
│   ├── xsec_hlo_main.csv      # main cross-section (predictors averaged 2000-2015)
│   ├── xsec_hlo_10y.csv       # 10-year-window cross-section
│   ├── xsec_hlo_5y.csv        # 5-year-window cross-section
│   ├── analysis_out1-5.json   # analysis outputs
│   ├── analysis_upgrade.json  # Shapley, Oster, jackknife, quantile, ML, threshold
│   ├── gapfill_analyses.json  # IV/2SLS, Hansen threshold, Moran's I/SLX, H3 test
│   ├── spec_curve.csv         # 18 specifications
│   ├── jackknife.csv          # leave-one-region-out
│   ├── convergence.csv        # EdStats panel convergence
│   ├── corr_matrix.csv        # predictor correlation matrix
│   ├── hlo_efficiency.csv     # residuals vs income prediction
│   └── ...                    # other derived tables
├── scripts/
│   ├── fetch_*.py             # data retrieval from the World Bank API
│   ├── build_countries.py     # country metadata
│   ├── build_panel.py         # assemble master_panel.csv
│   ├── analysis1.py ... analysis5.py   # descriptive + multivariate + robustness
│   ├── analysis_upgrade.py    # Shapley, Oster, spec curve, quantile, random forest
│   ├── lead_placebo.py        # temporal falsification
│   ├── fd_specs.py            # within-country first-difference models
│   ├── gapfill_analyses.py    # IV/2SLS, Hansen threshold, Moran's I, SLX, H3 test
│   ├── build_merged_figs.py   # generate all 5 figures
│   ├── final_tables.py        # regression tables
│   ├── append_tables.py       # summary-statistics table
│   └── verify_*.py            # automated checks of every reported number
└── figures/                   # generated PNGs (output)
```

## 3. Reproducing the results

Install the environment (Python 3.12):

```bash
pip install -r requirements.txt
```

Re-run the full pipeline from the package root, in order:

```bash
# 1. retrieve raw data from the World Bank API (optional; raw JSONs are included)
python scripts/fetch_wdi.py
python scripts/fetch_wdi2.py
python scripts/fetch_hlo.py
python scripts/fetch_extra.py
python scripts/fetch_map50.py
python scripts/fetch_telephone.py
python scripts/build_countries.py
python scripts/build_panel.py

# 2. analysis
python scripts/analysis1.py
python scripts/analysis2.py
python scripts/analysis3.py
python scripts/analysis4.py
python scripts/analysis5.py
python scripts/analysis_upgrade.py
python scripts/lead_placebo.py
python scripts/fd_specs.py
python scripts/gapfill_analyses.py

# 3. tables and figures
python scripts/final_tables.py
python scripts/build_merged_figs.py

# 4. validation (recompute every reported number and check it against the text)
python scripts/verify_all_data.py
python scripts/verify_gapfill.py
python scripts/check_consistency.py
```

`reproduce_all.py` runs steps 2–4 in the correct order.

## 4. Methods summary

- **Staged OLS** of the harmonized learning outcome on four input domains
  (financial, instructional, digital, equity), common sample N = 83, HC1
  robust standard errors.
- **Relative importance**: Shapley-value decomposition of R² over all 5,040
  predictor orderings.
- **Robustness**: specification-curve analysis (18 specifications), Oster
  bounding for selection on unobservables, leave-one-region-out jackknife,
  temporal falsification (post-outcome lead windows), random forest with
  five-fold cross-validation, quantile regressions.
- **Identification and extensions**: instrumental-variables estimation (two-stage
  least squares) instrumenting internet penetration with legacy fixed-telephone
  infrastructure (1995–2000); a Hansen-type threshold test for stage-dependence;
  Moran's I and a spatially-lagged (SLX) model for spatial dependence; a
  system-level test of the compensatory (H3) hypothesis.
- **Secondary outcomes and dynamics**: learning poverty (descriptive),
  β- and σ-convergence on the EdStats panel, within-country first differences,
  gender gaps, and an efficiency (residual) analysis.

All analyses use pandas, NumPy, statsmodels, and scikit-learn. Random-number
generators are seeded for reproducibility.

## 5. Validation

`verify_all_data.py` recomputes every quantitative claim in the manuscript
(coefficients, correlations, group means, sample sizes, p-values) from the raw
data and reports a pass/fail count. `verify_gapfill.py` does the same for the
identification and spatial analyses. `relevance_audit.py` and
`reverify_refs2.py` check that each reference is real (resolved via the Crossref
API) and cited in a relevant context.

## 6. License

- **Code**: released for reproducibility. Choose a license before publishing
  (the default in `CITATION.cff` is MIT; edit to taste).
- **Data**: all data are derived from the World Bank open data and Natural Earth
  public-domain sources and are governed by those sources' terms. The World Bank
  data are provided under the Creative Commons Attribution 4.0 International
  license (CC BY 4.0); attribute the World Bank when reusing.

## 7. Citation

See `CITATION.cff` and `.zenodo.json`. Replace the author and affiliation
placeholders and the DOI with the final published identifiers before uploading.

## 8. Contact

Corresponding author: [name, email — to be completed before submission].
